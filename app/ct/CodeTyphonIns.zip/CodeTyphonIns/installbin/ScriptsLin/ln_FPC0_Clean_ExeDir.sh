# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

if [ ! -d $vFpcExeDir/ ] ;
then   
  exit
fi

cd $vFpcExeDir

echo " "
echo "----------------------------------------------------"
echo "     Clean FPC$vBits Executables Directory "
echo "----------------------------------------------------"

find $PWD -type f -iname "*-addr2line" -exec rm -f {} \;
find $PWD -type f -iname "*-ar" -exec rm -f {} \;
find $PWD -type f -iname "*-as" -exec rm -f {} \;
find $PWD -type f -iname "*-gprof" -exec rm -f {} \;
find $PWD -type f -iname "*-ld" -exec rm -f {} \;
find $PWD -type f -iname "*-nm" -exec rm -f {} \;
find $PWD -type f -iname "*-objcopy" -exec rm -f {} \;
find $PWD -type f -iname "*-objdump" -exec rm -f {} \;
find $PWD -type f -iname "*-ranlib" -exec rm -f {} \;
find $PWD -type f -iname "*-readelf" -exec rm -f {} \;
find $PWD -type f -iname "*-run" -exec rm -f {} \;
find $PWD -type f -iname "*-size" -exec rm -f {} \;
find $PWD -type f -iname "*-strings" -exec rm -f {} \;
find $PWD -type f -iname "*-strip" -exec rm -f {} \;
find $PWD -type f -iname "*-cecopy" -exec rm -f {} \;
find $PWD -type f -iname "*-dlltool" -exec rm -f {} \;
find $PWD -type f -iname "*-windres" -exec rm -f {} \;
find $PWD -type f -iname "*-ld.bfd" -exec rm -f {} \;
find $PWD -type f -iname "*-gld" -exec rm -f {} \;
find $PWD -type f -iname "*-gas" -exec rm -f {} \;
find $PWD -type f -iname "*-c++filt" -exec rm -f {} \;
find $PWD -type f -iname "*-elfedit" -exec rm -f {} \;

find $PWD -type f -iname "arm-linux-*" -exec rm -f {} \;

find $PWD -type f -iname "ppcross*" -exec rm -f {} \;

find $PWD -type f -iname "*jvm" -exec rm -f {} \;
find $PWD -type f -iname "*.jar" -exec rm -f {} \;

find $PWD -type f -iname "*.ctss" -exec rm -f {} \;
find $PWD -type f -iname "*-readme.txt" -exec rm -f {} \;

cd /usr/local/codetyphon/ScriptsLin
}

# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi

echo " "

