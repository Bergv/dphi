# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

echo "----------------------------------------------"
echo "    Please Wait... Removing FreePascal $vBits" 
echo "----------------------------------------------"

#--------------Remove FreePascal Conguration File ----------------
if [ -f $vFpcCfgDir/fpc.cfg ] ;
then  
  sudo rm -f $vFpcCfgDir/fpc.cfg
fi

#------------- Remove FreePascal Bin Directory --------------------
if [ -d $vFpcDir ] ;
then 
  sudo rm -fr $vFpcDir
  echo "[INFO]: FreePascal Bin Directory Removed OK"
else
  echo "[INFO]: FreePascal Bin Directory NOT EXIST, nothing to do ..."   
fi

#------------- Remove FreePascal Source Directory -----------------
if [ -d $vFpcSrcDir ] ;
then 
  sudo rm -fr $vFpcSrcDir
  echo "[INFO]: FreePascal Source Directory Removed OK"
else
  echo "[INFO]: FreePascal Source Directory NOT EXIST, nothing to do ..."   
fi

#------------- Remove LLDB Directory -----------------
if [ -d $vCTDir/binLLDB ] ;
then 
  sudo rm -fr $vCTDir/binLLDB
  echo "[INFO]: LLDB Directory Removed OK"
else
  echo "[INFO]: LLDB Directory NOT EXIST, nothing to do ..."   
fi

# ------------------------------------------------

./ln_xCodeTyphon_Remove_CrossBuildEngine.sh
./ln_xCodeTyphon_Remove_ChainsLibrary.sh
./ln_xCodeTyphon_Remove_Libraries.sh

#------------- Remove FreePascal all link files ---------------------

sudo rm -f $vOSBinDir/fpc
sudo rm -f $vOSBinDir/fpc32
sudo rm -f $vOSBinDir/fpc64
sudo rm -f $vOSBinDir/ppc386
sudo rm -f $vOSBinDir/ppcx64

}

# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi

echo "   "
echo "[INFO]: All FreePascal parts removed from disk"



