# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ CrossEng @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

if [ ! -d $vCTDir/CrossEng ] ;
then     
    echo "   "
    echo "-------------------------------------------------------"
    echo "       Extract CrossBuild Engine..."
    echo "-------------------------------------------------------"
    echo "   "
    sudo mkdir $vCTDir/CrossEng
    sudo chmod -R 777 $vCTDir/CrossEng/
fi

# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ GDB @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

if [ -d $vCTDir/CrossEng/gdbout ] ;
then     
    echo "[INFO]: Remove OLD GDB temporary OUT directory..."
    sudo rm -rf $vCTDir/CrossEng/gdbtem
fi
   
if [ ! -d $vCTDir/CrossEng/gdb_src ] ;
then    
sudo $v7zipexe x ../../allzips/src/gdb_src.7z -o$vCTDir/CrossEng/ -y
sudo chmod -R 777 $vCTDir/CrossEng/gdb_src/
fi

sudo mkdir $vCTDir/CrossEng/gdbout
sudo chmod -R 777 $vCTDir/CrossEng/gdbout/

# ===================== Build GDB Final ==================

./ln_GDB_Build_Final.sh $bbPCBits $bbPCOS $bbPCCPUOS $bbGDBbuildCPUOS $bbGDBhostCPUOS $bbGDBTargetCPUOS

# ================== Check and Strip GDB files ===========

if [ -d $vCTDir/CrossEng/gdbout/bin ] ;
then      

   echo "   "
   echo "-------------------------------------------------------"
   echo "   Strip GDB Executables files..."
   echo "-------------------------------------------------------"
   echo "   "

   sudo chmod -R 777 $vCTDir/CrossEng/gdbout/bin
   sudo strip $vCTDir/CrossEng/gdbout/bin/*   

   echo "------------------------------------------------"
   echo "   "
   echo "[FINAL INFO]: GDB for Host=$bbGDBhostCPUOS and Target=$bbGDBTargetCPUOS Build OK...!!!" 
   echo "All GDB Executables are in /usr/local/codetyphon/CrossEng/gdbout/bin/ Directory"
   echo "   "
else
   echo "------------------------------------------------"
   echo "   "
   echo "??????????????????????????????????????????????????????????????????????"
   echo "[ERROR]: Sorry, GDB for Host=$bbGDBhostCPUOS and Target=$bbGDBTargetCPUOS NOT Build..." 
   echo "??????????????????????????????????????????????????????????????????????"
fi
 
}

# =================== MAIN =============================
. /usr/local/codetyphon/ScriptsLin/ln_All_Functions.sh
getvalues

bbPCBits=$1
bbPCOS=$2
bbPCCPUOS=$3
bbGDBbuildCPUOS=$4
bbGDBhostCPUOS=$5
bbGDBTargetCPUOS=$6

# ----------------------------------------

echo "   "
echo "==============================================="
echo "           GDB Build Engine settings"
echo "==============================================="
echo "   "
echo $bbBits
echo $bbOS
echo $bbPCCPUOS
echo $bbGDBbuildCPUOS
echo $bbGDBhostCPUOS
echo $bbGDBTargetCPUOS
echo "   "

dothejob

