# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

echo "-------------------------------------------------------"
echo "          Convert rpms to deps files"
echo "-------------------------------------------------------"
cd ~/
echo "Converting FPC rpm file..."
sudo alien -c fpc-2*.rpm
echo "Converting FPC-Source rpm file..."
sudo alien -c fpc-src*.rpm
echo "Converting Lazarus rpm file..."
sudo alien -c lazarus*.rpm


