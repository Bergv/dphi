# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

if [ -d $vTyphonSetDir ] ;
then   
  sudo chmod -R 777 $vTyphonSetDir
  sudo rm -fr $vTyphonSetDir
fi

if [ ! -d $vTyphonSetDir ] ;
then   
  sudo mkdir $vTyphonSetDir
  sudo chmod -R 777 $vTyphonSetDir
fi

echo "   "
echo "[INFO]: Clean Typhon$vBits IDE Setings finish"

}

# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

echo "   "
echo "--------------------------------------------"
echo "       Clean Typhon IDE Setings"
echo "--------------------------------------------"


dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi

echo "   "

