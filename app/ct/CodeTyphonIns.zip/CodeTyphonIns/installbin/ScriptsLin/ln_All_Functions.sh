# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

#================== Find Linux Distribution =============

FindDistributionLinux()
{

# cat /etc/*-release 

vMultiArchDirPlan=0

#------------ 760 ChakraLinux ------------------------
# Chakra Linux has and "/etc/lsb-release" file like Ubuntu 
# so must place before ubuntu

 if [ -f /etc/chakra-release ] ; then
   vOSVerNum=760
   vOSDistribution="Chakra Linux"
   vMultiArchDirPlan=300
   
#------------ 750 ArtixLinux ------------------------
 elif [ -f /etc/artix-release ] ; then
   vOSVerNum=750
   vOSDistribution="Artix Linux"
   vMultiArchDirPlan=300

#------------ 763 KaOS Linux ------------------------
# KaOS Linux has and "/etc/lsb-release" file like Ubuntu 
# so must place before ubuntu

 elif [ -f /etc/KaOS-release ] ; then
   vOSVerNum=763
   vOSDistribution="KaOS Linux"
   vMultiArchDirPlan=0
   
#------------ 765 PCLinuxOS ------------------------
# PCLinuxOS Linux has and "/etc/Mandriva-release" file like Mandriva 
# so must place before Mandriva

 elif [ -f /etc/pclinuxos-release ] ; then
   vOSVerNum=765
   vOSDistribution="PCLinuxOS Linux"
   vMultiArchDirPlan=200

#------------ 775 MageiaLinux ------------------------
# Mageia Linux has and 
# "/etc/mandriva-release" and
# "/etc/redhat-release"
# "/etc/mandrake-release"
# so must place before Mandriva, Redhat and Mandrake

 elif [ -f /etc/mageia-release ] ; then
   vOSVerNum=775
   vOSDistribution="Mageia Linux"
   vMultiArchDirPlan=100

#------------ 776 ROSA Linux ------------------------
# ROSA and  OpenMandriva Linux has and 
# "/etc/lsd-release" and
# "/etc/mandriva-release" and
# "/etc/redhat-release" 
# "/etc/mandrake-release"
# so must place before Mandriva, Redhat, debian and Mandrake

 elif [ -f /etc/rosa-release ] ; then
 
  case $(cat /etc/rosa-release) in 
   *OpenMandriva*)   
     vOSVerNum=777
     vOSDistribution="OpenMandriva Linux"
     vMultiArchDirPlan=100
    ;; 
   *)
     vOSVerNum=776
     vOSDistribution="ROSA Linux"
     vMultiArchDirPlan=100
   ;;    
  esac   
   
#------------ 770 MandrivaLinux ------------------------
# Mandriva Linux has and "/etc/lsb-release" file like Ubuntu 
# so must place before Ubuntu

 elif [ -f /etc/mandriva-release ] ; then
   vOSVerNum=770
   vOSDistribution="Mandriva Linux"  
   vMultiArchDirPlan=100 

#------------ 780 Manjaro Linux ------------------------
# Manjaro Linux has and "/etc/lsb-release" file like Ubuntu 
# so must place before Ubuntu

 elif [ -f /etc/manjaro-release ] ; then
   vOSVerNum=780
   vOSDistribution="Manjaro Linux"
   vMultiArchDirPlan=300
       
#------------ 400 CentOS -------------------------- 
# CentOS >6.4 Linux has and "/etc/lsb-release" file like Ubuntu 
# so must place before Ubuntu             
 elif [ -f /etc/centos-release ] ; then
   vOSVerNum=400
   vOSDistribution="CentOS Linux" 
   vMultiArchDirPlan=100 
       
#------------ 450 Oracle Linux -----------------------            
 elif [ -f /etc/oracle-release ] ; then
   vOSVerNum=450
   vOSDistribution="Oracle Linux" 
   vMultiArchDirPlan=100 

#------------ 720 Sabayon --------------------------- 
# Sabayon >14.01 Linux has and "/etc/lsb-release" file like Ubuntu           
 elif [ -f /etc/sabayon-release ] ; then
   vOSVerNum=720
   vOSDistribution="Sabayon Linux"
   vMultiArchDirPlan=400

#------------ 750 ArchLinux ------------------------            
 elif [ -f /etc/arch-release ] ; then
   vOSVerNum=750
   vOSDistribution="Arch Linux"
   vMultiArchDirPlan=300                              
      
#------------ 500 Fedora -------------------------                         
 elif [ -f /etc/fedora-release ] ; then
   vOSVerNum=500
   vOSDistribution="Fedora Linux" 
   vMultiArchDirPlan=100                       
 elif [ -f /etc/aurox-release ] ; then
   vOSVerNum=500
   vOSDistribution="Aurox Linux"  
   vMultiArchDirPlan=100                      
 elif [ -f /etc/blackcat-release ] ; then
   vOSVerNum=500
   vOSDistribution="BlackCat Linux" 
   vMultiArchDirPlan=100                       
 elif [ -f /etc/yellowdog-release ] ; then
   vOSVerNum=500
   vOSDistribution="Yellow Dog Linux"    
   vMultiArchDirPlan=100                                 
 elif [ -f /etc/tinysofa-release ] ; then
   vOSVerNum=500
   vOSDistribution="Tiny Sofa Linux"  
   vMultiArchDirPlan=100                     
 elif [ -f /etc/e-smith-release ] ; then
   vOSVerNum=500
   vOSDistribution="SME Server (E-Smith) Linux" 
   vMultiArchDirPlan=100 

#------------ 600 RedHat -------------------------               
 elif [ -f /etc/redhat-release ] ; then
   vOSVerNum=600
   vOSDistribution="Red Hat Linux"   
   vMultiArchDirPlan=100            
 elif [ -f /etc/immunix-release ] ; then
   vOSVerNum=600
   vOSDistribution="Immunix Linux"  
   vMultiArchDirPlan=100
   
#------------ 700 Gentoo ---------------------------            
 elif [ -f /etc/gentoo-release ] ; then
   vOSVerNum=700
   vOSDistribution="Gentoo Linux" 
   vMultiArchDirPlan=400

#------------ 740 ChakraLinux ------------------------            
 elif [ -f /etc/chakra-release ] ; then
   vOSVerNum=740
   vOSDistribution="Chakra Linux"
   vMultiArchDirPlan=300
   
#------------ 800 Slackware -----------------------               
 elif [ -f /etc/slackware-version ] ; then
   vOSVerNum=800
   vOSDistribution="Slackware Linux" 
   vMultiArchDirPlan=500
   
#------------ 850 Solus -----------------------               
 elif [ -f /etc/solus-release ] ; then
   vOSVerNum=850
   vOSDistribution="Solus Linux" 
   vMultiArchDirPlan=500
      
#------------ 100 Alt (apt-get compitible)----------
 elif [ -f /etc/altlinux-release ] ; then
   vOSVerNum=100
   vOSDistribution="Alt Linux (apt-get compatible)"
   vMultiArchDirPlan=200

#------------ 100 Ubuntu----------------------------
 elif [ -f /etc/lsb-release  ] ; then
   vOSVerNum=100
   vOSDistribution="Ubuntu Linux" 
   vMultiArchDirPlan=200

 case $(cat /etc/lsb-release) in 
   *Mageia*)   
     vOSVerNum=775
     vOSDistribution="Mageia Linux"
     vMultiArchDirPlan=100
    ;; 
    *ubuntu*)   
     vOSVerNum=100
     vOSDistribution="Ubuntu Linux" 
     vMultiArchDirPlan=200
    ;; 
   *)
     vOSVerNum=100
     vOSDistribution="Ubuntu Linux" 
     vMultiArchDirPlan=200
   ;;    
  esac   
  
#------------ 300 Debian ---------------------------             
 elif [ -f /etc/debian_version ] ; then
   vOSVerNum=300
   vOSDistribution="Debian Linux"   
   vMultiArchDirPlan=200            
 elif [ -f /etc/knoppix_version ] ; then
   vOSVerNum=300
   vOSDistribution="Knoppix Linux" 
   vMultiArchDirPlan=200 

#------------ 200 SuSE------------------------------            
 elif [ -f /etc/SuSE-release ] ; then
   vOSVerNum=200
   vOSDistribution="SuSE Linux"  
   vMultiArchDirPlan=100                   
 elif [ -f /etc/novell-release ] ; then
   vOSVerNum=200
   vOSDistribution="SuSE Linux"    
   vMultiArchDirPlan=100                  
 elif [ -f /etc/sles-release ] ; then
   vOSVerNum=200
   vOSDistribution="SUSE Linux ES9"  
   vMultiArchDirPlan=100                   
 elif [ -f /etc/nld-release ] ; then
   vOSVerNum=200
   vOSDistribution="Novell Linux Desktop" 
   vMultiArchDirPlan=100                   
 elif [ -f /etc/UnitedLinux-release ] ; then
   vOSVerNum=200
   vOSDistribution="UnitedLinux"  
   vMultiArchDirPlan=100                   
 elif [ -f /etc/os-release ] ; then
   vOSVerNum=200
   vOSDistribution="openSUSE Tumbleweed"  
   vMultiArchDirPlan=100   
 
fi 

}

#================== Find FreeBSD Distribution ==========
FindDistributionFreeBSD()
{    
vOSVerNum=2000
vOSDistribution="FreeBSD"  
vMultiArchDirPlan=1000  
}

#================== Find OpenBSD Distribution ==========
FindDistributionOpenBSD()
{
vOSVerNum=3000
vOSDistribution="OpenBSD"
vMultiArchDirPlan=1000 
}

#================== Find NetBSD Distribution ===========
FindDistributionNetBSD()
{
vOSVerNum=4000
vOSDistribution="NetBSD"
vMultiArchDirPlan=1000  
}

#================== Find DragonFly Distribution ========
FindDistributionDragonFly()
{
vOSVerNum=4500
vOSDistribution="DragonFly"
vMultiArchDirPlan=1000  
}

#================== Find Solaris Distribution ==========
FindDistributionSolaris()
{

case $(uname -a) in 
 *openindiana*)    
    vOSVerNum=5100
    vOSDistribution="OpenIndiana"
    vMultiArchDirPlan=5000  
   ;; 
 *)
    vOSVerNum=5000
    vOSDistribution="Solaris"
    vMultiArchDirPlan=5000  
   ;;    
esac

}

#================== Find Darwin Distribution ==========
FindDistributionDarwin()
{
vOSVerNum=6000
vOSDistribution="Darwin"
vMultiArchDirPlan=6000  
}

#============= Get MultiArch Plan ============================

GetMultiArchPlan()
{

case $vMultiArchDirPlan in

# --- RedHat, Suse, Fedora, Mageia, etc-------
  100)   
     if [ $vHostBits = 64 ] ;
      then    
        if [ $vBits = 64 ] ;
          then 
            vOSBinSub=bin
            vOSLocalBinSub=bin        
            vOSLibSub=lib64
            vOSLocalLinSub=lib64
          else 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib
            vOSLocalLinSub=lib
          fi   
      else 
        vOSBinSub=bin
        vOSLocalBinSub=bin 
        vOSLibSub=lib
        vOSLocalLinSub=lib
      fi  
   ;;

# --- Debian, Ubuntu, PcLinuxOS, etc-------
  200)   
     if [ $vHostBits = 64 ] ;
      then    
        if [ $vCPU = aarch64 ] ;
          then 

           if [ $vBits = 64 ] ;
            then 
              vOSBinSub=bin
              vOSLocalBinSub=bin 
              vOSLibSub=lib/aarch64-linux-gnu
              vOSLocalLinSub=lib
            else 
              vOSBinSub=bin
              vOSLocalBinSub=bin 
              vOSLibSub=lib/arm-linux-gnueabihf
              vOSLocalLinSub=lib
            fi     
            
          else 

            if [ $vBits = 64 ] ;
            then 
              vOSBinSub=bin
              vOSLocalBinSub=bin 
              vOSLibSub=lib/x86_64-linux-gnu
              vOSLocalLinSub=lib
            else 
              vOSBinSub=bin
              vOSLocalBinSub=bin 
              vOSLibSub=lib/i386-linux-gnu
             vOSLocalLinSub=lib
           fi  

       fi  
 
      else 
        if [ $vCPU = arm ] ;
          then 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib/arm-linux-gnueabihf
            vOSLocalLinSub=lib
          else 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib/i386-linux-gnu
            vOSLocalLinSub=lib
          fi         
      fi  
   ;;

# --- ArchLinux, Manjaro etc-------
  300)   
     if [ $vHostBits = 64 ] ;
      then    
        if [ $vBits = 64 ] ;
          then 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib
            vOSLocalLinSub=lib
          else 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib32
            vOSLocalLinSub=lib
          fi   
      else 
        vOSBinSub=bin
        vOSLocalBinSub=bin 
        vOSLibSub=lib
        vOSLocalLinSub=lib
      fi  
   ;;

# --- Gentoo, Sabayon etc-------
# has lib32 and lib64, lib link to lib64
  400)   
     if [ $vHostBits = 64 ] ;
      then    
        if [ $vBits = 64 ] ;
          then 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib
            vOSLocalLinSub=lib
          else 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib32
            vOSLocalLinSub=lib32
          fi   
      else 
        vOSBinSub=bin
        vOSLocalBinSub=bin 
        vOSLibSub=lib
        vOSLocalLinSub=lib
      fi  
   ;;

# --- Slackware, slackel, Salix, Porteus, VectorLinux etc-------
  500)   
     if [ $vHostBits = 64 ] ;
      then    
        if [ $vBits = 64 ] ;
          then 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib64
            vOSLocalLinSub=lib64
          else 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib
            vOSLocalLinSub=lib
          fi   
      else 
        vOSBinSub=bin
        vOSLocalBinSub=bin 
        vOSLibSub=lib
        vOSLocalLinSub=lib
      fi  
   ;;

# --- FreeBSD, OpenBSD, NetBSD, DragonFly ----------------
  1000)   
     if [ $vHostBits = 64 ] ;
      then    
        if [ $vBits = 64 ] ;
          then 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib
            vOSLocalLinSub=lib
          else 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib32
            vOSLocalLinSub=lib32
          fi   
      else 
        vOSBinSub=bin
        vOSLocalBinSub=bin 
        vOSLibSub=lib
        vOSLocalLinSub=lib
      fi  
   ;;

# --- Solaris -------------------
  5000)   
     if [ $vHostBits = 64 ] ;
      then    
        if [ $vBits = 64 ] ;
          then 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib
            vOSLocalLinSub=lib
          else 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib
            vOSLocalLinSub=lib
          fi   
      else 
        vOSBinSub=bin
        vOSLocalBinSub=bin 
        vOSLibSub=lib
        vOSLocalLinSub=lib
      fi  
   ;;

# --- MACOSX ----------------
  6000)    
     if [ $vHostBits = 64 ] ;
      then    
        if [ $vBits = 64 ] ;
          then 
            vOSBinSub=/local/bin
            vOSLocalBinSub=bin 
            vOSLibSub=/local/lib
            vOSLocalLinSub=lib
          else 
            vOSBinSub=/local/bin
            vOSLocalBinSub=bin 
            vOSLibSub=/local/lib
            vOSLocalLinSub=lib
          fi   
      else 
        vOSBinSub=/local/bin
        vOSLocalBinSub=bin 
        vOSLibSub=/local/lib
        vOSLocalLinSub=lib
      fi  
   ;;

# --------------Default any other ----------
  *)    
     if [ $vHostBits = 64 ] ;
      then    
        if [ $vBits = 64 ] ;
          then 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib
            vOSLocalLinSub=lib
          else 
            vOSBinSub=bin
            vOSLocalBinSub=bin 
            vOSLibSub=lib
            vOSLocalLinSub=lib
          fi   
      else 
        vOSBinSub=bin
        vOSLocalBinSub=bin 
        vOSLibSub=lib
        vOSLocalLinSub=lib
      fi  
   ;;
esac

}


#============= Get CodeTyphon Default OS MultiArch =====================

GetDefaultOSMultiArch()
{

vUseMultiArch=0 
      
case $(uname) in
  SunOS)
      
      if [ $(isainfo -b) = "64" ] ; 
      then         
         vUseMultiArch=1
      fi
   ;;
   
#  Darwin)     
#      if [ $(uname -m) = "x86_64" ] ; 
#      then         
#         vUseMultiArch=1
#      fi  
#   ;;

esac

}

#====================== Find LCLPlatform ======================================

FindLCLPlatform() 
{
# vLCLplat=0  for GTK2
# vLCLplat=1  for QT4
# vLCLplat=3  for GTK3
# vLCLplat=4  for customdrawn
# vLCLplat=5  for Carbon
# vLCLplat=6  for Cocoa
# vLCLplat=7  for QT5
# vLCLplat=8  for fpGUI
# vLCLplat=9  for GTK4

vLCLplat=0

# Default for MacOS is Cocoa
if [ $vOSName = darwin ] ;
then 
 vLCLplat=6
fi

# Default for Chakra Linux is QT5
if [ -f /etc/chakra-release ] ; 
then   
  vLCLplat=7
fi

# Default for KaOS Linux is QT5
if [ -f /etc/KaOS-release ] ; 
then   
  vLCLplat=7
fi

#------------ Set from Files ----------------

# If CTC Settings Use QT4
if [ -f $vCTDir/Settings/CT_Use_QT4.ctsw ] ; 
then   
  vLCLplat=1
fi
# If CTC Settings Use GTK2
if [ -f $vCTDir/Settings/CT_Use_GTK2.ctsw ] ; 
then   
  vLCLplat=0
fi
# If CTC Settings Use GTK3
if [ -f $vCTDir/Settings/CT_Use_GTK3.ctsw ] ; 
then   
  vLCLplat=3
fi
# If CTC Settings Use CustomDrawn
if [ -f $vCTDir/Settings/CT_Use_CustomDrawn.ctsw ] ; 
then   
  vLCLplat=4
fi
# If CTC Settings Use Carbon
if [ -f $vCTDir/Settings/CT_Use_Carbon.ctsw ] ; 
then   
  vLCLplat=5
fi
# If CTC Settings Use QT5
if [ -f $vCTDir/Settings/CT_Use_QT5.ctsw ] ; 
then   
  vLCLplat=7
fi
# If CTC Settings Use fpGUI
if [ -f $vCTDir/Settings/CT_Use_fpGUI.ctsw ] ; 
then   
  vLCLplat=8
fi
# If CTC Settings Use GTK4
if [ -f $vCTDir/Settings/CT_Use_GTK4.ctsw ] ; 
then   
  vLCLplat=9
fi

#------ lclplatform String ---

case $vLCLplat in
0)
  vLCLPlatStr=gtk2 
 ;;
1)
   vLCLPlatStr=qt4
 ;;
3)
   vLCLPlatStr=gtk3
 ;;
4)
   vLCLPlatStr=customdrawn
 ;;
5)
   vLCLPlatStr=carbon
 ;;
6)
   vLCLPlatStr=cocoa
 ;;
7)
   vLCLPlatStr=qt5
 ;;
8)
   vLCLPlatStr=fpgui
 ;;
9)
   vLCLPlatStr=gtk4
 ;;
esac  

}

#======================= FindOtherValues ======================

FindOtherValues() 
{

vOSBinDir=/usr/$vOSBinSub
vOSLibDir=/usr/$vOSLibSub
vOSLocalBinDir=/usr/local/$vOSLocalBinSub
vOSLocalLinDir=/usr/local/$vOSLocalLinSub

vFpcDir=$vCTDir/fpc
vFpcSrcDir=$vCTDir/fpcsrc
vFpcBitsDir=$vCTDir/fpc/fpc$vBits
vFpcBinDir=$vFpcBitsDir/bin
vFpcUnitsDir=$vFpcBitsDir/units
vFpcExeDir=$vFpcBinDir/$vCPUOS
vFpcCfgDir=$vFpcExeDir

vTyphonDir=$vCTDir/typhon
vTyphonSetDir=~/.typhon$vBits

#--- 7zip --------------------------------

v7zipexe=${vCTDir}/binBase/${vHostCPUOS}/7zr

if [ -f $vOSBinDir/7za ] ;
then  
   v7zipexe=$vOSBinDir/7za
fi

if [ -f /usr/bin/7za ] ;
then  
   v7zipexe=/usr/bin/7za
fi

if [ -f /usr/local/bin/7za ] ;
then  
   v7zipexe=/usr/local/bin/7za
fi

if [ -f /usr/pkg/bin/7za ] ;
then  
   v7zipexe=/usr/pkg/bin/7za
fi

#------------

if [ -f $vOSBinDir/7zr ] ;
then  
   v7zipexe=$vOSBinDir/7zr
fi

if [ -f /usr/bin/7zr ] ;
then  
   v7zipexe=/usr/bin/7zr
fi

if [ -f /usr/local/bin/7zr ] ;
then  
   v7zipexe=/usr/local/bin/7zr
fi

if [ -f /usr/pkg/bin/7zr ] ;
then  
   v7zipexe=/usr/pkg/bin/7zr
fi

#--- wget -------------------------------

if [ -f $vOSBinDir/wget ] ;
then  
   vwgetexe=$vOSBinDir/wget
elif [ -f $vOSLocalBinDir/wget ] ; then
   vwgetexe=$vOSLocalBinDir/wget
   
elif [ -f /usr/bin/wget ] ; then
   vwgetexe=/usr/bin/wget
   
elif [ -f /usr/local/bin/wget ] ; then
   vwgetexe=/usr/local/bin/wget
   
elif [ -f /usr/pkg/bin/wget ] ; then
   vwgetexe=/usr/pkg/bin/wget
   
else
   vwgetexe=${vCTDir}/binBase/${vHostCPUOS}/wget
fi

#-------- Current User staff -------


vctuser=$(whoami)
vctuserhome=~/
vctuserdesk=~/Desktop

vccurdesk=$XDG_CURRENT_DESKTOP
vccurgdmsession=$GDMSESSION
vccurdesksession=$DESKTOP_SESSION
 

#------------------------------------  

FindLCLPlatform

vCPUOSPlat=${vCPUOS}-${vLCLPlatStr}

}

#====================== setdummy32 =============================

setdummy32()
{

vBits=32
vUseMultiArch=0
vFpcExeFile=ppc386

case $vHostOSRealName in
  Linux)  

     if [ $vHostOSRealArch = "aarch64" ] ; 
      then 
         vHostBits=32
         vBits=32
         vOSNameBits=linux32  
         vCPU=arm
         vCPUOS=arm-linux
         vFpcExeFile=ppcarm          
      else    
         vHostBits=32
         vBits=32
         vOSNameBits=linux32  
         vCPU=i386
         vCPUOS=i386-linux
         vFpcExeFile=ppc386    
      fi 
   
   ;;
  FreeBSD)    
      vOSName=freebsd      
      vOSNameBits=freebsd32
      vCPU=i386
      vCPUOS=i386-freebsd   
      FindDistributionFreeBSD      
   ;;
  OpenBSD) 
      vOSName=openbsd     
      vOSNameBits=openbsd32 
      vCPU=i386    
      vCPUOS=i386-openbsd 
      FindDistributionOpenBSD        
   ;;
  NetBSD) 
      vOSName=netbsd      
      vOSNameBits=netbsd32
      vCPU=i386
      vCPUOS=i386-netbsd 
      FindDistributionNetBSD  
   ;;
  DragonFly) 
      vOSName=dragonfly     
      vOSNameBits=dragonfly32
      vCPU=i386
      vCPUOS=i386-dragonfly 
      FindDistributionDragonFly  
   ;;
  SunOS)
      vOSName=solaris    
      vOSNameBits=solaris32
      vCPU=i386
      vCPUOS=i386-solaris  
      FindDistributionSolaris     
   ;;
  Darwin)
      vOSName=darwin    
      vOSNameBits=darwin32
      vCPU=i386
      vCPUOS=i386-darwin  
      FindDistributionDarwin    
   ;;
esac

GetMultiArchPlan   

FindOtherValues

}

#======================= getvalues =======================================

getvalues()
{
#---------------------------------
vOSVerNum=1
vOSDistribution="Sorry, Unknow OS ???" 

vOSBinSub=bin
vOSLibSub=lib
vOSLocalBinSub=bin
vOSLocalLinSub=lib

vOSAppDskDir=/usr/share/applications
vOSAppXmlDir=/usr/share/mime/packages
vOSAppPngDir=/usr/share/pixmaps

vCTDir=/usr/local/codetyphon

vUseMultiArch=0      
vBits=32
vMake=make
vCPU=i386
vCPUOS=i386-linux
vFpcExeFile=ppc386

vFpcVer=3.3.1

vHostOSRealName=$(uname) 
      
case $vHostOSRealName in
  Linux)      
      vOSName=linux       
      vMake=make 
      vOSAppDskDir=/usr/share/applications
      vOSAppXmlDir=/usr/share/mime/packages
      vOSAppPngDir=/usr/share/pixmaps
      
      vHostOSRealArch=$(uname -m)
      
      if [ $vHostOSRealArch = "x86_64" ] ; 
      then            
         vHostBits=64
         vBits=64
         vOSNameBits=linux64
         vCPU=x86_64
         vCPUOS=x86_64-linux
         vFpcExeFile=ppcx64
      elif [ $vHostOSRealArch = "aarch64" ] ; 
      then        
         vHostBits=64
         vBits=64
         vOSNameBits=linux64
         vCPU=aarch64
         vCPUOS=aarch64-linux
         vFpcExeFile=ppca64
      elif [ $vHostOSRealArch = "armv7l" ] ; 
      then   
         vHostBits=32
         vBits=32
         vOSNameBits=linux32  
         vCPU=arm
         vCPUOS=arm-linux
         vFpcExeFile=ppcarm          
      else    
         vHostBits=32
         vBits=32
         vOSNameBits=linux32  
         vCPU=i386
         vCPUOS=i386-linux
         vFpcExeFile=ppc386       
      fi       
      FindDistributionLinux  
   ;;
  FreeBSD)    
      vOSName=freebsd        
      vMake=gmake
      vOSAppDskDir=/usr/local/share/applications
      vOSAppXmlDir=/usr/local/share/mime/packages
      vOSAppPngDir=/usr/local/share/pixmaps
      
      vHostOSRealArch=$(uname -m)
      
      if [ $vHostOSRealArch = "amd64" ] ; 
      then  
         vHostBits=64
         vBits=64
         vOSNameBits=freebsd64
         vCPU=x86_64
         vCPUOS=x86_64-freebsd
         vFpcExeFile=ppcx64    
      else
         vHostBits=32
         vBits=32
         vOSNameBits=freebsd32 
         vCPU=i386
         vCPUOS=i386-freebsd
         vFpcExeFile=ppc386       
      fi      
      FindDistributionFreeBSD
   ;;
  OpenBSD) 
      vOSName=openbsd        
      vMake=gmake
      vOSAppDskDir=/usr/local/share/applications
      vOSAppXmlDir=/usr/local/share/mime/packages
      vOSAppPngDir=/usr/local/share/pixmaps
      
      vHostOSRealArch=$(uname -m)
      
      if [ $vHostOSRealArch = "amd64" ] ; 
      then  
         vHostBits=64
         vBits=64
         vOSNameBits=openbsd64
         vCPU=x86_64
         vCPUOS=x86_64-openbsd
         vFpcExeFile=ppcx64    
      else
         vHostBits=32
         vBits=32
         vOSNameBits=openbsd32 
         vCPU=i386
         vCPUOS=i386-openbsd
         vFpcExeFile=ppc386       
      fi
      FindDistributionOpenBSD 
   ;;
  NetBSD) 
      vOSName=netbsd        
      vMake=gmake
      vOSAppDskDir=/usr/pkg/share/applications
      vOSAppXmlDir=/usr/pkg/share/mime/packages
      vOSAppPngDir=/usr/pkg/share/pixmaps
      
      vHostOSRealArch=$(uname -m)
      
      if [ $vHostOSRealArch = "amd64" ] ; 
      then        
         vHostBits=64
         vBits=64
         vOSNameBits=netbsd64
         vCPU=x86_64
         vCPUOS=x86_64-netbsd
         vFpcExeFile=ppcx64   
      else
         vHostBits=32
         vBits=32
         vOSNameBits=netbsd32 
         vCPU=i386
         vCPUOS=i386-netbsd
         vFpcExeFile=ppc386  
      fi
      FindDistributionNetBSD  
   ;;
  DragonFly) 
      vOSName=dragonfly        
      vMake=gmake
      vOSAppDskDir=/usr/local/share/applications
      vOSAppXmlDir=/usr/local/share/mime/packages
      vOSAppPngDir=/usr/local/share/pixmaps
      
      vHostOSRealArch=$(uname -m)
      
      if [ $vHostOSRealArch = "x86_64" ] ; 
      then 
         vHostBits=64
         vBits=64
         vOSNameBits=dragonfly64
         vCPU=x86_64
         vCPUOS=x86_64-dragonfly
         vFpcExeFile=ppcx64     
      else
         vHostBits=32
         vBits=32
         vOSNameBits=dragonfly32 
         vCPU=i386
         vCPUOS=i386-dragonfly
         vFpcExeFile=ppc386      
      fi
      FindDistributionDragonFly  
   ;;
  SunOS)
      vOSName=solaris        
      vMake=gmake 
      vOSAppDskDir=/usr/share/applications
      vOSAppXmlDir=/usr/share/mime/packages
      vOSAppPngDir=/usr/share/pixmaps
      
      vHostOSRealArch=$(isainfo -b)
      
      if [ $vHostOSRealArch = "64" ] ; 
      then   
         vHostBits=64
         vBits=64
         vOSNameBits=solaris64
         vCPU=x86_64
         vCPUOS=x86_64-solaris
         vFpcExeFile=ppcx64 
         vUseMultiArch=1 
      else
         vHostBits=32
         vBits=32
         vOSNameBits=solaris32 
         vCPU=i386
         vCPUOS=i386-solaris
         vFpcExeFile=ppc386       
      fi
      FindDistributionSolaris 
   ;;
  Darwin)
      vOSName=darwin    
      vMake=/usr/local/bin/gmake 
      vOSAppDskDir=/Applications
      vOSAppXmlDir=/Applications
      vOSAppPngDir=/Applications
      
      vHostOSRealArch=$(uname -m)
      
      if [ $vHostOSRealArch = "x86_64" ] ; 
      then   
         vHostBits=64
         vBits=64
         vOSNameBits=darwin64 
         vCPU=x86_64
         vCPUOS=x86_64-darwin
         vFpcExeFile=ppcx64
         vUseMultiArch=1           
      else  
         vHostBits=32
         vBits=32
         vOSNameBits=darwin32   
         vCPU=i386
         vCPUOS=i386-darwin
         vFpcExeFile=ppc386                       
      fi       
      FindDistributionDarwin 
   ;;
esac

#-------------------------------------
# Check file in Settings directory

if [ -f $vCTDir/Settings/CT_If_Use_MultiArch.ctsw ] ; 
then   
  vUseMultiArch=1
else
  vUseMultiArch=0
fi

# 32bit OS always is NO MultiArch

if [ $vHostBits = 32 ] ; 
then
  vUseMultiArch=0
fi
  
GetMultiArchPlan   
   
#---------------------------------------

vCTDir=/usr/local/codetyphon

vHostCPUOS=$vCPUOS
vHostBinSub=$vOSBinSub
vHostLibSub=$vOSLibSub
vHostLocalBinSub=$vOSBinSub
vHostLocalLinSub=$vOSLibSub

FindOtherValues

#--------------------------------------

if [ $vHostBits = 32 ] ;
then 
 vUseMultiArch=0
fi

}