# ctusersctript:System Info
# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

# Annvix (Mandriva): /etc/annvix-release 

# Fedora Core (Fedora): /etc/fedora-release
# Aurox Linux (Fedora): /etc/aurox-release
# BlackCat (Fedora): /etc/blackcat-release
# Yellow Dog (Fedora): /etc/yellowdog-release
# Tiny Sofa (Fedora): /etc/tinysofa-release
# SME Server (Formerly E-Smith) (Fedora): /etc/e-smith-release
# -----
# Red Hat: /etc/redhat-release, /etc/redhat_version (rare)
# Immunix (Red Hat): /etc/immunix-release
# -----
# Debian: /etc/debian_version, /etc/debian_release (rare)
# Ubuntu Linux (Debian): /etc/lsb-release
# Knoppix (Debian): knoppix_version
# -----
# SUSE Linux: /etc/SuSE-release, /etc/novell-release
# SUSE Linux ES9: /etc/sles-release
# Novell Linux Desktop (openSUSE): /etc/nld-release
# UnitedLinux (openSUSE): /etc/UnitedLinux-release (covers SUSE SLES8)
# -----
# Cobalt: /etc/cobalt-release
# Conectiva (Independent): /etc/conectiva-release
# Gentoo Linux (Independent): /etc/gentoo-release
# Linux-From-Scratch (Independent): /etc/lfs-release
# Linux-PPC: /etc/linuxppc-release
# Mandrake: /etc/mandrake-release
# Mandriva/Mandrake Linux: /etc/mandriva-release, /etc/mandrake-release, /etc/mandakelinux-release
# MkLinux: /etc/mklinux-release
# PLD Linux (Independent): /etc/pld-release
# Slackware (Independent): /etc/slackware-version, /etc/slackware-release (rare)
# Solaris SPARC: /etc/release
# Sun JDS: /etc/sun-release
# TurboLinux (Independent): /etc/turbolinux-release
# UltraPenguin: /etc/ultrapenguin-release
# VA-Linux/RH-VALE: /etc/va-release
# Arch Linux (Independent): /etc/arch-release
# Arklinux (Independent): /etc/arklinux-release

# cat /etc/*-release 

# =========================Main================================= 
. $PWD/ln_All_Functions.sh
getvalues

#  =====================================================

echo "   "
echo "==================================================="
echo "           CodeTyphon Host OS Info"
echo "==================================================="
 
echo "Found:  $vOSDistribution  (OS ID:$vOSVerNum)"
echo "HostOSRealName : $vHostOSRealName"
echo "User Name      : $vctuser"

if [ -d $vctuserhome ] ;
then  
  echo "User Home Dir  : $vctuserhome"
else  
  echo "User Home Dir  : ???????????"
fi 

if [ -d $vctuserdesk ] ;
then  
  echo "User Desk Dir  : $vctuserdesk"
else  
  echo "User Desk Dir  : ???????????"
fi

echo "   "
echo "HostBits       : $vHostBits"
echo "HostCPUOS      : $vHostCPUOS"
echo "HostBinSub     : $vHostBinSub"
echo "HostLibSub     : $vHostLibSub"
echo "HostLocalBinSub: $vHostLocalBinSub"
echo "HostLocalLinSub: $vHostLocalLinSub"
echo "   "
echo "MultiArch mode : $vUseMultiArch"
echo "   "
echo "Desktop        : $vccurdesk"
echo "Desktop Session: $vccurdesksession"
echo "GDM Session    : $vccurgdmsession"
echo "   "

dothejob()
{
echo "------- for Arch $vBits ------ "
echo "OSName          : $vOSName"
echo "OSNameBits      : $vOSNameBits"
echo "Bits            : $vBits"
echo "CPU             : $vCPU"
echo "CPU-OS          : $vCPUOS"
echo "CPU-OS-Platform : $vCPUOSPlat"
echo "..... "
echo "OSBinDir        : $vOSBinDir"
echo "OSLibDir        : $vOSLibDir"
echo "OSLocalBinDir   : $vOSLocalBinDir"
echo "OSLocalLinDir   : $vOSLocalLinDir"
echo "OSAppDskDir     : $vOSAppDskDir"
echo "OSAppXmlDir     : $vOSAppXmlDir"
echo "OSAppPngDir     : $vOSAppPngDir"
echo "CTDir           : $vCTDir"
echo "..... "
echo "fpcver      : $vFpcVer"
echo "fpcFile     : $vFpcExeFile"
echo "make        : $vMake"
echo "FpcSrcDir   : $vFpcSrcDir"
echo "FpcDir      : $vFpcDir"
echo "FpcCPUOSDir : $vFpcBitsDir"
echo "FpcBinDir   : $vFpcBinDir"
echo "FpcUnitsDir : $vFpcUnitsDir"
echo "FpcExeDir   : $vFpcExeDir"
echo "FpcCfgDir   : $vFpcCfgDir"
echo "..... "
echo "7zip : $v7zipexe"
echo "wget : $vwgetexe"
echo "   "
}

dothejob 

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob  
fi


echo "---------------------------------- "
echo "   "
#-----------------------------------------------------
if [ $(id -u) = 0 ]; then
 echo "[WARNING]: CTCenter run for root or sudo user, this is NOT correct...?????"
else
 echo "[INFO]: CTCenter run for normal user, all OK"
fi  

echo "   "
echo "============== OS/Distribution Info ==============="
echo "   "
uname -a

if [ $vOSName = solaris ] ;
then 
  echo "   "
  isainfo -v
fi

if [ $vOSName = linux ] ;
then 
  echo "   "
  cat /etc/*-release 
fi

echo "   "
echo "============== Utils Info ==============="
echo "   "
echo "-------------- make -------------"
$vMake -v

echo "   "
echo "-------------- wget -------------"
$vwgetexe --version

echo "   "
echo "-------------- gdb --------------"

if [ ! $vOSName = darwin ] ;
then
  gdb -v
fi 

if [ $vOSName = darwin ] ;
then 
  /usr/local/bin/ggdb -v
  echo "  "
  #.........Check codesign ggdb ............
  SIGNED="$(codesign -dv /usr/local/bin/ggdb 2>&1)"
  if [[ $SIGNED == *"object is not signed"* ]]
  then
    echo "[WARNING] gdb (/usr/local/bin/ggdb) is NOT currently code signed.????"
  else  
    echo "[INFO] gdb (/usr/local/bin/ggdb) has signed"
  fi  
fi

echo "   "
echo "-------------- gcc --------------"
gcc -v


exit