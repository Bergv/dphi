# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# ==============================================================

echo "=============================================================="
echo "    Remove and Build ALL (FreePascal, Typhon and CodeOcean)" 
echo "=============================================================="

./ln_xCodeTyphon_Remove_ALL.sh


./ln_FPC32_Build.sh
./ln_FPC64_Build.sh

./ln_Typhon32_Build.sh
./ln_Typhon64_Build.sh



 

