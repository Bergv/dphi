# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

echo "----------------------------------------------------------"
echo "     Remove ALL (FreePascal, Typhon and CodeOcean) " 
echo "----------------------------------------------------------"

echo "Step 1/2"
./ln_xCodeTyphon_Remove_FPC.sh

echo "Step 2/2"
./ln_xCodeTyphon_Remove_Typhon.sh


