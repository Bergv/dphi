# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#      This Script Install to OpenMandriva Linux 
#      base libraries to Build and Run CodeTyphon
# =============================================================
# Update 17-05-2014 for OpenMandriva Linux (OpenMandrivaLx-2014.0.x86_64.iso) MultiArch for QT4
# Update 20-07-2015 for OpenMandriva Linux (OpenMandrivaLx-2014.2.x86_64.iso) 
# Update 16-06-2019 for OpenMandrivaLx.4.0 Linux (OpenMandrivaLx.4.0-plasma.x86_64.iso) 
#        SOS OpenMandrivaLx.4.0 has DNF packages manager, NOT urpmi
#========================================================

ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for" 
echo "              OpenMandriva Linux" 
echo "----------------------------------------------------"
echo "   "

# --- OS Update  -----

echo "[INFO] Start OS Update..."
echo "   "
sudo dnf update -y 

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

sudo dnf install -y xterm 
sudo dnf install -y zip 
sudo dnf install -y unzip
sudo dnf install -y wget

sudo dnf install -y make 
sudo dnf install -y kernel-devel 
sudo dnf install -y kernel-headers 
sudo dnf install -y gcc 
sudo dnf install -y gcc-c++
sudo dnf install -y gdb 
sudo dnf install -y binutils 

sudo dnf install -y glib-devel 
sudo dnf install -y glibc-devel 
sudo dnf install -y libX11-devel
sudo dnf install -y libXtst
sudo dnf install -y libXtst-devel
sudo dnf install -y mesa-libGLU 
sudo dnf install -y libGL* 
sudo dnf install -y freeglut 
sudo dnf install -y xorg-x11-font*

if [ $ciUseMultiArch = 1 ] ; 
then
  sudo dnf install -y glib-devel.i686  
  sudo dnf install -y glibc-devel.i686  
  sudo dnf install -y libX11-devel.i686 
  sudo dnf install -y libXtst.i686 
  sudo dnf install -y libXtst-devel.i686
  sudo dnf install -y mesa-libGLU.i686
  sudo dnf install -y freeglut.i686   
fi

# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    sudo dnf install -y gtk2-devel 
    sudo dnf install -y gtk+extra 
    sudo dnf install -y gtk+-devel
    sudo dnf install -y cairo-devel 
    sudo dnf install -y cairo-gobject-devel
    sudo dnf install -y pango-devel 

    
    if [ $ciUseMultiArch = 1 ] ; 
    then
      sudo dnf install -y gtk2-devel.i686 
      sudo dnf install -y gtk+extra.i686  
      sudo dnf install -y gtk+-devel.i686 
      sudo dnf install -y cairo-devel.i686  
      sudo dnf install -y cairo-gobject-devel.i686 
      sudo dnf install -y pango-devel.i686    
    fi

fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT"
    echo "   "
            
    sudo dnf install -y qt-devel
    sudo dnf install -y qt-config  
    sudo dnf install -y qt4-devel  
    sudo dnf install -y qtwebkit.x86_64

    if [ $ciUseMultiArch = 1 ] ; 
    then
      sudo dnf install -y qt-devel.i686 
      sudo dnf install -y qtwebkit.i686   
    fi

fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo dnf install -y gtk3
    sudo dnf install -y gtk3-devel 

    if [ $ciUseMultiArch = 1 ] ; 
    then
      sudo dnf install -y gtk3.i686  
    fi 
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo dnf install -y gtk4
    sudo dnf install -y gtk4-devel 

    if [ $ciUseMultiArch = 1 ] ; 
    then
      sudo dnf install -y gtk4.i686  
    fi 
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo dnf install -y qt5-qtbase
    sudo dnf install -y qt5-qtbase-devel
    sudo dnf install -y qt5-qtx11extras
    sudo dnf install -y qt5-qtx11extras-devel
  

    if [ $ciUseMultiArch = 1 ] ; 
    then
      sudo dnf install -y qt5-qtbase.i686
      sudo dnf install -y qt5-qtbase-devel.i686
      sudo dnf install -y qt5-qtx11extras.i686
      sudo dnf install -y qt5-qtx11extras-devel.i686
    fi
fi
   
echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation" 
echo "Finish !!!"

#sleep 5
