# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{
# ===================== Build GDB ==================

cd /usr/local/codetyphon/CrossEng/gdb_src
  

if [ -d build ] ;
then     
    echo "[INFO]: Remove OLD temporary BUILD directory..."
    sudo rm -rf build
    echo "  "
fi

mkdir build
cd build
  
echo " "
echo "-------- configure -----------"
 
../configure --build=$buGDBbuildCPUOS --host=$buGDBhostCPUOS --target=$buGDBTargetCPUOS --prefix=/usr/local/codetyphon/CrossEng/gdbout \
--disable-nls 

echo " "
echo "-------- make ----------------"
make -j4

echo " "
echo "-------- make install --------"
make -j4 install

}

# =================== MAIN =============================

buPCBits=$1
buPCOS=$2
buPCCPUOS=$3
buGDBbuildCPUOS=$4
buGDBhostCPUOS=$5
buGDBTargetCPUOS=$6


echo "   "
echo "-----------------------------------------------"
echo "   GDB Build Engine Final settings"
echo "-----------------------------------------------"
echo "   "
echo $buPCBits
echo $buPCOS
echo $buPCCPUOS
echo $buGDBbuildCPUOS
echo $buGDBhostCPUOS
echo $buGDBTargetCPUOS
echo "   "

dothejob

