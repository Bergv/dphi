# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

if [ $bbTARGETCPUOS = $vHostCPUOS ] ;
then 
  exit
fi

echo "====================================================================="
echo "   BinUtils Build for $bbTARGETCPUOS Param:$bbParam"
echo "====================================================================="
echo "   "

# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ CrossEng @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

if [ ! -d $vCTDir/CrossEng ] ;
then      
    echo "   "
    echo "-------------------------------------------------------"
    echo "       Extract CrossBuild Engine..."
    echo "-------------------------------------------------------"
    echo "   "
    sudo mkdir $vCTDir/CrossEng
    sudo chmod -R 777 $vCTDir/CrossEng/
fi

# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ binutils @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

if [ -d $vCTDir/CrossEng/binutilsout ] ;
then     
    echo "[INFO]: Remove OLD BinUtils temporary OUT folder..."
    sudo rm -rf $vCTDir/CrossEng/binutilsout
fi
   
if [ ! -d $vCTDir/CrossEng/binutils ] ;
then   
sudo $v7zipexe x ../../allzips/src/binutils.7z -o$vCTDir/CrossEng/ -y
sudo chmod -R 777 $vCTDir/CrossEng/binutils/
fi

sudo mkdir $vCTDir/CrossEng/binutilsout
sudo chmod -R 777 $vCTDir/CrossEng/binutilsout/

# ===================== Build Binutils ==================
# if the script find CUSTOM ln_Cross_Binutils_xxxx.sh will execute this script..

if [ -f ln_Cross_Binutils_${bbTARGETCPU}_${bbTARGETOS}_${bbParam}.sh ] ; then  
 ./ln_Cross_Binutils_${bbTARGETCPU}_${bbTARGETOS}_${bbParam}.sh $bbFPCType $bbFPCCPUOS $bbFPCStartEXE $bbTARGETCPU $bbTARGETOS $bbFPCCrossEXE $bbParam

elif [ -f ln_Cross_Binutils_${bbTARGETCPU}_${bbTARGETOS}.sh ] ; then  
 ./ln_Cross_Binutils_${bbTARGETCPU}_${bbTARGETOS}.sh $bbFPCType $bbFPCCPUOS $bbFPCStartEXE $bbTARGETCPU $bbTARGETOS $bbFPCCrossEXE $bbParam

elif [ -f ln_Cross_Binutils_${bbTARGETOS}.sh ] ; then  
 ./ln_Cross_Binutils_${bbTARGETOS}.sh $bbFPCType $bbFPCCPUOS $bbFPCStartEXE $bbTARGETCPU $bbTARGETOS $bbFPCCrossEXE $bbParam

else
 ./ln_Cross_Binutils.sh $bbFPCType $bbFPCCPUOS $bbFPCStartEXE $bbTARGETCPU $bbTARGETOS $bbFPCCrossEXE $bbParam
fi

# ======================Check and Copy files to Toolchain Store ============

if [ -d $vCTDir/CrossEng/binutilsout/bin ] ;
then     

   sudo strip $vCTDir/CrossEng/binutilsout/bin/*

   sudo $bbFpcBinDir/$bbFPCCPUOS/upx $vCTDir/CrossEng/binutilsout/bin/* 
       
   sudo mkdir $vCTDir/binToolchains/${bbbincross} 

   sudo cp -f $vCTDir/CrossEng/binutilsout/bin/* $vCTDir/binToolchains/${bbbincross}
   sudo chmod -R 777 $vCTDir/binToolchains/${bbbincross}

   echo "------------------------------------------------"
   echo "   "
   echo "[FINAL INFO]: Toolschains for $bbTARGETCPUOS Param:$bbParam Build OK...!!!" 
   echo "   "
else
   echo "------------------------------------------------"
   echo "   "
   echo "??????????????????????????????????????????????????????????????????????"
   echo "[ERROR]: Sorry, Toolschains for $bbTARGETCPUOS Param:$bbParam NOT Build..." 
   echo "??????????????????????????????????????????????????????????????????????"
fi
 
}

# =================== MAIN =============================
. /usr/local/codetyphon/ScriptsLin/ln_All_Functions.sh
getvalues

bbFPCType=$1
bbFPCCPUOS=$2
bbFPCStartEXE=$3
bbTARGETCPU=$4
bbTARGETOS=$5
bbFPCCrossEXE=$6
bbParam=$7

bbTARGETCPUOS=${bbTARGETCPU}-${bbTARGETOS}

if [ $bbParam = xxxx ] ; 
then 
  bbbincross=${bbFPCType}-${bbTARGETCPUOS}
else
  bbbincross=${bbFPCType}-${bbTARGETCPUOS}--${bbParam}
fi

#---- for MultiArch Toolchains build ----

case $bbFPCType in 
 *32)
    bbFpcBinDir=$vCTDir/fpc/fpc32/bin
    ;; 
 *64)
    bbFpcBinDir=$vCTDir/fpc/fpc64/bin
    ;; 
 *)
    bbFpcBinDir=$vFpcBinDir
    ;;    
esac


#----------------------------------------

echo "   "
echo "-----------------------------------------------"
echo "   GNU Cross toolschains Engine settings"
echo "-----------------------------------------------"
echo "   "
echo $bbFPCType
echo $bbFPCCPUOS
echo $bbFPCStartEXE
echo $bbTARGETCPU
echo $bbTARGETOS
echo $bbFPCCrossEXE
echo $bbTARGETCPUOS
echo $bbParam
echo $bbbincross
echo $bbFpcBinDir
echo "   "

dothejob

