# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ CrossEng @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

if [ ! -d $vCTDir/CrossEng ] ;
then      
    echo "   "
    echo "-------------------------------------------------------"
    echo "       Extract CrossBuild Engine..."
    echo "-------------------------------------------------------"
    echo "   "
    sudo mkdir $vCTDir/CrossEng
    sudo chmod -R 777 $vCTDir/CrossEng/
fi

# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ GNU make @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

if [ -d $vCTDir/CrossEng/makeout ] ;
then     
    echo "[INFO]: Remove OLD GNU make temporary OUT directory..."
    sudo rm -rf $vCTDir/CrossEng/makeout
fi
  
if [ ! -d $vCTDir/CrossEng/make_src ] ;
then      
sudo $v7zipexe x ../../allzips/src/make_src.7z -o$vCTDir/CrossEng/ -y
sudo chmod -R 777 $vCTDir/CrossEng/make_src/
fi

sudo mkdir $vCTDir/CrossEng/makeout
sudo chmod -R 777 $vCTDir/CrossEng/makeout/

# ===================== Build GNU make Final ==================

./ln_GNUmake_Build_Final.sh $bbPCBits $bbPCOS $bbPCCPUOS $bbGDBbuildCPUOS $bbGDBhostCPUOS $bbGDBTargetCPUOS

# ================== Check and Strip GDB files ===========

if [ -f $vCTDir/CrossEng/makeout/bin/make ] ;
then

   echo "   "
   echo "-------------------------------------------------------"
   echo "   Strip GNU make Executable file..."
   echo "-------------------------------------------------------"
   echo "   "   
   
   sudo chmod -R 777 $vCTDir/CrossEng/makeout/bin
   sudo strip $vCTDir/CrossEng/makeout/bin/* 
   
   echo "------------------------------------------------"
   echo "   "
   echo "[FINAL INFO]: GNU make for Host=$bbMakhostCPUOS and Target=$bbMakTargetCPUOS Build OK...!!!" 
   echo "All GNU make Executable is in /usr/local/codetyphon/CrossEng/makeout/bin/ Directory"
   echo "   "
else
   echo "------------------------------------------------"
   echo "   "
   echo "??????????????????????????????????????????????????????????????????????"
   echo "[ERROR]: Sorry, GNU make for Host=$bbMakhostCPUOS and Target=$bbMakTargetCPUOS NOT Build..." 
   echo "??????????????????????????????????????????????????????????????????????"
fi
 
}

# =================== MAIN =============================
. /usr/local/codetyphon/ScriptsLin/ln_All_Functions.sh
getvalues

bbPCBits=$1
bbPCOS=$2
bbPCCPUOS=$3
bbMakbuildCPUOS=$4
bbMakhostCPUOS=$5
bbMakTargetCPUOS=$6

#----------------------------------------

echo "   "
echo "==============================================="
echo "        GNU make Build Engine Settings"
echo "==============================================="
echo "   "
echo $bbBits
echo $bbOS
echo $bbPCCPUOS
echo $bbMakbuildCPUOS
echo $bbMakhostCPUOS
echo $bbMakTargetCPUOS
echo "   "

dothejob
