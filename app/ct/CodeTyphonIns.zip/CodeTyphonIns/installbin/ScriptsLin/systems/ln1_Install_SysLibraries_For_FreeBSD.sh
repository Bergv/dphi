# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#     This Script Install to FreeBSD OS 
#     base libraries to Build and Run CodeTyphon
# =============================================================
# Update 05-12-2013 for FreeBSD 9.2
# Update 25-03-2014 for FreeBSD 10.0
# Update 10-12-2014 for FreeBSD 10.1
# Update 20-10-2016 for FreeBSD 11.0
# Update 08-11-2016 for GhostBSD 10.3
# Update 29-07-2017 for FreeBSD 11.1
# Update 18-08-2017 for TrueOS
# Update 29-06-2017 for FreeBSD 11.2
# Update 29-06-2018 for FreeBSD 11.3
# Update 14-12-2018 for FreeBSD 12.0
# Update 05-11-2019 for FreeBSD 12.1
# Update 19-05-2020 for GhostBSD 20.04.1
# Update 19-05-2020 for FuryBSD 12.1
# Update 15-04-2021 for FuryBSD 13.0
#========================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

# =============================================
# For FreeBSD ver 8.x and 9.x

doversion9()
{
echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for" 
echo "                FreeBSD 9.x" 
echo "----------------------------------------------------"
echo "   "


sudo /sbin/ldconfig -m -v

sudo pkg_add -r xterm
sudo pkg_add -r zip
sudo pkg_add -r unzip
sudo pkg_add -r wget
sudo pkg_add -r upx

sudo pkg_add -r gcc
sudo pkg_add -r gdb
sudo pkg_add -r binutils
sudo pkg_add -r gmake

sudo pkg_add -r iconv
sudo pkg_add -r xorg-libraries
sudo pkg_add -r libX11
sudo pkg_add -r libXtst

sudo pkg_add -r xorg-fonts-type1
sudo pkg_add -r liberation-fonts-ttf

# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    sudo pkg install -y gtkglext
fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo pkg_add -r qt4 
    sudo pkg_add -r qt4-qmake
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo pkg_add -r qt5 
    sudo pkg_add -r qt5-qmake
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo pkg_add -r gtk+-3.0
fi
}

# =============================================
# For FreeBSD ver 10.x - 13.x

doversion1x()
{
echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for" 
echo "                 FreeBSD"
echo "----------------------------------------------------"
echo "   "

# sudo pkg update 
# sudo pkg upgrade

sudo pkg install -y xterm
sudo pkg install -y zip 
sudo pkg install -y unzip 
sudo pkg install -y wget
sudo pkg install -y upx
sudo pkg install -y gcc
sudo pkg install -y gdb
sudo pkg install -y lldb
sudo pkg install -y binutils
sudo pkg install -y gmake
sudo pkg install -y iconv
sudo pkg install -y xorg-libraries
sudo pkg install -y libX11
sudo pkg install -y libXtst
sudo pkg install -y xorg-fonts-type1
sudo pkg install -y liberation-fonts-ttf

# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    sudo pkg install -y gtkglext
fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo pkg install -y qt4
    sudo pkg install -y qt4-moc
    sudo pkg install -y qt4-qmake
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo pkg install -y gtk3
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo pkg install -y gtk4
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo pkg install -y qt5
    sudo pkg install -y qt5-webkit
    sudo pkg install -y qt5-x11extras
    sudo pkg install -y qt5-qmake
fi

}

# =============================================
# =============================================
# =============================================

case $(uname -r) in 
 *8.*)
    doversion9
    ;; 
 *9.*)
    doversion9
    ;; 
 *)
    doversion1x
    ;;
    
esac


sudo /sbin/ldconfig -m -v

echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation"  
echo "Finish !!!"

#sleep 5