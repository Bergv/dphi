# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

# =================== stripfile =============================
stripfile() 
{

if [ -f $vCTDir/typhon/bin$vBits/$ctsstriptool ] ;
then   
  strip $vCTDir/typhon/bin$vBits/$ctsstriptool 
  echo "[INFO]: $vOSName $vBits $ctsstriptool executable Striped OK"
else
  echo "[ERROR]: $vOSName $vBits $ctsstriptool executable NOT Exists ???????"
fi

}

# =================== dothejob =============================
dothejob() 
{

if [ ! -d $vCTDir/typhon/bin$vBits ] ;
then 
  exit
fi

echo "   "
echo " -----------------------------------------------"
echo "              Strip Typhon$vBits Executables        "
echo " -----------------------------------------------"


ctsstriptool=typhon
stripfile

ctsstriptool=typhonstart
stripfile

ctsstriptool=typhonbuild
stripfile

ctsstriptool=ctres
stripfile

ctsstriptool=ctlrstofrm
stripfile

#------

ctsstriptool=ctchmbuilder
stripfile

ctsstriptool=ctchmviewer
stripfile

ctsstriptool=ctdatadesktop
stripfile

ctsstriptool=ctdiagramins
stripfile

ctsstriptool=cthexeditor
stripfile

ctsstriptool=ctimageeditor
stripfile

ctsstriptool=ctjsonviewer
stripfile

ctsstriptool=ctpobuilder
stripfile

ctsstriptool=ctresbuilder
stripfile

ctsstriptool=ctdoceditor
stripfile

ctsstriptool=ctdocbuilder
stripfile

ctsstriptool=ctunieditor
stripfile

ctsstriptool=ctschemaeditor
stripfile

ctsstriptool=ctdebugserver
stripfile

#--------------------

if [ -f $vCTDir/typhon/bin64/typhon.old ] ;
then   
  rm -f $vCTDir/typhon/bin64/typhon.old 
fi

if [ -f $vCTDir/typhon/typhon.old ] ;
then   
  rm -f $vCTDir/typhon/typhon.old 
fi
}
# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

cbStripingBits=$1

case $cbStripingBits in
  32)   
     if [ $vUseMultiArch = 1 ] ;
     then    
       setdummy32
       dothejob
     else
       dothejob
     fi
    ;;
  64)  
       dothejob    
    ;; 
  *)  
     if [ $vUseMultiArch = 1 ] ;
     then  
       dothejob  
       setdummy32
       dothejob
     else
       dothejob
     fi

    ;;
esac 




