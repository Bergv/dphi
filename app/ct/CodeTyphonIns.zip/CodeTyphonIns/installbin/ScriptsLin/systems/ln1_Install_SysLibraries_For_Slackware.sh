# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#      This Script Install to Slackware Linux 
#      base libraries to Build and Run CodeTyphon
# =============================================================
# Update 14-05-2014 for Slackware ver 14.1
# Update 07-03-2021 for Slackware ver 14.2 (release Date: 2016-07-01)
#========================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for" 
echo "              Slackware Linux" 
echo "----------------------------------------------------"
echo "   "

# ========================== slackpkg ==========================================
Use_slackpkg()
{
echo "[INFO] USE "slackpkg" OS Packages Manager..."
echo "   "
echo "[INFO] Start OS Update..."
echo "   "
sudo /usr/sbin/slackpkg update 

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

sudo /usr/sbin/slackpkg install xterm 
sudo /usr/sbin/slackpkg install zip 
sudo /usr/sbin/slackpkg install unzip
sudo /usr/sbin/slackpkg install wget

sudo /usr/sbin/slackpkg install make 
sudo /usr/sbin/slackpkg install gcc 
sudo /usr/sbin/slackpkg install gcc-c++ 
sudo /usr/sbin/slackpkg install gdb
sudo /usr/sbin/slackpkg install binutils 
sudo /usr/sbin/slackpkg install binutils-devel

sudo /usr/sbin/slackpkg install freetype2
sudo /usr/sbin/slackpkg install libx11-dev 
sudo /usr/sbin/slackpkg install libxtst-dev


# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    sudo /usr/sbin/slackpkg install gtkglext
fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo /usr/sbin/slackpkg install libqt4-dev 
    sudo /usr/sbin/slackpkg install qt4-qmake   
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo /usr/sbin/slackpkg install gtk+-3.0   
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo /usr/sbin/slackpkg install gtk+-4.0   
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo /usr/sbin/slackpkg install libqt5-dev 
    sudo /usr/sbin/slackpkg install qt5-qmake    
fi

}

# ====================== slapt-get ==============================================
Use_slapt-get()
{
echo "[INFO] USE "slapt-get" OS Packages Manager..."
echo "   "
echo "[INFO] Start OS Update..."
echo "   "
sudo slapt-get -y --upgrade

echo "[INFO] Start Libraries Installation..."
echo "   "

sudo slapt-get -y --install xterm 
sudo slapt-get -y --install zip 
sudo slapt-get -y --install unzip
sudo slapt-get -y --install wget

sudo slapt-get -y --install make 
sudo slapt-get -y --install gcc 
sudo slapt-get -y --install gcc-c++ 
sudo slapt-get -y --install gdb
sudo slapt-get -y --install binutils 
sudo slapt-get -y --install binutils-devel

sudo slapt-get -y --install freetype2
sudo slapt-get -y --install libx11-dev 
sudo slapt-get -y --install libXtst-dev


# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    sudo slapt-get -y --install gtkglext
fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo slapt-get -y --install libqt4-dev 
    sudo slapt-get -y --install qt4-qmake   
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo slapt-get -y --install gtk+-3.0   
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo slapt-get -y --install libqt5-dev 
    sudo slapt-get -y --install qt5-qmake    
fi

}

#==============================================================

 if [ -f /usr/sbin/slapt-get ] ; then
   Use_slapt-get
 elif [ -f /usr/sbin/slackpkg ] ; then
   slackpkg
 else
  echo "   "
  echo "[ERROR] Unknown OS Packages Manager ?????"
  echo "   " 
  
 fi


echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation" 
echo "Finish !!!"

#sleep 5
