# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#     This Script Install to Debian Linux 
#     base libraries to Build and Run CodeTyphon   
# =============================================================
# Update 25-11-2014 for Debian 7.7
# Update 04-07-2015 for Debian 8.0
# Update 25-07-2015 for Debian 8.0 MultiArch
# Update 10-04-2016 for Debian 8.4 MultiArch for GTK2, QT4 and QT5
# Update 16-10-2016 for Parrot Security OS 3.2 MultiArch for GTK2, QT4 and QT5
# Update 03-01-2017 for Debian SID (9.0) MultiArch for GTK2, QT4 and QT5
# Update 21-06-2017 for Debian 9.0 MultiArch for GTK2, QT4 and QT5
# Update 23-05-2018 for Debian 10.0 (SID) MultiArch and MultiPatform
# Update 09-06-2018 for MX Linux 17.1 MultiArch and MultiPatform
# Update 12-10-2018 for Debian 9.6 MultiArch and MultiPatform
# Update 21-12-2018 for MX Linux 18.0 MultiArch and MultiPatform
# Update 10-07-2019 for Debian 10.0 with MultiArch , MultiPlatform for GTK2, QT4 and QT5
# Update 20-09-2019 for Parrot Security OS 4.7
# Update 02-12-2019 for Debian 10.2 with MultiArch , MultiPlatform for GTK2, QT4 and QT5
# Update 16-02-2020 for Debian 10.3 with MultiArch , MultiPlatform for GTK2, QT4 and QT5
# Update 02-04-2020 for Devuan 3.0  with MultiArch , MultiPlatform for GTK2, QT4 and QT5
#========================================================

ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5


cisecondarch=i386

if [ $cicpuname = aarch64 ] ; 
then  
 cisecondarch=armhf
fi

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for"  
echo "              Debian Linux" 
echo "----------------------------------------------------"
echo "   "


if [ $ciUseMultiArch = 1 ] ;
then  
  echo "[INFO] Setup MultiArch OS..."

  sudo dpkg --add-architecture $cisecondarch

  echo "  Base OS Architecture:     $(dpkg --print-architecture)"
  echo "  Foreign OS Architectures: $(dpkg --print-foreign-architectures)"
  echo "   "
fi

echo "[INFO] Start OS Update..."
echo "   "
sudo apt-get update -y
sudo apt-get autoremove -y

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

# ------------Install libraries Common
sudo apt-get install -y xterm 
sudo apt-get install -y zip 
sudo apt-get install -y unzip 
sudo apt-get install -y wget 
sudo apt-get install -y alien
sudo apt-get install -y make 
sudo apt-get install -y gcc 
sudo apt-get install -y g++ 
sudo apt-get install -y build-essential
sudo apt-get install -y binutils
sudo apt-get install -y gdb
sudo apt-get install -y devscripts
sudo apt-get install -y libc6-dev

sudo apt-get install -y freeglut3-dev
sudo apt-get install -y libgl1-mesa 
sudo apt-get install -y libgl1-mesa-dev
sudo apt-get install -y libglu1-mesa
sudo apt-get install -y libglu1-mesa-dev
sudo apt-get install -y libgpmg1-dev
sudo apt-get install -y libsdl-dev
sudo apt-get install -y libXxf86vm-dev
sudo apt-get install -y libxtst-dev
sudo apt-get install -y libx11-dev
  
sudo apt-get install -y libxft2
sudo apt-get install -y libfontconfig1

# Install Courier fonts
sudo apt-get install -y xfonts-scalable
# sudo apt-get install -y ttf-mscorefonts-installer


if [ $ciUseMultiArch = 1 ] ; 
then  
  sudo apt-get install -y libc6-dev-$cisecondarch
  sudo apt-get install -y lib32gcc1
  sudo apt-get install -y gcc-multilib
  sudo apt-get install -y lib32stdc++6
  sudo apt-get install -y g++-multilib

  sudo apt-get install -y libc6-dev:$cisecondarch
  sudo apt-get install -y libxtst-dev:$cisecondarch
  sudo apt-get install -y freeglut3:$cisecondarch
  sudo apt-get install -y libgl1-mesa:$cisecondarch
  sudo apt-get install -y libgl1-mesa-dev:$cisecondarch
  sudo apt-get install -y libglu1-mesa:$cisecondarch
  sudo apt-get install -y libglu1-mesa-dev:$cisecondarch
  sudo apt-get install -y libxtst6:$cisecondarch
  sudo apt-get install -y libx11-6:$cisecondarch
  sudo apt-get install -y libxmu-dev:$cisecondarch
  sudo apt-get install -y libxxf86vm1:$cisecondarch
  
  sudo apt-get install -y libxft2:$cisecondarch
  sudo apt-get install -y libfontconfig1:$cisecondarch
fi

# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    
   if [ $ciUseMultiArch = 1 ] ;
   then  
      sudo apt-get install -y libglib2.0:$cisecondarch
      sudo apt-get install -y libgtk2.0:$cisecondarch
      sudo apt-get install -y libgtk2.0-0:$cisecondarch
      sudo apt-get install -y gtk2-engines-pixbuf:$cisecondarch
      sudo apt-get install -y libcairo2:$cisecondarch
   fi

    sudo apt-get install -y libglib2.0-dev
    sudo apt-get install -y libgtk2.0-0-dev
    sudo apt-get install -y libgtk2.0-dev
    sudo apt-get install -y gtk2-engines-pixbuf
    sudo apt-get install -y libcairo2-dev

fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo apt-get install -y libqt4-dev
    sudo apt-get install -y libqtwebkit-dev
    sudo apt-get install -y qt4-qmake


   if [ $ciUseMultiArch = 1 ] ; 
   then  
      sudo apt-get install -y libqt4-dev:$cisecondarch
      sudo apt-get install -y libqtwebkit-dev:$cisecondarch
   fi 
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo apt-get install -y gtk+-3.0


   if [ $ciUseMultiArch = 1 ] ; 
   then
      sudo apt-get install -y libgtk-3-0:$cisecondarch
   fi
 
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo apt-get install -y gtk+-4.0


   if [ $ciUseMultiArch = 1 ] ; 
   then
      sudo apt-get install -y libgtk-4-0:$cisecondarch
   fi
 
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo apt-get install -y qt5-qmake
    sudo apt-get install -y qtbase5-dev
    sudo apt-get install -y qtbase5-dev-tools
    sudo apt-get install -y qtdeclarative5-dev
    sudo apt-get install -y libqt5x11extras5-dev


   if [ $ciUseMultiArch = 1 ] ;
   then   
    sudo apt-get install -y libqt5x11extras5-dev:$cisecondarch
   fi 

fi


sudo apt-get autoremove -y
sudo ldconfig
#use  sudo ldconfig -v to see if lib are visible to the dynamic linker ld

echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation"
echo "Finish !!!"

#sleep 5
