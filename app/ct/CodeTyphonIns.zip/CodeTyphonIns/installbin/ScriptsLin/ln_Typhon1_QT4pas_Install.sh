# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


# ======================= for Unix ===============================
dothejob_unix() 
{

if [ -f $vCTDir/allzips/binqt/qt4-${vCPUOS}.7z ] ;
then 

  if [ ! -d $vCTDir/qt4pas/ ] ;
   then  
     sudo mkdir $vCTDir/qt4pas/
     sudo chmod -R 777 $vCTDir/qt4pas/
   fi 

  sudo $v7zipexe x ${vCTDir}/allzips/binqt/qt4-${vCPUOS}.7z -o${vCTDir}/qt4pas/ -y 
  sudo chmod -R 777 $vCTDir/qt4pas/
  echo "-------------------- " 
  echo "[INFO] Install OK prebuild QT4Pas Libraries for ${vCPUOS}" 

else 
  echo "  " 
  echo "[INFO] Prebuild QT4Pas Libraries for ${vCPUOS} NOT exists" 
  echo "[INFO] START QT4Pas builder..." 
  echo "  " 

cd $vCTDir/ScriptsLin

./ln_Typhon1_QT4pas_Build.sh

fi
 
cd $vCTDir/ScriptsLin
}

# ======================= for MacOS ===============================
dothejob_macos() 
{

if [ -f $vCTDir/allzips/binqt/qt4-${vCPUOS}.7z ] ;
then 

  if [ ! -d $vCTDir/qt4pas/ ] ;
   then  
     sudo mkdir $vCTDir/qt4pas/
     sudo chmod -R 777 $vCTDir/qt4pas/
   fi 

  sudo $v7zipexe x ${vCTDir}/allzips/binqt/qt4-${vCPUOS}.7z -o${vCTDir}/qt4pas/ -y 
  sudo chmod -R 777 $vCTDir/qt4pas/
  echo "-------------------- " 
  echo "[INFO] Install OK prebuild QT4Pas Libraries for ${vCPUOS}" 

else 
  echo "  " 
  echo "[INFO] Prebuild QT4Pas Libraries for ${vCPUOS} NOT exists" 
  echo "[INFO] START QT4Pas builder..." 
  echo "  " 

cd $vCTDir/ScriptsLin

./ln_Typhon1_QT4pas_Build.sh

fi
 
cd $vCTDir/ScriptsLin
}

# ======================= dothejob ===========================
dothejob() 
{
if [ $vOSName = darwin ] ;
then

  if [ $vBits = 64 ] ;
  then 
   dothejob_unix
  fi  

else

dothejob_unix

fi
}

#========================MAIN===========================
. $PWD/ln_All_Functions.sh
getvalues

echo "---------------------------------------------------------"
echo "    Install prebuild QT4Pas Libraries"   
echo "---------------------------------------------------------"

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi

./ln_Typhon1_QT4pas_Make_Links.sh


