# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

echo "   "
echo "---------------------------------------------------------"
echo "     Extract ${vOSNameBits} Toolchains Library..."   
echo "---------------------------------------------------------"

if [ -f ../allzips/cross/bincross-common.7z ] ;
then    
   sudo $v7zipexe x ../allzips/cross/bincross-common.7z -o$vCTDir -y
   sudo chmod -R 777 $vCTDir/binToolchains/   
else
   echo "[ERROR]: bincross-common.7z Toolchains Library Zip File NOT EXIST ????????"
fi

if [ -f ../allzips/cross/bincross-${vCPUOS}.7z ] ;
then    
   sudo $v7zipexe x ../allzips/cross/bincross-${vCPUOS}.7z -o$vCTDir -y
   sudo chmod -R 777 $vCTDir/binToolchains/   
else
   echo "[ERROR]: ${vCPUOS} Toolchains Library Zip File NOT EXIST ????????"
fi

}

# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi


