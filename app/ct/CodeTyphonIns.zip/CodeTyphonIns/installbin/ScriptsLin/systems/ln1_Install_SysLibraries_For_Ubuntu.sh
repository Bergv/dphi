# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#      This Script Install to Ubuntu Linux 
#      base libraries to Build and Run CodeTyphon
# =============================================================
# Update 05-11-2014 for Ubuntu 14.10
# Update 26-07-2015 for Ubuntu 15.04   MultiArch
# Update 05-08-2015 for LinuxMint 17.2 MultiArch (ubuntu 14.04 based)
# Update 24-10-2015 for Ubuntu 15.10   MultiArch
# Update 06-12-2015 for LinuxMint 17.3 MultiArch (ubuntu 14.04 based)
# Update 09-04-2016 for Ubuntu 16.04   MultiArch
# Update 16-10-2016 for Ubuntu 16.10   MultiArch
# Update 14-04-2017 for Ubuntu 17.04   MultiArch
# Update 25-10-2017 for Ubuntu 17.10   MultiArch
# Update 23-11-2017 for Kali Linux
# Update 23-05-2018 for Ubuntu 18.04   MultiArch
# Update 29-06-2018 for LinuxMint 19.0 MultiArch (ubuntu 18.04 based)
# Update 20-10-2018 for Ubuntu 18.10   MultiArch
# Update 25-12-2018 for LinuxMint 19.1 MultiArch 
# Update 20-04-2019 for Ubuntu 19.04   MultiArch
# Update 10-08-2019 for LinuxMint 19.2 MultiArch 
# Update 02-12-2019 for Ubuntu 19.10   MultiArch  
# Update 24-04-2020 for Ubuntu 20.04   MultiArch, MultiPlatform for GTK2 and QT5  
# Update 27-06-2020 for LinuxMint 20   MultiArch, MultiPlatform for GTK2 and QT5 
# Update 12-09-2020 for Deepin Linux ver 20 
# Update 20-10-2020 for Ubuntu 20.10   MultiArch, MultiPlatform for GTK2 and QT5  
# Update 09-01-2021 for LinuxMint 20.1 MultiArch, MultiPlatform for GTK2 and QT5 
# Update 22-04-2021 for Ubuntu 21.04   MultiArch, MultiPlatform for GTK2 and QT5  
#========================================================

ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

cisecondarch=i386

if [ $cicpuname = aarch64 ] ; 
then  
 cisecondarch=armhf
fi

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for" 
echo "              Ubuntu Linux" 
echo "----------------------------------------------------"
echo "   "


if [ $ciUseMultiArch = 1 ] ;
then  
  echo "[INFO] Setup MultiArch OS..."

  sudo dpkg --add-architecture $cisecondarch

  echo "  Base OS Architecture:     $(dpkg --print-architecture)"
  echo "  Foreign OS Architectures: $(dpkg --print-foreign-architectures)"
  echo "   "
fi

echo "[INFO] Start OS Update..."
echo "   "
sudo apt-get update -y
sudo apt-get autoremove -y

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

# ------------Install libraries Common
sudo apt-get install -y xterm 
sudo apt-get install -y zip 
sudo apt-get install -y unzip 
sudo apt-get install -y wget 
sudo apt-get install -y alien
sudo apt-get install -y make 
sudo apt-get install -y gcc 
sudo apt-get install -y g++ 
sudo apt-get install -y build-essential
sudo apt-get install -y binutils
sudo apt-get install -y gdb
sudo apt-get install -y devscripts
sudo apt-get install -y libc6-dev

sudo apt-get install -y freeglut3-dev
sudo apt-get install -y libgl1-mesa 
sudo apt-get install -y libgl1-mesa-dev
sudo apt-get install -y libglu1-mesa
sudo apt-get install -y libglu1-mesa-dev
sudo apt-get install -y libgpmg1-dev
sudo apt-get install -y libsdl-dev
sudo apt-get install -y libXxf86vm-dev
sudo apt-get install -y libxtst-dev
sudo apt-get install -y libx11-dev
  
sudo apt-get install -y libxft2
sudo apt-get install -y libfontconfig1

# Install Courier fonts
sudo apt-get install -y xfonts-scalable
# sudo apt-get install -y ttf-mscorefonts-installer


if [ $ciUseMultiArch = 1 ] ; 
then  
  sudo apt-get install -y libc6-dev-$cisecondarch
  sudo apt-get install -y lib32gcc1
  sudo apt-get install -y gcc-multilib
  sudo apt-get install -y lib32stdc++6
  sudo apt-get install -y g++-multilib

  sudo apt-get install -y libc6-dev:$cisecondarch
  sudo apt-get install -y libxtst-dev:$cisecondarch
  sudo apt-get install -y freeglut3:$cisecondarch
  sudo apt-get install -y libgl1-mesa:$cisecondarch
  sudo apt-get install -y libgl1-mesa-dev:$cisecondarch
  sudo apt-get install -y libglu1-mesa:$cisecondarch
  sudo apt-get install -y libglu1-mesa-dev:$cisecondarch
  sudo apt-get install -y libxtst6:$cisecondarch
  sudo apt-get install -y libx11-6:$cisecondarch
  sudo apt-get install -y libxmu-dev:$cisecondarch
  sudo apt-get install -y libxxf86vm1:$cisecondarch
  
  sudo apt-get install -y libxft2:$cisecondarch
  sudo apt-get install -y libfontconfig1:$cisecondarch
fi

# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    
   if [ $ciUseMultiArch = 1 ] ;
   then  
      sudo apt-get install -y libglib2.0:$cisecondarch
      sudo apt-get install -y libgtk2.0:$cisecondarch
      sudo apt-get install -y libgtk2.0-0:$cisecondarch
      sudo apt-get install -y gtk2-engines-pixbuf:$cisecondarch
      sudo apt-get install -y libcairo2:$cisecondarch
   fi

    sudo apt-get install -y libglib2.0-dev
    sudo apt-get install -y libgtk2.0-0-dev
    sudo apt-get install -y libgtk2.0-dev
    sudo apt-get install -y gtk2-engines-pixbuf
    sudo apt-get install -y libcairo2-dev

fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo apt-get install -y libqt4-dev
    sudo apt-get install -y libqtwebkit-dev
    sudo apt-get install -y qt4-qmake


   if [ $ciUseMultiArch = 1 ] ; 
   then  
      sudo apt-get install -y libqt4-dev:$cisecondarch
      sudo apt-get install -y libqtwebkit-dev:$cisecondarch
   fi 
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo apt-get install -y gtk+-3.0


   if [ $ciUseMultiArch = 1 ] ; 
   then
      sudo apt-get install -y libgtk-3-0:$cisecondarch
   fi
 
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo apt-get install -y gtk+-4.0


   if [ $ciUseMultiArch = 1 ] ; 
   then
      sudo apt-get install -y libgtk-4-0:$cisecondarch
   fi
 
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo apt-get install -y qt5-qmake
    sudo apt-get install -y qtbase5-dev
    sudo apt-get install -y qtbase5-dev-tools
    sudo apt-get install -y qtdeclarative5-dev
    sudo apt-get install -y libqt5x11extras5-dev


   if [ $ciUseMultiArch = 1 ] ;
   then   
    sudo apt-get install -y libqt5x11extras5-dev:$cisecondarch
   fi 

fi


sudo apt-get autoremove -y
sudo ldconfig
#use  sudo ldconfig -v to see if lib are visible to the dynamic linker ld

echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation"
echo "Finish !!!"

#sleep 5