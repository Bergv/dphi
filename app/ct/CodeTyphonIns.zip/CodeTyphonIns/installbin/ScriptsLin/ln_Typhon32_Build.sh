# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

# ======================== Check build =====================
checkbuild() 
{

# ---- Don't build Typhon32 IDE for MacOS GTK2 Platform ----
if [ $vOSName = darwin ] ;
then
if [ $vLCLplat = 0 ] ; 
then
 echo " "
 echo "----------------------------------------------------" 
 echo "[INFO]: On MacOS GTK2 Platform NOT support 32bits" 
 echo "          Typhon32 BIG IDE build Aborted..."
 echo "----------------------------------------------------"  
 echo " "
 
 exit
fi

if [ $vLCLplat = 1 ] ; 
then
 echo " "
 echo "----------------------------------------------------" 
 echo "[INFO]: On MacOS QT4 Platform NOT support 32bits" 
 echo "          Typhon32 BIG IDE build Aborted..."
 echo "----------------------------------------------------"  
 echo " "
 
 exit
fi

if [ $vLCLplat = 7 ] ; 
then
 echo " "
 echo "----------------------------------------------------" 
 echo "[INFO]: On MacOS QT5 Platform NOT support 32bits" 
 echo "          Typhon32 BIG IDE build Aborted..."
 echo "----------------------------------------------------"  
 echo " "
 
 exit
fi

fi
}

# ======================== CheckQT =========================
checkforqt() 
{

# ----------- For MacOS -----------
if [ $vOSName = darwin ] ;
then  
 
if [ $vLCLplat = 1 ] ;
then 
  if [ ! -f /usr/${vOSLibSub}/Qt4Pas.framework ] ; 
  then 
   ./ln_Typhon1_QT4pas_Install.sh
  fi
fi
if [ $vLCLplat = 7 ] ;
then 
  if [ ! -f /usr/${vOSLibSub}/Qt5Pas.framework ] ; 
  then 
   ./ln_Typhon1_QT5pas_Install.sh
  fi
fi

else
# ----------- For Unix -----------

if [ $vLCLplat = 1 ] ;
then 
  if [ ! -f /usr/${vOSLibSub}/libQt4Pas.so ] ; 
  then 
   ./ln_Typhon1_QT4pas_Install.sh
  fi
fi
if [ $vLCLplat = 7 ] ;
then 
  if [ ! -f /usr/${vOSLibSub}/libQt5Pas.so ] ; 
  then 
   ./ln_Typhon1_QT5pas_Install.sh
  fi
fi
 
fi
}

# ======================== DoTheJob =========================
dothejob() 
{

# =================== Build Typhon32 ==================================

if [ ! -f $vCTDir/typhon/bin$vBits/typhonbuild ] ;
then  
 ./ln_Typhon32_Build_Small.sh
fi

echo "   "
echo "=============================================================="
echo "    Build Typhon32 BIG IDE $vCPUOSPlat for $vHostOSRealName"  
echo "=============================================================="
echo "   "

if [ ! -f $vCTDir/typhon/bin$vBits/typhon ] ;
then 
echo "   "
echo "[ERROR]: Sorry, Typhon32 from Small-IDE NOT Build"      
echo "         please remove and build Typhon again..."
echo "   "
 sleep 3
exit
fi

if [ ! -f $vCTDir/typhon/bin$vBits/typhonbuild ] ;
then 
echo "   "
echo "[ERROR]: Sorry, typhonbuild32 from Small-IDE NOT Build"      
echo "         please remove and build Typhon again..."
echo "   "
 sleep 3
exit
fi

# =================== Preparation =====================

VarPkgsGroup=
if [ -f $vCTDir/Settings/CT_NOT_Use_Pkgs_Group.ctsw ] ;
then
  VarPkgsGroup=--no-pkgs-group
echo "   "
echo "[INFO]: NOT use Pkgs Group Compile Method"
echo "   "
fi

if [ ! -f $vCTDir/typhon/bin$vBits/styphon ] ;
then  
 sudo rm -f $vCTDir/typhon/bin$vBits/styphon
fi

if [ -f $vCTDir/typhon/bin$vBits/CT_Is_BigIDE.ctsw ] ;
then  
 sudo rm -f $vCTDir/typhon/bin$vBits/CT_Is_BigIDE.ctsw
fi

sudo mv -f $vCTDir/typhon/bin$vBits/typhon $vCTDir/typhon/bin$vBits/styphon

# =====================================================

sudo chmod -R 777 $vCTDir/typhon/

cd $vCTDir/typhon

case $vLCLplat in
  0)
     $vCTDir/typhon/bin$vBits/typhonbuild -B --build-ide="-dLCLgtk2" --ws=gtk2 $VarPkgsGroup
    ;;
  1)
     $vCTDir/typhon/bin$vBits/typhonbuild -B --build-ide="-dLCLqt" --ws=qt $VarPkgsGroup
    ;;
  3)
     $vCTDir/typhon/bin$vBits/typhonbuild -B --build-ide="-dLCLgtk3" --ws=gtk3 $VarPkgsGroup
    ;;
  4)
     $vCTDir/typhon/bin$vBits/typhonbuild -B --build-ide="-dLCLcustomdrawn" --ws=customdrawn $VarPkgsGroup
    ;;
  5)
     $vCTDir/typhon/bin$vBits/typhonbuild -B --build-ide="-dLCLcarbon" --ws=carbon $VarPkgsGroup
    ;;
  6)
     $vCTDir/typhon/bin$vBits/typhonbuild -B --build-ide="-dLCLcocoa" --ws=cocoa $VarPkgsGroup
    ;;
  7)
     $vCTDir/typhon/bin$vBits/typhonbuild -B --build-ide="-dLCLqt5" --ws=qt5 $VarPkgsGroup
    ;;
  8)
     $vCTDir/typhon/bin$vBits/typhonbuild -B --build-ide="-dLCLfpgui" --ws=fpgui $VarPkgsGroup
    ;;
  9)
     $vCTDir/typhon/bin$vBits/typhonbuild -B --build-ide="-dLCLgtk4" --ws=gtk4 $VarPkgsGroup
    ;;
  *)
     $vMake bigide PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=usr/local/codetyphon/typhon/ 
    ;;
esac 


# sleep 120


cd $vCTDir/typhon

# ================= if BIG-IDE Build OK =======================

if [ -f $vCTDir/typhon/typhon ] ;
then   

sudo mv -f typhon $vCTDir/typhon/bin$vBits/

if [ -f typhonstart ] ;
then  
 sudo mv -f typhonstart $vCTDir/typhon/bin$vBits/
fi

if [ -f typhonbuild ] ;
then  
 sudo mv -f typhonbuild $vCTDir/typhon/bin$vBits/
fi

sudo cp -f $vCTDir/binSettings/switcher/CT_Is_BigIDE.ctsw $vCTDir/typhon/bin$vBits/

# -------------- Make Permitions ---------------------

sudo chmod -R 777 $vCTDir/typhon/
 
# -------------- Build External Tools ----------------

if [ ! -f $vCTDir/Settings/CT_NOT_Build_Tools.ctsw ] ;
then
cd $vCTDir/ScriptsLin
./ln_Typhon_Tools_Build.sh 32
fi

# -------------- Remove Temp styphon exe---------

sudo rm -f $vCTDir/typhon/bin$vBits/styphon

# -------------- Strip Executables files ---------
cd $vCTDir/ScriptsLin
./ln_Typhon_Strip.sh 32

# --------------  Make links ---------------------
cd $vCTDir/ScriptsLin
./ln_xCodeTyphon_Make_Links.sh 32

cd $vCTDir/typhon
 
 echo "   "
 echo " ------------------------------------------------------"
 echo "   "
 echo "[FINAL INFO]: Typhon32 BIG IDE $vCPUOSPlat Build OK!!! Have fun..." 
 echo "   "
  
#sleep 5
  
else 
# ================= if BIG-IDE NOT Build =======================

 sudo mv -f $vCTDir/typhon/bin$vBits/styphon $vCTDir/typhon/bin$vBits/typhon

 if [ -f $vCTDir/typhon/typhonbuild ] ;
  then  
   sudo rm -f $vCTDir/typhon/typhonbuild
  fi

 if [ -f $vCTDir/typhon/typhonstart ] ;
  then  
   sudo rm -f $vCTDir/typhon/typhonstart
 fi
 
# --------------  Make links ---------------------
cd $vCTDir/ScriptsLin 
./ln_xCodeTyphon_Make_Links.sh 32
 
 echo "   "
 echo " ------------------------------------------------------"
 echo "   "
 echo  "??????????????????????????????????????????????????????????"
 echo  "[ERROR]: Sorry, Typhon32 BIG IDE $vCPUOSPlat NOT Build"
 echo  "??????????????????????????????????????????????????????????"

if [ -f $vCTDir/typhon/bin$vBits/typhon ] ;
  then    
   echo "   "
   echo "[FINAL INFO]: Typhon32 BIG IDE $vCPUOSPlat NOT Build" 
   echo "              but Typhon32 Small-IDE Exists !!! Have fun..."
   echo "   "   
  fi

#sleep 5 
fi
}
# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

checkbuild
checkforqt

if [ $vBits = 32 ] ;
then 
 dothejob
else
  if [ $vUseMultiArch = 1 ] ;
  then 
    setdummy32
    dothejob 
  fi
fi

