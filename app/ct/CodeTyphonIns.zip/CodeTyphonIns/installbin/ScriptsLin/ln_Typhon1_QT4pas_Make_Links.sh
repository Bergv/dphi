# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


# ======================== Make Links Unix =========================
dothejob_unix()
{

if [ ! -f $vCTDir/qt4pas/${vCPUOS}/libQt4Pas.so.5.2.8 ] ;
then
echo "   "
echo "[ERROR] File $vCTDir/qt4pas/${vCPUOS}/libQt4Pas.so.5.2.8 NOT Exists..."
echo "[ERROR] Can't Make QT4pas links..."
echo "   "
exit
fi

#---- Check and Make Local Links -------

if [ ! -f ${vCTDir}/qt4pas/${vCPUOS}/libQt4Pas.so.5.2 ] ;
then
sudo ln -f -s ${vCTDir}/qt4pas/${vCPUOS}/libQt4Pas.so.5.2.8 ${vCTDir}/qt4pas/${vCPUOS}/libQt4Pas.so.5.2
fi

if [ ! -f ${vCTDir}/qt4pas/${vCPUOS}/libQt4Pas.so.5 ] ;
then
sudo ln -f -s ${vCTDir}/qt4pas/${vCPUOS}/libQt4Pas.so.5.2.8 ${vCTDir}/qt4pas/${vCPUOS}/libQt4Pas.so.5
fi

if [ ! -f ${vCTDir}/qt4pas/${vCPUOS}/libQt4Pas.so ] ;
then
sudo ln -f -s ${vCTDir}/qt4pas/${vCPUOS}/libQt4Pas.so.5.2.8 ${vCTDir}/qt4pas/${vCPUOS}/libQt4Pas.so
fi

sudo chmod -R 777 $vCTDir/qt4pas/

#---- Remove OLD Links from OS Lib Folder -------

if [ -f /usr/${vOSLibSub}/libQt4Pas.so ] ;
then
sudo rm -f /usr/${vOSLibSub}/libQt4Pas.so
fi

if [ -f /usr/${vOSLibSub}/libQt4Pas.so.5 ] ;
then
sudo rm -f /usr/${vOSLibSub}/libQt4Pas.so.5
fi

if [ -f /usr/${vOSLibSub}/libQt4Pas.so.5.2 ] ;
then
sudo rm -f /usr/${vOSLibSub}/libQt4Pas.so.5.2
fi

if [ -f /usr/${vOSLibSub}/libQt4Pas.so.5.2.8 ] ;
then
sudo rm -f /usr/${vOSLibSub}/libQt4Pas.so.5.2.8
fi

#---- Make new Links to OS Lib Folder -----------

sudo cp -f ${vCTDir}/qt4pas/${vCPUOS}/libQt4Pas.so.5.2.8 /usr/${vOSLibSub}/libQt4Pas.so.5.2.8
sudo chmod 777 /usr/${vOSLibSub}/libQt4Pas.so.5.2.8

sudo ln -f -s /usr/${vOSLibSub}/libQt4Pas.so.5.2.8 /usr/${vOSLibSub}/libQt4Pas.so.5.2
sudo ln -f -s /usr/${vOSLibSub}/libQt4Pas.so.5.2.8 /usr/${vOSLibSub}/libQt4Pas.so.5
sudo ln -f -s /usr/${vOSLibSub}/libQt4Pas.so.5.2.8 /usr/${vOSLibSub}/libQt4Pas.so

sudo chmod 777 /usr/${vOSLibSub}/libQt4Pas.so.5.2
sudo chmod 777 /usr/${vOSLibSub}/libQt4Pas.so.5
sudo chmod 777 /usr/${vOSLibSub}/libQt4Pas.so

echo "[INFO] Make QT4pas links to /usr/${vOSLibSub}/ for ${vCPUOS} finish OK"
}

# ======================== Make Links MacOS =========================
dothejob_macos()
{

if [ ! -d $vCTDir/qt4pas/${vCPUOS}/Qt4Pas.framework ] ;
then
echo "   "
echo "[ERROR] File $vCTDir/qt4pas/${vCPUOS}/Qt4Pas.framework NOT Exists..."
echo "[ERROR] Can't Make Qt4Pas.framework links..."
echo "   "
exit
fi

sudo chmod -R 777 $vCTDir/qt4pas/

# --- Remove MacPorts Qt4Pas Version -----
if [ -d /opt/local/libexec/qt4/lib/Qt4Pas.framework ] ;
then
sudo rm -fr /opt/local/libexec/qt4/lib/Qt4Pas.framework
echo "[INFO] REMOVE MacPorts Qt4Pas Version from /opt/local/libexec/qt4/lib/Qt4Pas.framework"
fi

# --- Remove OLD CT Qt4Pas Version -----
if [ -d /Library/Frameworks/Qt4Pas.framework ] ;
then
sudo rm -fr /Library/Frameworks/Qt4Pas.framework
fi

sudo cp -fr ${vCTDir}/qt4pas/${vCPUOS}/Qt4Pas.framework /Library/Frameworks/Qt4Pas.framework
sudo chmod -R 777 /Library/Frameworks/Qt4Pas.framework

# --- make internal links -----

sudo rm -f /Library/Frameworks/Qt4Pas

sudo chmod 777 /Library/Frameworks/Qt4Pas.framework/Versions/5/Qt4Pas
sudo ln -f -s /Library/Frameworks/Qt4Pas.framework/Versions/5/Qt4Pas /Library/Frameworks/Qt4Pas.framework/Qt4Pas
sudo chmod 777 /Library/Frameworks/Qt4Pas.framework/Qt4Pas
sudo chmod -R 777 /Library/Frameworks/Qt4Pas.framework


echo "[INFO] Make Qt4Pas.framework links to /Library/Frameworks/Qt4Pas.framework for ${vCPUOS} finish OK"
}

# ======================== Make Links General ======================
dothejob()
{
if [ $vOSName = darwin ] ;
then

  if [ $vBits = 64 ] ;
  then 
   dothejob_macos
  fi  

else
dothejob_unix
fi
}


#========================MAIN===========================
. $PWD/ln_All_Functions.sh
getvalues

echo "   "
echo "---------------------------------------------------------"
echo "    Make QT4Pas Libraries Links"
echo "---------------------------------------------------------"
echo "   "

dothejob

if [ $vUseMultiArch = 1 ] ;
then
setdummy32
dothejob
fi


