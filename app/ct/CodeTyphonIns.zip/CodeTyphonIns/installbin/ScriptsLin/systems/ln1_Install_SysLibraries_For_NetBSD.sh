# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#     This Script Install to NetBSD OS
#     base libraries to Build and Run CodeTyphon
# =============================================================
# Update 17-07-2015 for NetBSD 6.1.5
# Update 20-05-2019 for NetBSD 8.0
# Update 24-08-2019 for NetBSD 8.1
# Update 08-04-2020 for NetBSD 9.0
# Update 21-10-2020 for NetBSD 9.1
# Update 19-05-2021 for NetBSD 9.2
#========================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for" 
echo "                NetBSD"
echo "----------------------------------------------------"
echo "   "

sudo pkgin -y install xterm
sudo pkgin -y install zip
sudo pkgin -y install unzip
sudo pkgin -y install wget

sudo pkgin -y install gcc10
sudo pkgin -y install binutils
sudo pkgin -y install gmake
sudo pkgin -y install gdb
sudo pkgin -y install lldb

sudo pkgin -y install libiconv
sudo pkgin -y install libX11 
sudo pkgin -y install libXtst

#sudo pkgin -y install xorg-fonts-type1
#sudo pkgin -y install takao-fonts-ttf


# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    sudo pkgin -y install gtkglext
fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo pkgin -y install qt4
    sudo pkgin -y install qt4-tools
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo pkgin -y install gtk3+
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo pkgin -y install gtk4+
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo pkgin -y install qt5
    sudo pkgin -y install qt5-qttools
    sudo pkgin -y install qt5-qtwebkit
fi


echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation"
echo "Finish !!!"

#sleep 5
