# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


dothejob() 
{

echo "----------------------------------------------"
echo "   Exract CrossBuild Engine" 
echo "----------------------------------------------"

if [ ! -d $vCTDir/CrossEng ] ;
then     
    sudo mkdir $vCTDir/CrossEng
    sudo chmod -R 777 $vCTDir/CrossEng/
fi

}

# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi


