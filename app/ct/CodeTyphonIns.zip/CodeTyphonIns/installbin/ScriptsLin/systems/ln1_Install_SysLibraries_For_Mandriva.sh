# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#      This Script Install to Mandriva Linux 
#      base libraries to Build and Run CodeTyphon
# =============================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for" 
echo "             Mandriva Linux" 
echo "----------------------------------------------------"
echo "   "

echo "[INFO] Start OS Update..."
echo "   "
sudo urpmi --auto-update

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

sudo urpmi --auto -a xterm
sudo urpmi --auto -a zip
sudo urpmi --auto -a unzip
sudo urpmi --auto -a wget

sudo urpmi --auto -a make 
sudo urpmi --auto -a kernel-devel 
sudo urpmi --auto -a kernel-headers 
sudo urpmi --auto -a gcc
sudo urpmi --auto -a gcc-c++
sudo urpmi --auto -a gdb 
sudo urpmi --auto -a binutils

sudo urpmi --auto -a glibc
sudo urpmi --auto -a glibc-dev
sudo urpmi --auto -a glibc-devel

sudo urpmi --auto -a libx11
sudo urpmi --auto -a libx11-dev
sudo urpmi --auto -a libx11-devel

sudo urpmi --auto -a glib
sudo urpmi --auto -a glib-dev
sudo urpmi --auto -a glib-devel

sudo urpmi --auto -a mesa-common
sudo urpmi --auto -a mesa-common-dev
sudo urpmi --auto -a mesa-common-devel

sudo urpmi --auto -a libxtst
sudo urpmi --auto -a libxtst-dev
sudo urpmi --auto -a libxtst-devel

sudo urpmi --auto -a freeglut

sudo urpmi --auto -a xorg-x11-100dpi-fonts xorg-x11-75dpi-fonts 


# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    
    sudo urpmi --auto -a gtk2
    sudo urpmi --auto -a gtk2-dev
    sudo urpmi --auto -a gtk2-devel

    sudo urpmi --auto -a gtk+extra
    sudo urpmi --auto -a gtk+
    sudo urpmi --auto -a gtk+-dev
    sudo urpmi --auto -a gtk+-devel

    sudo urpmi --auto -a cairo
    sudo urpmi --auto -a cairo-dev 
    sudo urpmi --auto -a cairo-devel 

    sudo urpmi --auto -a cairo-gobject
    sudo urpmi --auto -a cairo-gobject-dev
    sudo urpmi --auto -a cairo-gobject-devel

    sudo urpmi --auto -a pango
    sudo urpmi --auto -a pango-dev
    sudo urpmi --auto -a pango-devel  
fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo urpmi --auto -a libqt4-dev
    sudo urpmi --auto -a libqt4-devel
    sudo urpmi --auto -a qt4-qmake
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo urpmi --auto -a gtk+-3.0   
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo urpmi --auto -a gtk+-4.0   
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo urpmi --auto -a libqt5-dev
    sudo urpmi --auto -a libqt5-devel
    sudo urpmi --auto -a qt5-qmake
fi

echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation"  
echo "Finish !!!"

#sleep 5
