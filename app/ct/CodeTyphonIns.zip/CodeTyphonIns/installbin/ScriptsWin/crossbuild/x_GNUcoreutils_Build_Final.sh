# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{
# ===================== Build GNU coreutils ==================

cd C:/codetyphon/CrossEng/coreutils_src

if [ -d build ] ;
then     
    echo "[INFO]: Remove OLD temporary BUILD directory..."
    rm -rf build
    echo "  "
else    
    echo " "
    echo "--- patch for Windows OS-----------"
    patch -p1 < coreutils-win.patch
    echo " "
fi
      

# Missing <sys/wait.h>.
echo "/* ignore */" > lib/savewd.c

# Missing <pwd.h> and <grp.h>.
echo "/* ignore */" > lib/idcache.c
echo "/* ignore */" > lib/userspec.c
echo "/* ignore */" > src/chgrp.c
echo "/* ignore */" > src/chown-core.c
echo "/* ignore */" > src/ls.c
echo "/* ignore */" > src/install.c
echo "/* ignore */" > src/groups.c
echo "/* ignore */" > src/group-list.c
echo "/* ignore */" > src/id.c
echo "/* ignore */" > src/stat.c
echo "/* ignore */" > src/whoami.c

# Missing fpathconf().
echo "/* ignore */" > lib/backupfile.c
  
mkdir build
cd build

echo "ac_cv_header_pthread_h=no" > config.site
#export CONFIG_SITE=config.site
    

echo " "
echo "-------- configure -----------"
 
../configure --build=$buMakbuildCPUOS --host=$buMakhostCPUOS --target=$buMakTargetCPUOS --prefix=C:/codetyphon/CrossEng/coreutilsout \
--enable-install-program=arch,hostname \
--enable-no-install-program=uptime

#touch src/make-prime-list

echo " "
echo "-------- make ----------------"
make -j4 -k "CFLAGS=-O3 -D_FORTIFY_SOURCE=0" "LDFLAGS=-s" || true

}

# =================== MAIN =============================

buPCBits=$1
buPCOS=$2
buPCCPUOS=$3
buMakbuildCPUOS=$4
buMakhostCPUOS=$5
buMakTargetCPUOS=$6


echo "   "
echo "-----------------------------------------------"
echo "   GNU coreutils Build Engine Final settings"
echo "-----------------------------------------------"
echo "   "
echo $buPCBits
echo $buPCOS
echo $buPCCPUOS
echo $buMakbuildCPUOS
echo $buMakhostCPUOS
echo $buMakTargetCPUOS
echo "   "

dothejob

