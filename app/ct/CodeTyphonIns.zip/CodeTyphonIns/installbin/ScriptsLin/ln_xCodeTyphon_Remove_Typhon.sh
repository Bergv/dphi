# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


dothejob() 
{
# ------------ Remove CodeOcean ------------

echo "---SubStep 1/4"
./ln_xCodeTyphon_Remove_CodeOcean.sh

# ------------ Remove DocFactory ------------

echo "---SubStep 2/4"
./ln_xCodeTyphon_Remove_DocFactory.sh

# ------------ Remove Runtimes ------------

echo "---SubStep 3/4"
./ln_xCodeTyphon_Remove_Runtimes.sh

# ------------ Remove Typhon ---------------

echo "---SubStep 4/4"
echo "----------------------------------------------"
echo "    Please Wait... Removing Typhon $vBits" 
echo "----------------------------------------------"

#------------- Remove Typhon Directory ---------------

if [ -d $vCTDir/lazarus ] ;
then 
  sudo rm -fr $vCTDir/lazarus  
fi

if [ -d $vCTDir/typhon ] ;
then 
  sudo rm -fr $vCTDir/typhon
  echo "[INFO]: Remove Typhon Directory Removed OK"
else
  echo "[INFO]: Remove Typhon Directory NOT EXIST, nothing to do ..."   
fi

#------------- Remove Typhon Temporary Directory ---------------
if [ -d $vTyphonSetDir ] ;
then 
  sudo rm -fr $vTyphonSetDir
  echo "[INFO]: typhonTemp Directory Removed OK"
else
  echo "[INFO]: typhonTemp Directory NOT EXIST, nothing to do ..."   
fi

# ------------ Remove Typhon all link files ------------

sudo rm -f $vOSBinDir/typhon-ide
sudo rm -f $vOSBinDir/typhonbuild
sudo rm -f $vOSBinDir/typhonstart
sudo rm -f $vOSBinDir/typhon
sudo rm -f $vOSBinDir/typhon-ide32
sudo rm -f $vOSBinDir/typhonbuild32
sudo rm -f $vOSBinDir/typhonstart32
sudo rm -f $vOSBinDir/typhon64
sudo rm -f $vOSBinDir/typhon-ide64
sudo rm -f $vOSBinDir/typhonbuild64
sudo rm -f $vOSBinDir/typhonstart64
sudo rm -f $vOSBinDir/typhon64

# ----------- Remove Typhon all link files ---------------

if [ $vOSName = darwin ] ;
then 

# Remove old links

sudo rm -f $vOSBinDir/typhon-ide$vBits
sudo rm -f $vOSBinDir/typhonbuild$vBits
sudo rm -f $vOSBinDir/typhonstart$vBits

if [ -f $vOSAppDskDir/Typhon$vBits.app ] ;
then
  sudo chmod 777 $vOSAppDskDir/Typhon$vBits.app
  sudo rm -f $vOSAppDskDir/Typhon$vBits.app
fi

# Make New links
if [ -f $vCTDir/typhon/bin$vBits/typhon ] ;
then
 
 sudo chmod 777 $vCTDir/typhon/bin$vBits/typhon
 sudo chmod 777 $vCTDir/typhon/bin$vBits/typhonstart
 sudo chmod -R 777 $vCTDir/binSettings/settings/allformacos/typhon.app
 sudo chmod -R 777 $vCTDir/binSettings/settings/allformacos/typhonstart.app
 sudo chmod -R 777 $vCTDir/binSettings/settings/allformacos/Typhon$vBits.app

if [ -d $vCTDir/typhon/bin$vBits/typhon.app ] ;
then
 sudo chmod -R 777 $vCTDir/typhon/bin$vBits/typhon.app
 sudo rm -fr $vCTDir/typhon/bin$vBits/typhon.app
fi

if [ -d $vCTDir/typhon/bin$vBits/typhonstart.app ] ;
then
 sudo chmod -R 777 $vCTDir/typhon/bin$vBits/typhonstart.app
 sudo rm -fr $vCTDir/typhon/bin$vBits/typhonstart.app
fi

sudo cp -fr $vCTDir/binSettings/settings/allformacos/typhon.app $vCTDir/typhon/bin$vBits/
sudo ln -f -s $vCTDir/typhon/bin$vBits/typhon $vCTDir/typhon/bin$vBits/typhon.app/Contents/MacOS/typhon
sudo ln -f -s $vCTDir/typhon/bin$vBits/typhonstart $vCTDir/typhon/bin$vBits/typhon.app/Contents/Resources/typhonstart.app/Contents/MacOS/typhonstart
sudo chmod -R 777 $vCTDir/typhon/bin$vBits/typhon.app

sudo cp -fr $vCTDir/binSettings/settings/allformacos/typhonstart.app $vCTDir/typhon/bin$vBits/
sudo ln -f -s $vCTDir/typhon/bin$vBits/typhonstart $vCTDir/typhon/bin$vBits/typhonstart.app/Contents/MacOS/typhonstart
sudo chmod -R 777 $vCTDir/typhon/bin$vBits/typhonstart.app

sudo ln -f -s $vCTDir/typhon/bin$vBits/typhonstart.app $vOSAppDskDir/Typhon$vBits.app
sudo chmod 777 $vOSAppDskDir/Typhon$vBits.app


sudo ln -f -s $vCTDir/typhon/bin$vBits/typhon.app $vOSBinDir/typhon-ide$vBits
sudo ln -f -s $vCTDir/typhon/bin$vBits/typhonbuild.app $vOSBinDir/typhonbuild$vBits
sudo ln -f -s $vCTDir/typhon/bin$vBits/typhonstart.app $vOSBinDir/typhonstart$vBits

fi
else
#=============== OTHER UNIXs =================================================
# Remove old links

sudo rm -f $vOSBinDir/typhon-ide$vBits
sudo rm -f $vOSBinDir/typhonbuild$vBits
sudo rm -f $vOSBinDir/typhonstart$vBits  

sudo rm -f $vOSAppDskDir/typhon$vBits.desktop
sudo rm -f $vOSAppXmlDir/typhon$vBits.xml
sudo rm -f $vOSAppPngDir/typhon$vBits.png 

if [ -f $vctuserdesk/typhon$vBits.desktop ] ;
then
sudo rm -f $vctuserdesk/typhon$vBits.desktop
fi
fi

./ln_Typhon_Settings_Clean.sh

}

# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi

echo "   "
echo "[INFO]: All Typhon parts removed from disk"


