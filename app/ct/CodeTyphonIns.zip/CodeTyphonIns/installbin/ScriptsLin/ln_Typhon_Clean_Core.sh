# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


# ==================== unused directories =====================
cleanUnsedDirs() 
{

if [ ! -d $vCTDir/typhon ] ;
then  
 echo "[ERROR]: Typhon Directory NOT EXIST !!!"
 exit
fi 

#--------- Main Units --------
cd $vCTDir/

sudo rm -fr typhon/units
sudo rm -fr typhon/lcl/units
sudo rm -fr typhon/packager/units
sudo rm -fr typhon/tools/lib

sudo find $PWD/typhon -type f -iname "*.bak" -exec rm -f {} \;


cd $vCTDir/ScriptsLin/ 
}

# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

echo " "
echo "=========================================================="
echo "         Clean Typhon IDE Directory Core"
echo "=========================================================="
echo " "

cleanUnsedDirs

echo " "
echo "[FINAL INFO]: Clean Typhon IDE Directory Core Finish."
echo " "


