# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejobother()
{
if [ -f /usr/bin/caja ] ; then
   sudo caja /usr/local/codetyphon/
   
elif [ -f /usr/bin/nemo ] ; then    
   sudo nemo /usr/local/codetyphon/ 
   
elif [ -f /usr/bin/nautilus ] ; then  
 
   #For OpenSuse
  if [ -f /etc/SuSE-release ] ;
   then   
     gnomesu nautilus /usr/local/codetyphon/
   else   
     sudo nautilus /usr/local/codetyphon/ 
   fi  

elif [ -f /usr/bin/dolphin ] ; then 

   #For OpenSuse
  if [ -f /etc/SuSE-release ] ;
   then   
     kdesu dolphin /usr/local/codetyphon/ 
   else   
     sudo dolphin /usr/local/codetyphon/  
   fi  
   
fi

}

dothejobbsd() 
{

if [ -f /usr/local/bin/caja ] ; then
   sudo caja /usr/local/codetyphon/

elif [ -f /usr/local/bin/nemo ] ; then    
   sudo nemo /usr/local/codetyphon/ 

elif [ -f /usr/local/bin/dolphin ] ; then  
   sudo dolphin /usr/local/codetyphon/  
   
else
   sudo nautilus /usr/local/codetyphon/     
fi

}

dothejobdarwin() 
{

sudo open /usr/local/codetyphon/ 

}

# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

echo "-------------------------------------------------"
echo "         Start File Explorer AS ROOT "
echo "-------------------------------------------------"

case $(uname) in 
 FreeBSD)    
    dothejobbsd 
   ;; 
 Darwin)    
    dothejobdarwin 
   ;; 
 *)
   dothejobother 
   ;;    
esac
