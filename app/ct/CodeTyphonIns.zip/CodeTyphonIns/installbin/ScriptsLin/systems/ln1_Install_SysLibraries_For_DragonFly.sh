# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#     This Script Install to DragonFly OS 
#     base libraries to Build and Run CodeTyphon
# =============================================================
# Update 08-12-2014 for DragonFly 4.01
# Update 17-06-2019 for DragonFly 5.4.3
# Update 04-03-2020 for DragonFly 5.8.1
# Update 01-10-2020 for DragonFly 5.8.3
# Update 12-05-2021 for DragonFly 6.0.0
#========================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for" 
echo "               DragonFly BSD" 
echo "----------------------------------------------------"
echo "   "

# sudo pkg update 
# sudo pkg upgrade

sudo pkg install -y xterm
sudo pkg install -y zip 
sudo pkg install -y unzip 
sudo pkg install -y wget
sudo pkg install -y upx
sudo pkg install -y gcc 
sudo pkg install -y gdb 
sudo pkg install -y binutils 
sudo pkg install -y gmake
sudo pkg install -y iconv 
sudo pkg install -y xorg-libraries
sudo pkg install -y libX11
sudo pkg install -y libXtst
sudo pkg install -y xorg-fonts-type1
sudo pkg install -y liberation-fonts-ttf

# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    sudo pkg install -y gtkglext  
fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo pkg install -y qt4 
    sudo pkg install -y qt4-moc    
    sudo pkg install -y qt4-qmake   
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo pkg install -y gtk+-3.0   
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo pkg install -y gtk+-4.0   
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo pkg install -y qt5 
    sudo pkg install -y qt5-x11extras 
    sudo pkg install -y qt5-moc    
    sudo pkg install -y qt5-qmake   
fi


echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation"  
echo "Finish !!!"

#sleep 5
