# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

if [ ! -d $vFpcDir ] ;
then 
  sudo mkdir $vFpcDir
fi

if [ ! -d $vFpcBitsDir ] ;
then 
  sudo mkdir $vFpcBitsDir
fi

if [ ! -d $vFpcBinDir ] ;
then   
  sudo mkdir $vFpcBinDir
fi

if [ ! -d $vFpcExeDir ] ;
then   
  sudo mkdir $vFpcExeDir
fi

# ======================================

if [ ! -f $vFpcExeDir/$vFpcExeFile ] ;
then      
    echo "[INFO]: FPC$vBits Binary files not exists, extracting..."
    ./ln_FPC0_Install_Bin_Files.sh $vBits
fi

echo "   "
echo "------------------------------------------------"
echo "     Install FPC$vBits Starting Bootstrap Compile Files"
echo "------------------------------------------------"
echo "   "
sudo $v7zipexe x $vCTDir/allzips/binfpc/${vCPUOS}_bootstrap.7z -o$vFpcBinDir/ -y

sudo chmod -R 777 $vFpcBinDir
sudo chmod -R 777 $vFpcDir

sudo rm -f $vOSBinDir/$vFpcExeFile
sudo rm -f $vOSBinDir/fpc$vBits
sudo ln -s $vFpcExeDir/$vFpcExeFile $vOSBinDir/$vFpcExeFile
sudo ln -s $vFpcExeDir/$vFpcExeFile $vOSBinDir/fpc$vBits

}

# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

cbInstallBits=$1

case $cbInstallBits in
  32)
     if [ $vUseMultiArch = 1 ] ;
      then 
        setdummy32
        dothejob 
      else 
        dothejob
      fi
    ;;
  64)
     dothejob
    ;; 
  *)
     dothejob

     if [ $vUseMultiArch = 1 ] ;
      then 
        setdummy32
        dothejob       
      fi
    ;;
  esac 

echo "    "


