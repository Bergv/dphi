# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#      This Script Install to OpenIndiana (Solaris clone)
#      base libraries to Build and Run CodeTyphon
# =============================================================
# Update 08-05-2015 for OpenIndiana 151a9
# Update 15-08-2017 for OpenIndiana Hipster 2017.04
# Update 31-10-2017 for OpenIndiana Hipster 2017.10
# Update 06-05-2020 for OpenIndiana Hipster 2020.04
# Update 04-04-2021 for OpenIndiana Hipster 2021.04
#========================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for" 
echo "              OpenIndiana" 
echo "----------------------------------------------------"
echo "   "

echo "[INFO] Start OS Update..."
echo "   "
sudo pkg update

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

sudo pkg install xterm 
sudo pkg install zip
sudo pkg install unzip
sudo pkg install p7zip
sudo pkg install wget

sudo pkg install illumos-gcc 
sudo pkg install gcc-10

sudo pkg install gdb
sudo pkg install gnu-binutils 
sudo pkg install developer/gnu 
sudo pkg install libxtst


# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo pkg install qt4   
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo pkg install gtk+-3.0   
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo pkg install gtk+-4.0   
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo pkg install qt5  
fi

echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation"  
echo "Finish !!!"

#sleep 5
