# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

# ======================== Check build =====================
checkbuild() 
{

# ---- Don't build Typhon32 IDE for MacOS GTK2 Platform ----
if [ $vOSName = darwin ] ;
then
if [ $vLCLplat = 0 ] ; 
then
 echo " "
 echo "----------------------------------------------------" 
 echo "[INFO]: On MacOS GTK2 Platform NOT support 32bits" 
 echo "          Typhon32 Small IDE build Aborted..."
 echo "----------------------------------------------------"  
 echo " "
 
 exit
fi

if [ $vLCLplat = 1 ] ; 
then
 echo " "
 echo "----------------------------------------------------" 
 echo "[INFO]: On MacOS QT4 Platform NOT support 32bits" 
 echo "          Typhon32 Small IDE build Aborted..."
 echo "----------------------------------------------------"  
 echo " "
 
 exit
fi

if [ $vLCLplat = 7 ] ; 
then
 echo " "
 echo "----------------------------------------------------" 
 echo "[INFO]: On MacOS QT5 Platform NOT support 32bits" 
 echo "          Typhon32 Small IDE build Aborted..."
 echo "----------------------------------------------------"  
 echo " "
 
 exit
fi

fi
}

# ======================== CheckQT =========================
checkforqt() 
{

# ----------- For MacOS -----------
if [ $vOSName = darwin ] ;
then  
 
if [ $vLCLplat = 1 ] ;
then 
  if [ ! -f /usr/${vOSLibSub}/Qt4Pas.framework ] ; 
  then 
   ./ln_Typhon1_QT4pas_Install.sh
  fi
fi
if [ $vLCLplat = 7 ] ;
then 
  if [ ! -f /usr/${vOSLibSub}/Qt5Pas.framework ] ; 
  then 
   ./ln_Typhon1_QT5pas_Install.sh
  fi
fi

else
# ----------- For Unix -----------

if [ $vLCLplat = 1 ] ;
then 
  if [ ! -f /usr/${vOSLibSub}/libQt4Pas.so ] ; 
  then 
   ./ln_Typhon1_QT4pas_Install.sh
  fi
fi
if [ $vLCLplat = 7 ] ;
then 
  if [ ! -f /usr/${vOSLibSub}/libQt5Pas.so ] ; 
  then 
   ./ln_Typhon1_QT5pas_Install.sh
  fi
fi
 
fi
}

# ======================== DoTheJob =========================
dothejob() 
{
echo "   "
echo "============================================================="
echo "  Build Typhon32 Small IDE $vCPUOSPlat for $vHostOSRealName"
echo "============================================================="
echo "   "

if [ ! -f $vOSBinDir/fpc$vBits ] ;
then    
    echo "[INFO]: FrePascal NOT exist, start FPC building..."
   ./ln_FPC32_Build.sh
fi

if [ ! -f $vCTDir/typhon/Makefile.fpc ] ;
then    
   ./ln_Typhon0_Exract_Source_from_ZipFile.sh
fi

# =================== Clear All Settings ===============================

./ln_Typhon_Settings_Clean.sh

# =================== Prepare ==========================================

if [ ! -d $vCTDir/typhon/bin$vBits ] ;
then   
  sudo mkdir $vCTDir/typhon/bin$vBits
fi

./ln_Typhon_Settings_Restore.sh

if [ -f $vCTDir/typhon/bin$vBits/styphon ] ;
then  
 sudo rm -f $vCTDir/typhon/bin$vBits/styphon
fi

if [ -f $vCTDir/typhon/bin$vBits/CT_Is_BigIDE.ctsw ] ;
then  
 sudo rm -f $vCTDir/typhon/bin$vBits/CT_Is_BigIDE.ctsw
fi

# =================== Build Typhon32 ==================================

sudo chmod -R 777 $vCTDir/typhon/

cd $vCTDir/typhon

#if [ $vOSName = solaris ] ;
#then
#$vMake all OPT="-Xn" PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=usr/local/codetyphon/typhon/
#$vMake all LCL_PLATFORM=gtk2 OPT="-Xn" PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=usr/local/codetyphon/typhon/ 
#else
#fi

case $vLCLplat in
  0)
     $vMake all LCL_PLATFORM=gtk2 PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=usr/local/codetyphon/typhon/
    ;;
  1)
     $vMake all LCL_PLATFORM=qt OPT="-dUSE_QT_45" PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=usr/local/codetyphon/typhon/
    ;;
  3)
     $vMake all LCL_PLATFORM=gtk3 PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=usr/local/codetyphon/typhon/
    ;;
  4)
     $vMake all LCL_PLATFORM=customdrawn PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=usr/local/codetyphon/typhon/
    ;;
  5)
     $vMake all LCL_PLATFORM=carbon PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=usr/local/codetyphon/typhon/    
    ;;
  6)
     $vMake all LCL_PLATFORM=cocoa PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=usr/local/codetyphon/typhon/    
    ;;
  7)
     $vMake all LCL_PLATFORM=qt5 PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=usr/local/codetyphon/typhon/    
    ;;
  8)
     $vMake all LCL_PLATFORM=fpgui PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=usr/local/codetyphon/typhon/    
    ;;
  9)
     $vMake all LCL_PLATFORM=gtk4 PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=usr/local/codetyphon/typhon/
    ;;
  *)
     $vMake all PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=usr/local/codetyphon/typhon/ 
    ;;
esac 


# sleep 120

# ================= Move Bin files ====================================

sudo mv -f typhon $vCTDir/typhon/bin$vBits/
sudo mv -f typhonstart $vCTDir/typhon/bin$vBits/
sudo mv -f typhonbuild $vCTDir/typhon/bin$vBits/
sudo mv -f tools/ctres $vCTDir/typhon/bin$vBits/
sudo mv -f tools/ctlrstofrm $vCTDir/typhon/bin$vBits/

# ================= Make Permitions ===================================

sudo chmod -R 777 $vCTDir/typhon/

# -------------- Clean Tools Directory -----------------------
echo "   "
echo " ------------------------------------------------------"
echo "   "
echo "[INFO]: Clean Tools Directory"  
echo "   "

find $vCTDir/typhon/tools -type f -iname "*.o" -exec rm -f {} \;
find $vCTDir/typhon/tools -type f -iname "*.ppu" -exec rm -f {} \;


# ============================ Check Building ===========================

if [ -f $vCTDir/typhon/bin$vBits/typhon ] ;
then    

# ================= Strip Bin files ====================================
cd $vCTDir/ScriptsLin
./ln_Typhon_Strip.sh 32

# ================= Make links =========================================
cd $vCTDir/ScriptsLin
./ln_xCodeTyphon_Make_Links.sh 32

 cd $vCTDir/typhon

 echo "   "
 echo "[FINAL INFO]: Typhon32 Small IDE $vCPUOSPlat Build OK !!!"  
 echo "   "

else

 echo "   "
 echo  "??????????????????????????????????????????????????????????"
 echo  "[ERROR]: Sorry, Typhon32 Small IDE $vCPUOSPlat NOT Build"
 echo  "??????????????????????????????????????????????????????????"

fi

}


# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

checkbuild
checkforqt

if [ $vBits = 32 ] ;
then 
 dothejob
else
  if [ $vUseMultiArch = 1 ] ;
  then 
    setdummy32
    dothejob 
  fi
fi

