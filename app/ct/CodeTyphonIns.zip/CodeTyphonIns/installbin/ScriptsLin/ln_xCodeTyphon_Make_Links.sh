# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


dothejob() 
{

    
echo "   "
echo "[INFO]: make some links for Typhon$vBits and user [ $vctuser ]..."
echo "   "
  
#=================== MacOS ===================================================

if [ $vOSName = darwin ] ;
then 

# Remove old links

sudo rm -f $vOSBinDir/typhon-ide$vBits
sudo rm -f $vOSBinDir/typhonbuild$vBits
sudo rm -f $vOSBinDir/typhonstart$vBits

if [ -f $vOSAppDskDir/Typhon$vBits.app ] ;
then
  sudo chmod 777 $vOSAppDskDir/Typhon$vBits.app
  sudo rm -f $vOSAppDskDir/Typhon$vBits.app
fi

# Make New links
if [ -f $vCTDir/typhon/bin$vBits/typhon ] ;
then
 
 sudo chmod 777 $vCTDir/typhon/bin$vBits/typhon
 sudo chmod 777 $vCTDir/typhon/bin$vBits/typhonstart
 sudo chmod -R 777 $vCTDir/binSettings/settings/allformacos/typhon.app
 sudo chmod -R 777 $vCTDir/binSettings/settings/allformacos/typhonstart.app
 sudo chmod -R 777 $vCTDir/binSettings/settings/allformacos/Typhon$vBits.app

if [ -d $vCTDir/typhon/bin$vBits/typhon.app ] ;
then
 sudo chmod -R 777 $vCTDir/typhon/bin$vBits/typhon.app
 sudo rm -fr $vCTDir/typhon/bin$vBits/typhon.app
fi

if [ -d $vCTDir/typhon/bin$vBits/typhonstart.app ] ;
then
 sudo chmod -R 777 $vCTDir/typhon/bin$vBits/typhonstart.app
 sudo rm -fr $vCTDir/typhon/bin$vBits/typhonstart.app
fi

sudo cp -fr $vCTDir/binSettings/settings/allformacos/typhon.app $vCTDir/typhon/bin$vBits/
sudo ln -f -s $vCTDir/typhon/bin$vBits/typhon $vCTDir/typhon/bin$vBits/typhon.app/Contents/MacOS/typhon
sudo ln -f -s $vCTDir/typhon/bin$vBits/typhonstart $vCTDir/typhon/bin$vBits/typhon.app/Contents/Resources/typhonstart.app/Contents/MacOS/typhonstart
sudo chmod -R 777 $vCTDir/typhon/bin$vBits/typhon.app

sudo cp -fr $vCTDir/binSettings/settings/allformacos/typhonstart.app $vCTDir/typhon/bin$vBits/
sudo ln -f -s $vCTDir/typhon/bin$vBits/typhonstart $vCTDir/typhon/bin$vBits/typhonstart.app/Contents/MacOS/typhonstart
sudo chmod -R 777 $vCTDir/typhon/bin$vBits/typhonstart.app

sudo ln -f -s $vCTDir/typhon/bin$vBits/typhonstart.app $vOSAppDskDir/Typhon$vBits.app
sudo chmod 777 $vOSAppDskDir/Typhon$vBits.app


sudo ln -f -s $vCTDir/typhon/bin$vBits/typhon.app $vOSBinDir/typhon-ide$vBits
sudo ln -f -s $vCTDir/typhon/bin$vBits/typhonbuild.app $vOSBinDir/typhonbuild$vBits
sudo ln -f -s $vCTDir/typhon/bin$vBits/typhonstart.app $vOSBinDir/typhonstart$vBits

fi

else
#=============== OTHER UNIXs =================================================
# Remove old links

sudo rm -f $vOSBinDir/typhon-ide$vBits
sudo rm -f $vOSBinDir/typhonbuild$vBits
sudo rm -f $vOSBinDir/typhonstart$vBits  

sudo rm -f $vOSAppDskDir/typhon$vBits.desktop
sudo rm -f $vOSAppXmlDir/typhon$vBits.xml
sudo rm -f $vOSAppPngDir/typhon$vBits.png 

if [ -f $vctuserdesk/typhon$vBits.desktop ] ;
then
sudo rm -f $vctuserdesk/typhon$vBits.desktop
fi
  
# Make New links
if [ -f $vCTDir/typhon/bin$vBits/typhon ] ;
then
  
  sudo cp -f ../binSettings/settings/allforunix/typhon-ide.1.gz /usr/share/man/man1/
  sudo cp -f ../binSettings/settings/allforunix/typhonbuild.1.gz /usr/share/man/man1/
  sudo cp -f ../binSettings/settings/allforunix/typhonstart.1.gz /usr/share/man/man1/
  
  sudo ln -f -s $vCTDir/typhon/bin$vBits/typhon $vOSBinDir/typhon-ide$vBits
  sudo ln -f -s $vCTDir/typhon/bin$vBits/typhonbuild $vOSBinDir/typhonbuild$vBits
  sudo ln -f -s $vCTDir/typhon/bin$vBits/typhonstart $vOSBinDir/typhonstart$vBits    

  sudo cp -f ../binSettings/settings/allforunix/typhon$vBits.desktop $vOSAppDskDir/
  sudo cp -f ../binSettings/settings/allforunix/typhon$vBits.xml $vOSAppXmlDir/
  sudo cp -f ../binSettings/settings/allforunix/typhon$vBits.png $vOSAppPngDir/
   
  sudo chmod 777 $vOSAppDskDir/typhon$vBits.desktop
  sudo chmod 777 $vOSAppXmlDir/typhon$vBits.xml
  sudo chmod 777 $vOSAppPngDir/typhon$vBits.png
    
if [ -d $vctuserdesk ] ;
then
  sudo cp -f ../binSettings/settings/allforunix/typhon$vBits.desktop $vctuserdesk/
  sudo chmod 777 $vctuserdesk/typhon$vBits.desktop
  sudo chown $vctuser $vctuserdesk/typhon$vBits.desktop
fi  
 
fi

fi
}

# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

cmlBuildingBits=$1

case $cmlBuildingBits in
  32)   
     if [ $vUseMultiArch = 1 ] ;
     then    
       setdummy32
       dothejob
     else
       dothejob
     fi
    ;;
  64)  
       dothejob    
    ;; 
  *)  
     if [ $vUseMultiArch = 1 ] ;
     then  
       dothejob  
       setdummy32
       dothejob
     else
       dothejob
     fi

    ;;
esac 








