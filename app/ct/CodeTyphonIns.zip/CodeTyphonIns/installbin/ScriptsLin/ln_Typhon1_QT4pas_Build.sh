# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


# ======================= Findqmake4 =========================
findqmake4()
{

# Debian 8.6 has /usr/lib/x86_64-linux-gnu/qt4/bin/qmake
# Debian 8.6 has /usr/lib/x86_64-linux-gnu/qt5/bin/qmake

# Fedora 25  has /usr/lib/qt4/bin/qmake
# Fedora 25  has /usr/lib/qt5/bin/qmake
# Fedora 25  has /usr/lib64/qt4/bin/qmake
# Fedora 25  has /usr/lib64/qt5/bin/qmake

vQMake=qmake
BLQMake=error

case $vHostOSRealName in
  Linux)    
  
# ---- these settings are for Ubuntu Linux -------  
      if [ $vBits = 32 ] ;
       then
        vQMake=/usr/lib/i386-linux-gnu/qt4/bin/qmake
       else
        vQMake=/usr/lib/x86_64-linux-gnu/qt4/bin/qmake
       fi
#-------------------------------------------------       
   ;;
  FreeBSD)    
      vQMake=/usr/local/lib/qt4/bin/qmake   
   ;;
  OpenBSD) 
      vQMake=/usr/local/lib/qt4/bin/qmake        
   ;;
  NetBSD) 
      vQMake=/usr/pkg/qt4/bin/qmake 
   ;;
  DragonFly) 
      vQMake=/usr/local/lib/qt4/bin/qmake
   ;;
  SunOS)
      vQMake=qmake   
   ;;
  Darwin)        
       vQMake=/opt/local/libexec/qt4/bin/qmake      
   ;;
esac


if [ -f $vQMake ] ;
then
  BLQMake=$vQMake
fi

if [ $BLQMake = error ] ;
then

echo "   "
echo "[ERROR]: qmake Executable NOT Found, QT4 Library Build Aborted."
echo "         Please sent this error to PilotLogic for fix"
echo "   "
exit

else

echo "   "
echo "-----------------------------------------------------------"
echo "[INFO]:USE qmake file from $BLQMake."
$BLQMake -v
echo "-----------------------------------------------------------"
echo "   "

fi
}

# ======================= Unzip ===============================
unzipqt4pas() 
{

#------------- Remove OLD QT4Pas Directory -------------

if [ -d $vCTDir/qt4pas ] ;
then 
  sudo rm -fr $vCTDir/qt4pas
  echo "[INFO]: OLD QT4Pas Directory Removed."  
fi


echo "   "
echo "---------------------------------------------------------"
echo "      Unzip qt4pas sources"   
echo "---------------------------------------------------------"
echo "   "

sudo mkdir $vCTDir/qt4pas/

sudo $v7zipexe x ../allzips/src/qt4pas.7z -o$vCTDir/ -y 

sudo chmod -R 777 $vCTDir/qt4pas/

}


# ======================= Build For Unix ===========================
buildqt4pas_unix() 
{ 

cd $vCTDir/qt4pas/${vCPUOS}

#---- Remove OLD Libraries and Links from Folder -------

  if [ -f $vCTDir/qt4pas/${vCPUOS}/libQt4Pas.so ] ;
  then  
    sudo rm -f $vCTDir/qt4pas/${vCPUOS}/libQt4Pas.so
  fi
  
  if [ -f $vCTDir/qt4pas/${vCPUOS}/libQt4Pas.so.5 ] ;
  then  
    sudo rm -f $vCTDir/qt4pas/${vCPUOS}/libQt4Pas.so.5
  fi
  
  if [ -f $vCTDir/qt4pas/${vCPUOS}/libQt4Pas.so.5.2 ] ;
  then  
    sudo rm -f $vCTDir/qt4pas/${vCPUOS}/libQt4Pas.so.5.2
  fi
  
  if [ -f $vCTDir/qt4pas/${vCPUOS}/libQt4Pas.so.5.2.8 ] ;
  then  
    sudo rm -f $vCTDir/qt4pas/${vCPUOS}/libQt4Pas.so.5.2.8
  fi

echo "   "
echo "------------- Qt Info --------------------------"
echo "   "

$BLQMake -query

echo "   "
echo "-------------- Build and Install QT4pas ------------------------------"
echo "   " 

$BLQMake

sudo $vMake install

echo "   "

if [ -f $vCTDir/qt4pas/${vCPUOS}/libQt4Pas.so.5.2.8 ] ;
then 
  echo "---------------------------------------"
  echo "[INFO]: QT4pas Libraries finish Build OK for $vCPUOS"
  echo "   "
else
  echo "---------------------------------------"
  echo "[ERROR]: QT4pas Libraries Don't Build...???"
  echo "   "
fi

}


# ======================= Build For MacOS ===========================
buildqt4pas_macos() 
{ 

cd $vCTDir/qt4pas/${vCPUOS}

#---- Remove OLD Libraries and Links from Folder -------

if [ -d /usr/${vOSLibSub}/Qt4Pas.framework ] ;
then  
    sudo rm -fr $vCTDir/qt4pas/${vCPUOS}/Qt4Pas.framework
fi

echo "   "
echo "------------- Qt Info --------------------------"
echo "   "

$BLQMake -query

echo "   "
echo "-------------- Build and Install QT4pas ------------------------------"
echo "   " 

$BLQMake

sudo $vMake install

echo "   "

sudo cp -fr /opt/local/lib/Qt4Pas.framework $vCTDir/qt4pas/${vCPUOS}
sudo chmod -R 777 $vCTDir/qt4pas/

echo "   "

if [ -d $vCTDir/qt4pas/${vCPUOS}/Qt4Pas.framework ] ;
then

  sudo rm -fr /opt/local/lib/Qt4Pas.framework
  
  echo "---------------------------------------"
  echo "[INFO]: Qt4Pas.framework Library finish Build OK for $vCPUOS"
  echo "   "
else
  echo "---------------------------------------"
  echo "[ERROR]: Qt4Pas.framework Library Don't Build...???"
  echo "   "
fi

}

# ======================= dothejob ===============================
dothejob() 
{

echo "  "
echo "---------------------------------------------------------"
echo " Try to Build QT4pas Libraries for ${vCPUOS} from Sources"   
echo "---------------------------------------------------------"

findqmake4

if [ ! -f $vCTDir/allzips/src/qt4pas.7z ] ;
then 
  echo "   "
  echo "[ERROR] qt4pas.7z file NOT Exists...Build QT4Pas STOPPED"
  echo "   " 
  exit
fi

if [ -f $BLQMake ] ;
then 
  echo "   "
  echo "[INFO] $BLQMake for QT4 Exists"
  echo "   "   
else
  echo "   "
  echo "[ERROR]: $BLQMake for QT4 NOT Exists......Build QT4Pas STOPPED"
  echo "          Install or find or link qmake for QT4 and retry"
  echo "   "
  exit
fi
 
if [ $vOSName = darwin ] ;
then 

  if [ $vBits = 64 ] ;
  then   
   unzipqt4pas
   buildqt4pas_macos
  fi
 
else
 unzipqt4pas
 buildqt4pas_unix
fi

cd $vCTDir/ScriptsLin

}

#========================MAIN===========================
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi

cd $vCTDir/ScriptsLin

./ln_Typhon1_QT4pas_Make_Links.sh


