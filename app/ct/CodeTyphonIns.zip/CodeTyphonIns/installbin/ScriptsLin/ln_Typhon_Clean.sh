# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

if [ ! -d $vCTDir/typhon ] ;
then  
 echo "[ERROR]: Typhon Directory NOT EXIST !!!"
 exit
fi 
  
cd $vCTDir/typhon/  

echo " "
echo "----------------------------------------------------------"
echo "[INFO]: Clean with FPC$vBits"
echo "----------------------------------------------------------"
echo " "

sudo $vMake clean PP=$vFpcExeDir/$vFpcExeFile  

}

# ==================== unused directories =====================
cleanUnsedDirs() 
{

echo " "
echo "----------------------------------------------------------"
echo "[INFO]: Remove unused directories"
echo "----------------------------------------------------------"
echo " "

#--------- Main Units --------
cd $vCTDir/

sudo rm -fr typhon/units
sudo rm -fr typhon/lcl/units
sudo rm -fr typhon/packager/units
sudo rm -fr typhon/tools/lib

sudo find $PWD/typhon -type f -iname "*.bak" -exec rm -f {} \;

# --------- Components ---------

sudo find $PWD/typhon/components -type d -iname "units" -exec rm -rf {} \;
sudo find $PWD/typhon/components -type d -iname "lib" -exec rm -rf {} \;

# --------- Source -------------
sudo find $PWD/typhon -type f -iname "*.bak" -exec rm -f {} \;
sudo find $PWD/typhon -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/typhon -type f -iname "*.ppu" -exec rm -f {} \;
sudo find $PWD/typhon -type f -iname "*.rst" -exec rm -f {} \;
sudo find $PWD/typhon -type f -iname "*.rsj" -exec rm -f {} \;

# --------- Tools ----

sudo rm -f typhon/tools/ctapimatrix/ctapimatrix
sudo rm -f typhon/tools/ctchmbuilder/ctchmbuilder
sudo rm -f typhon/tools/ctchmviewer/ctchmviewer
sudo rm -f typhon/tools/ctdatadesktop/ctdatadesktop
sudo rm -f typhon/tools/ctdebugserver/ctdebugserver
sudo rm -f typhon/tools/ctdiagramins/ctdiagramins
sudo rm -f typhon/tools/ctdoceditor/ctdoceditor
sudo rm -f typhon/tools/ctdocbuilder/ctdocbuilder
sudo rm -f typhon/tools/cthexeditor/cthexeditor
sudo rm -f typhon/tools/ctimageeditor/ctimageeditor
sudo rm -f typhon/tools/ctjsonviewer/ctjsonviewer
sudo rm -f typhon/tools/ctpobuilder/ctpobuilder
sudo rm -f typhon/tools/ctresbuilder/ctresbuilder
sudo rm -f typhon/tools/ctunieditor/ctunieditor

sudo rm -f typhon/tools/ctres
sudo rm -f typhon/tools/ctlrstofrm
sudo rm -f typhon/tools/svn2revisioninc
sudo rm -f typhon/tools/updatepofiles


sudo find $PWD/typhon/tools -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/typhon/tools -type f -iname "*.ppu" -exec rm -f {} \;
sudo find $PWD/typhon/tools -type f -iname "*.compiled" -exec rm -f {} \;

sudo find $PWD/typhon/tools -type d -iname "*.app" -exec rm -rf {} \;
sudo find $PWD/typhon/tools -type d -iname "lib" -exec rm -rf {} \;

cd $vCTDir/ScriptsLin/ 
}

# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

echo " "
echo "=========================================================="
echo "         Clean Typhon IDE Directory"
echo "=========================================================="

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi

cleanUnsedDirs

echo " "
echo "[FINAL INFO]: Clean Typhon IDE Directory Finish."
echo " "


