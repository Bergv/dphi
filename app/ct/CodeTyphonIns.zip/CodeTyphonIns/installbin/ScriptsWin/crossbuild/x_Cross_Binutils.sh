# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{
# ===================== Build Binutils ==================

cd C:/codetyphon/CrossEng/binutils  


if [ -d build ] ;
then     
    echo "[INFO]: Remove OLD temporary BUILD directory..."
    rm -rf build
    echo "  "
fi
  
mkdir build
cd build

echo "-------- configure -----------"
 
../configure --prefix=C:/codetyphon/CrossEng/binutilsout --target=$buTARGETCPUOS --disable-nls --disable-werror --disable-shared


echo " "
echo "-------- make ----------------"
make -j4

echo " "
echo "-------- make install --------"
make -j4 install

}

# =================== MAIN =============================

buFPCType=$1
buFPCCPUOS=$2
buFPCStartEXE=$3
buTARGETCPU=$4
buTARGETOS=$5
buFPCCrossEXE=$6
buParam=$7
buTARGETCPUOS=${buTARGETCPU}-${buTARGETOS}


echo "   "
echo "-----------------------------------------------"
echo "   GNU Cross toolschains Engine settings"
echo "-----------------------------------------------"
echo "   "
echo $buFPCType
echo $buFPCCPUOS
echo $buFPCStartEXE
echo $buTARGETCPU
echo $buTARGETOS
echo $buFPCCrossEXE
echo $buTARGETCPUOS
echo $buParam
echo "   "

dothejob

