# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

#========================MAIN===========================
. $PWD/ln_All_Functions.sh
getvalues

# ---------------- Extract Typhon ----------------------------

if [ -f ../allzips/src/typhon_src.7z.001 ] ;
then  

  if [ ! -d $vCTDir/typhon/ ] ;
   then  
     sudo mkdir $vCTDir/typhon/  
   fi

echo "   "
echo "---------------------------------------------------------"
echo "     Extract Typhon Source From Zip File"   
echo "---------------------------------------------------------"

sudo $v7zipexe x ../allzips/src/typhon_src.7z.001 -o$vCTDir/ -y

sudo chmod -R 777 $vCTDir/typhon/

echo "---------------------------------------"
echo "[INFO]: Extract Typhon source finish"
echo "   "

else

echo "---------------------------------------"
echo "[ERROR]: Typhon Source Zip File NOT EXIST ???"
echo "   "

fi

# ---------------- Extract CodeOcean ----------------------------
   
./ln_Typhon0_Exract_CodeOcean_from_ZipFile.sh 

# ---------------- Extract DocFactory ------------------------------

./ln_Typhon0_Exract_DocFactory_from_ZipFile.sh  

# ---------------- Extract Runtimes ------------------------------

./ln_Typhon0_Exract_Runtimes_from_ZipFile.sh   

