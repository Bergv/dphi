# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

# =================== buildtool =============================
buildtool() 
{
echo "   " 
echo "[INFO]: ------------- Build$vBits $ctbbuildtool ----------------------"
echo "   "

if [ -d $vCTDir/typhon/bin$vBits/$ctbbuildtool.app ] ;
then   
  sudo rm -fr $vCTDir/typhon/bin$vBits/$ctbbuildtool.app
fi
 
 case $vLCLplat in
  1)
     $vCTDir/typhon/bin$vBits/typhonbuild --build-all --ws=qt $vCTDir/typhon/tools/$ctbbuildtool/$ctbbuildtool.ctpr
    ;;
  3)
     $vCTDir/typhon/bin$vBits/typhonbuild --build-all --ws=gtk3 $vCTDir/typhon/tools/$ctbbuildtool/$ctbbuildtool.ctpr
    ;;
  4)
     $vCTDir/typhon/bin$vBits/typhonbuild --build-all --ws=customdrawn $vCTDir/typhon/tools/$ctbbuildtool/$ctbbuildtool.ctpr
    ;;
  5)
     $vCTDir/typhon/bin$vBits/typhonbuild --build-all --ws=carbon $vCTDir/typhon/tools/$ctbbuildtool/$ctbbuildtool.ctpr
    ;;
  6)
     $vCTDir/typhon/bin$vBits/typhonbuild --build-all --ws=cocoa $vCTDir/typhon/tools/$ctbbuildtool/$ctbbuildtool.ctpr
    ;;
  7)
     $vCTDir/typhon/bin$vBits/typhonbuild --build-all --ws=qt5 $vCTDir/typhon/tools/$ctbbuildtool/$ctbbuildtool.ctpr
    ;;
  8)
     $vCTDir/typhon/bin$vBits/typhonbuild --build-all --ws=fpgui $vCTDir/typhon/tools/$ctbbuildtool/$ctbbuildtool.ctpr
    ;;
  9)
     $vCTDir/typhon/bin$vBits/typhonbuild --build-all --ws=gtk4 $vCTDir/typhon/tools/$ctbbuildtool/$ctbbuildtool.ctpr
    ;;
  *)
     $vCTDir/typhon/bin$vBits/typhonbuild --build-all --ws=$vLCLPlatStr $vCTDir/typhon/tools/$ctbbuildtool/$ctbbuildtool.ctpr
    ;;
  esac 

if [ -f $vCTDir/typhon/bin$vBits/$ctbbuildtool ] ;
then 
  echo "   " 
  echo "---- $ctbbuildtool $vBits OK"
  echo "   "    
else  
  echo "   " 
  echo "??????????????????????????????????????????????????" 
  echo "[ERROR]:Problem $ctbbuildtool $vBits NOT Build ???"
  echo "??????????????????????????????????????????????????" 
  echo "   "  
fi

if [ -d $vCTDir/typhon/tools/lib ] ;
then 
  sudo rm -fr $vCTDir/typhon/tools/lib
fi

if [ $vOSName = darwin ] ;
then
  sudo cp -fr $vCTDir/binSettings/settings/allformacos/$ctbbuildtool.app $vCTDir/typhon/bin$vBits/
  sudo ln -f -s $vCTDir/typhon/bin$vBits/$ctbbuildtool $vCTDir/typhon/bin$vBits/$ctbbuildtool.app/Contents/MacOS/$ctbbuildtool
  sudo chmod -R 777 $vCTDir/typhon/bin$vBits/$ctbbuildtool.app
fi
}

# =================== dothejob =============================
dothejob() 
{

if [ ! -f $vCTDir/typhon/bin$vBits/typhonbuild ] ;
then  
  exit
fi

echo "   "
echo " -----------------------------------------------"
echo "              Build Typhon$vBits Tools          "
echo " -----------------------------------------------"
echo "   "

ctbbuildtool=ctchmbuilder
buildtool

ctbbuildtool=ctchmviewer
buildtool

ctbbuildtool=ctdatadesktop
buildtool

ctbbuildtool=ctdiagramins
buildtool

ctbbuildtool=cthexeditor
buildtool

ctbbuildtool=ctimageeditor
buildtool

ctbbuildtool=ctjsonviewer
buildtool

ctbbuildtool=ctpobuilder
buildtool

ctbbuildtool=ctresbuilder
buildtool

ctbbuildtool=ctdoceditor
buildtool

ctbbuildtool=ctdocbuilder
buildtool

ctbbuildtool=ctunieditor
buildtool

ctbbuildtool=ctschemaeditor
buildtool

ctbbuildtool=ctdebugserver
buildtool


# -----------------------------

if [ -f $vCTDir/typhon/tools/ctres ] ;
then 
  sudo mv -f $vCTDir/typhon/tools/ctres $vCTDir/typhon/bin$vBits/ 
fi

if [ -f $vCTDir/typhon/tools/ctlrstofrm ] ;
then 
  sudo mv -f $vCTDir/typhon/tools/ctlrstofrm $vCTDir/typhon/bin$vBits/
fi

# ------- Clean tools Directory --------------
echo "   " 
echo "[INFO]: ------- Clean tools Directory ---------"

find $vCTDir/typhon/tools -type f -iname "*.o" -exec rm -f {} \;
find $vCTDir/typhon/tools -type f -iname "*.ppu" -exec rm -f {} \;
find $vCTDir/typhon/tools -type f -iname "*.compiled" -exec rm -f {} \;

}

# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

ctbBuildingBits=$1

case $ctbBuildingBits in
  32)   
     if [ $vUseMultiArch = 1 ] ;
     then    
       setdummy32
       dothejob
     else
       dothejob
     fi
    ;;
  64)  
       dothejob    
    ;; 
  *)  
     if [ $vUseMultiArch = 1 ] ;
     then  
       dothejob  
       setdummy32
       dothejob
     else
       dothejob
     fi

    ;;
esac 






