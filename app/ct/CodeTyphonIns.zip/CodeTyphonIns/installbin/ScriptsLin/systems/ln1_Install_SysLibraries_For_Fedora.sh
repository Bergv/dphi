# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#     This Script Install to Fedora Linux 
#     base libraries to Build and Run CodeTyphon   
# =============================================================
# Update 25-04-2014 for Fedora 20 with MultiArch for GTK2 and QT
# Update 11-12-2014 for Fedora 21 with MultiArch for GTK2 and QT
# Update 28-05-2014 for Fedora 22 with MultiArch for GTK2 and QT
# Update 07-11-2015 for Fedora 23 with MultiArch , MultiPlatform for GTK2, QT4 and QT5
# Update 07-11-2015 for Fedora 25 with MultiArch , MultiPlatform for GTK2, QT4 and QT5
# Update 31-10-2018 for Fedora 29 with MultiArch , MultiPlatform for GTK2, QT4 and QT5
# Update 30-10-2019 for Fedora 31 with MultiArch , MultiPlatform for GTK2, QT4 and QT5
# Update 28-04-2020 for Fedora 32 with MultiArch , MultiPlatform for GTK2, QT4 and QT5
# Update 30-10-2020 for Fedora 33 with MultiArch , MultiPlatform for GTK2, QT4 and QT5
# Update 28-04-2021 for Fedora 34 with MultiArch , MultiPlatform for GTK2, GTK3, GTK4, QT4 and QT5
#========================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for" 
echo "              Fedora Linux" 
echo "----------------------------------------------------"
echo "   "

# --- OS pkg manager  -----

case $(uname -r) in 
 *fc1*)
    pkgman=yum
    ;; 
 *fc20*)
    pkgman=yum
    ;; 
 *fc21*)
    pkgman=yum
    ;; 
 *)
    pkgman=dnf
    ;;    
esac

echo "   "
echo "[INFO] use $pkgman manager..."
echo "   "

# --- OS Update  -----

echo "[INFO] Start OS Update..."
echo "   "
sudo $pkgman update -y 

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

sudo $pkgman install -y xterm 
sudo $pkgman install -y zip 
sudo $pkgman install -y unzip
sudo $pkgman install -y wget

sudo $pkgman install -y make 
sudo $pkgman install -y kernel-devel 
sudo $pkgman install -y kernel-headers 
sudo $pkgman install -y gcc 
sudo $pkgman install -y gcc-c++
sudo $pkgman install -y gdb 
sudo $pkgman install -y binutils 

sudo $pkgman install -y glib-devel 
sudo $pkgman install -y glibc-devel 
sudo $pkgman install -y libX11-devel
sudo $pkgman install -y libXtst
sudo $pkgman install -y libXtst-devel
sudo $pkgman install -y mesa-libGLU 
sudo $pkgman install -y libGL* 
sudo $pkgman install -y freeglut 
sudo $pkgman install -y xorg-x11-font*

if [ $ciUseMultiArch = 1 ] ; 
then
  sudo $pkgman install -y glib-devel.i686  
  sudo $pkgman install -y glibc-devel.i686  
  sudo $pkgman install -y libX11-devel.i686 
  sudo $pkgman install -y libXtst.i686 
  sudo $pkgman install -y libXtst-devel.i686
  sudo $pkgman install -y mesa-libGLU.i686
  sudo $pkgman install -y freeglut.i686   
fi

# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    sudo $pkgman install -y gtk2-devel 
    sudo $pkgman install -y gtk+extra 
    sudo $pkgman install -y gtk+-devel
    sudo $pkgman install -y cairo-devel 
    sudo $pkgman install -y cairo-gobject-devel
    sudo $pkgman install -y pango-devel 

    
    if [ $ciUseMultiArch = 1 ] ; 
    then
      sudo $pkgman install -y gtk2-devel.i686 
      sudo $pkgman install -y gtk+extra.i686  
      sudo $pkgman install -y gtk+-devel.i686 
      sudo $pkgman install -y cairo-devel.i686  
      sudo $pkgman install -y cairo-gobject-devel.i686 
      sudo $pkgman install -y pango-devel.i686    
    fi

fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT"
    echo "   "
            
    sudo $pkgman install -y qt-devel
    sudo $pkgman install -y qt-config  
    sudo $pkgman install -y qt4-devel  
    sudo $pkgman install -y qtwebkit.x86_64

    if [ $ciUseMultiArch = 1 ] ; 
    then
      sudo $pkgman install -y qt-devel.i686 
      sudo $pkgman install -y qtwebkit.i686   
    fi

fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo $pkgman install -y gtk3
    sudo $pkgman install -y gtk3-devel 

    if [ $ciUseMultiArch = 1 ] ; 
    then
      sudo $pkgman install -y gtk3.i686  
    fi 
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo $pkgman install -y gtk4
    sudo $pkgman install -y gtk4-devel 

    if [ $ciUseMultiArch = 1 ] ; 
    then
      sudo $pkgman install -y gtk4.i686  
    fi 
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo $pkgman install -y qt5-qtbase
    sudo $pkgman install -y qt5-qtbase-devel
    sudo $pkgman install -y qt5-qtx11extras
    sudo $pkgman install -y qt5-qtx11extras-devel
  

    if [ $ciUseMultiArch = 1 ] ; 
    then
      sudo $pkgman install -y qt5-qtbase.i686
      sudo $pkgman install -y qt5-qtbase-devel.i686
      sudo $pkgman install -y qt5-qtx11extras.i686
      sudo $pkgman install -y qt5-qtx11extras-devel.i686
    fi
fi
   
echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation" 
echo "Finish !!!"

#sleep 5
