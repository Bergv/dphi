# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

#========================MAIN===========================
. $PWD/ln_All_Functions.sh
getvalues


echo "   "
echo "---------------------------------------------------------"
echo "        Extract DocFactory Samples From Zip File"   
echo "---------------------------------------------------------"

if [ -f ../allzips/DocFactory.7z ] ;
then  

  if [ ! -d $vCTDir/DocFactory/ ] ;
  then  
    sudo mkdir $vCTDir/DocFactory/  
  fi

sudo $v7zipexe x ../allzips/DocFactory.7z -o../ -y

sudo chmod -R 777 $vCTDir/DocFactory/

echo "---------------------------------------"
echo "[INFO]: Extract DocFactory Samples finish"

else

echo "---------------------------------------"
echo "[ERROR]: DocFactory Zip File NOT EXIST ???"

fi

echo "   "
