# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{
echo "-----------------------------------------------------------"
echo "         Extract FreePascal From Zip File"
echo "-----------------------------------------------------------"

if [ ! -d $vFpcSrcDir ]
then  
   sudo mkdir $vFpcSrcDir     
fi

if [ -f ../allzips/src/fpc_src.7z ] ;
then    
   sudo $v7zipexe x ../allzips/src/fpc_src.7z -o$vCTDir -y
else
   echo "[ERROR]: FreePascal Source Zip File NOT EXIST ????????"
fi

sudo chmod -R 777 $vFpcSrcDir

# ------------------------------------------------

./ln_FPC0_Extract_ChainsLibrary_From_ZipFile.sh
./ln_FPC0_Extract_Libraries_From_ZipFile.sh

# ------------------------------------------------
}

# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

dothejob

echo "---------------------------------------"
echo "[INFO]: Extract FreePascal source finish"
echo "   "


