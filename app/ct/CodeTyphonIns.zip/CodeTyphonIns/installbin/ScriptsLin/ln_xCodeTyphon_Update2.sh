# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

#-------------------------------------------------------
actmakedownloaddir() 
{
echo "   "
echo "[INFO]: Make Download Main directory"

cd ../

if [ -d zupdate ] ;
then 
  sudo rm -fr zupdate
fi

sudo mkdir zupdate
sudo chmod -R 777 zupdate/

exit
}

#-------------------------------------------------------
actmakealldirs() 
{
echo "   "
echo "[INFO]: Make Update directories"

if [ ! -d ../zupdate ] ;
then 
  echo "   "
  echo "???????????????????????????????????????????????????????????"
  echo " [ERROR]: Update temporary directory NOT exists..."
  echo "???????????????????????????????????????????????????????????"
  echo "   "
  exit
fi

sudo chmod -R 777 ../zupdate/ 

cd ../zupdate

if [ -f ${cuval4} ] ;
then 
sudo ./${cuval4}
fi

cd ../

exit
}

#-------------------------------------------------------
actupdatefiles() 
{

cd ../

if [ ! -d zupdate/allzips ] ;
then 
  echo "[ERROR]: Directory zupdate/allzips NOT Exists..."
  exit
fi

sudo chmod -R 777 zupdate/

if [ ! -d allzips ] ;
then 
  sudo mkdir allzips
fi
sudo chmod -R 777 allzips/

#-----------------------

sudo cp -fr zupdate/allzips/* allzips/ 
sudo chmod -R 777 allzips/

#-----------------------

if [ -d zupdate ] ;
then 
  sudo rm -fr zupdate
fi

#-----------------------

if [ -f allzips/binmain.7z ] ;
then 
  echo "[INFO]: Exract binmain Zip file..."
  sudo $v7zipexe x allzips/binmain.7z -o$vCTDir -y 
  sudo chmod 777 *.sh
fi
sudo chmod -R 777 bin/

if [ -f allzips/binBase.7z ] ;
then 
  echo "[INFO]: Exract binBase Zip file..."
  sudo $v7zipexe x allzips/binBase.7z -o$vCTDir -y 
  sudo chmod -R 777 binBase/
else
  echo "[ERROR]: binBase Zip file NOT Exists..."
fi
sudo chmod -R 777 binBase/

if [ -f allzips/ScriptsLin.7z ] ;
then 
  echo "[INFO]: Exract ScriptsLin Zip file..."
  sudo $v7zipexe x allzips/ScriptsLin.7z -o$vCTDir -y 
  sudo chmod -R 777 ScriptsLin/
  sudo chmod +x ScriptsLin/*.sh
else
  echo "[ERROR]: ScriptsLin Zip file NOT Exists..."
fi
sudo chmod -R 777 ScriptsLin/

if [ -f allzips/ScriptsWin.7z ] ;
then 
  echo "[INFO]: Exract ScriptsWin Zip file..."
  sudo $v7zipexe x allzips/ScriptsWin.7z -o$vCTDir -y 
  sudo chmod -R 777 ScriptsWin/
else
  echo "[ERROR]: ScriptsWin Zip file NOT Exists..."
fi

exit
}

# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

cuactn=$1
cuval2=$2
cuval3=$3
cuval4=$4
cuval5=$5
cuval6=$6

echo "   "
echo " [INFO]: CodeTyphon Update Engine settings "
echo $cuactn
echo $cuval2
echo $cuval3
echo $cuval4
echo $cuval5
echo $cuval6
echo "   "


case $cuactn in
1)
  actmakedownloaddir 
 ;;
2)
  actmakealldirs
 ;;
3)
  actupdatefiles
 ;;
esac 

echo "???????????????????????????????????????????????????????????"
echo "   [ERROR]:  Sorry NO Correct Script Parameters."
echo "???????????????????????????????????????????????????????????"

exit

