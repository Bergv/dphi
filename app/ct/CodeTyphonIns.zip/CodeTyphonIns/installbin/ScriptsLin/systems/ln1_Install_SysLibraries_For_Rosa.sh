# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#      This Script Install to Mageia Linux 
#      base libraries to Build and Run CodeTyphon
# =============================================================
# Update (15-5-2014) for Rosa Linux  (ROSA.FRESH.KDE.R3.x86_64.iso) MultiArch for QT4
# Update (22-4-2017) for Rosa Linux  (ROSA.FRESH.PLASMA.R9.x86_64.uefi.iso) MultiArch for QT5
# Update (17-12-2017) for Rosa Linux (ROSA.FRESH.PLASMA.R10.x86_64.uefi.iso) 
# Update (18-03-2019) for Rosa Linux (ROSA.FRESH.XFCE.R11.x86_64.uefi.iso) 
#========================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for" 
echo "                ROSA Linux" 
echo "----------------------------------------------------"
echo "   "
echo "[INFO] Start OS Update..."
echo "   "
sudo urpmi --auto-update

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

sudo urpmi --auto -a xterm
sudo urpmi --auto -a zip
sudo urpmi --auto -a unzip
sudo urpmi --auto -a wget

sudo urpmi --auto -a make 
sudo urpmi --auto -a gcc
sudo urpmi --auto -a gcc-c++
sudo urpmi --auto -a gdb 
sudo urpmi --auto -a binutils

sudo urpmi --auto -a glib
sudo urpmi --auto -a glibc
sudo urpmi --auto -a glibc-devel 
sudo urpmi --auto -a glib
sudo urpmi --auto -a glib-devel 
sudo urpmi --auto -a libx11
sudo urpmi --auto -a libx11-devel
sudo urpmi --auto -a libxtst6
sudo urpmi --auto -a libxtst-devel
sudo urpmi --auto -a mesa-common-devel

if [ $cicpubits = 64 ] ; then
   sudo urpmi --auto -a lib64gthread2.0_0
   sudo urpmi --auto -a lib64gmodule2.0_0 
   sudo urpmi --auto -a lib64glu1
   sudo urpmi --auto -a lib64glib2.0_0
   sudo urpmi --auto -a lib64gthread2.0_0
fi
   sudo urpmi --auto -a libglu1
   sudo urpmi --auto -a libgthread2.0_0
   sudo urpmi --auto -a libgmodule2.0_0 
   sudo urpmi --auto -a libglib2.0_0
   sudo urpmi --auto -a libgthread2.0_0

sudo urpmi --auto -a freetype2
sudo urpmi --auto -a xorg-x11-100dpi-fonts xorg-x11-75dpi-fonts 


# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then

   if [ $cicpubits = 64 ] ; then
     sudo urpmi --auto -a lib64atk1.0_0
     sudo urpmi --auto -a lib64gtk+2.0-devel 
   fi
     sudo urpmi --auto -a libatk1.0_0
     sudo urpmi --auto -a libgtk+2.0-devel 

   
   sudo urpmi --auto -a gtk2-devel
   sudo urpmi --auto -a cairo-devel 
   sudo urpmi --auto -a pango-devel
fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo urpmi --auto -a qt4-devel

    if [ $cicpubits = 64 ] ; then
     sudo urpmi --auto -a lib64qt4-devel
     sudo urpmi --auto -a lib64qtwebkit4
    fi
    sudo urpmi --auto -a libqt4-devel
    sudo urpmi --auto -a libqtwebkit4

fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo urpmi --auto -a gtk+-3.0   
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo urpmi --auto -a gtk+-4.0   
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo urpmi --auto -a qt5-devel

    if [ $cicpubits = 64 ] ; then
     sudo urpmi --auto -a lib64qt5-devel
     sudo urpmi --auto -a lib64qtwebkit5
    fi
    sudo urpmi --auto -a libqt5-devel
    sudo urpmi --auto -a libqtwebkit5 
fi

#========================================================

echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation"  
echo "Finish !!!"

#sleep 5
