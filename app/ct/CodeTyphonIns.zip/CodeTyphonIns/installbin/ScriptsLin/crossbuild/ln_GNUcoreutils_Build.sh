ansi# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ CrossEng @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

if [ ! -d $vCTDir/CrossEng ] ;
then      
    echo "   "
    echo "-------------------------------------------------------"
    echo "       Extract CrossBuild Engine..."
    echo "-------------------------------------------------------"
    echo "   "
    sudo mkdir $vCTDir/CrossEng
    sudo chmod -R 777 $vCTDir/CrossEng/
fi

# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ GNU coreutils @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

if [ -d $vCTDir/CrossEng/coreutilsout ] ;
then     
    echo "[INFO]: Remove OLD GNU coreutils temporary OUT directory..."
    sudo rm -rf $vCTDir/CrossEng/coreutilsout
fi
 
if [ ! -d $vCTDir/CrossEng/coreutils_src ] ;
then    
sudo $v7zipexe x ../../allzips/src/coreutils_src.7z -o$vCTDir/CrossEng/ -y
sudo chmod -R 777 $vCTDir/CrossEng/coreutils_src/
fi

sudo mkdir $vCTDir/CrossEng/coreutilsout
sudo chmod -R 777 $vCTDir/CrossEng/coreutilsout/

# ===================== Build coreutils Final ==================

./ln_GNUcoreutils_Build_Final.sh $bbPCBits $bbPCOS $bbPCCPUOS $bbGDBbuildCPUOS $bbGDBhostCPUOS $bbGDBTargetCPUOS

# ================== Check and Strip GDB files ===========

if [ -f $vCTDir/CrossEng/coreutils_src/build/src/chcon ] ;
then
   
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/b2sum $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/base64 $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/base32 $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/basename $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/cat $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/chcon $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/chgrp $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/chmod $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/chown $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/cksum $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/comm $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/cp $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/csplit $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/cut $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/date $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/dd $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/dir $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/dircolors $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/dirname $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/du $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/echo $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/env $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/expand $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/expr $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/factor $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/false $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/fmt $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/fold $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/ginstall $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/groups $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/head $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/id $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/join $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/kill $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/link $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/ln $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/logname $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/ls $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/md5sum $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/mkdir $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/mkfifo $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/mknod $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/mktemp $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/mv $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/nl $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/nproc $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/nohup $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/numfmt $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/od $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/paste $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/pathchk $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/pr $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/printenv $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/printf $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/ptx $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/pwd $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/readlink $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/realpath $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/rm $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/rmdir $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/runcon $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/seq $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/sha1sum $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/sha224sum $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/sha256sum $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/sha384sum $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/sha512sum $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/shred $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/shuf $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/sleep $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/sort $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/split $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/stat $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/sum $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/sync $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/tac $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/tail $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/tee $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/test $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/touch $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/tr $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/true $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/truncate $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/tsort $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/tty $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/uname $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/unexpand $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/uniq $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/unlink $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/vdir $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/wc $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/whoami $vCTDir/CrossEng/coreutilsout/
   sudo cp -f $vCTDir/CrossEng/coreutils_src/build/src/yes $vCTDir/CrossEng/coreutilsout/


   echo "   "
   echo "-------------------------------------------------------"
   echo "   Strip GNU coreutils Executable file..."
   echo "-------------------------------------------------------"
   echo "   "   
   
   sudo chmod -R 777 $vCTDir/CrossEng/coreutilsout
   sudo strip $vCTDir/CrossEng/coreutilsout/* 
   
   echo "------------------------------------------------"
   echo "   "
   echo "[FINAL INFO]: GNU coreutils for Host=$bbMakhostCPUOS and Target=$bbMakTargetCPUOS Build OK...!!!" 
   echo "All GNU coreutils Executables are in /usr/local/codetyphon/CrossEng/coreutilsout/ Directory"
   echo "   "
else
   echo "------------------------------------------------"
   echo "   "
   echo "??????????????????????????????????????????????????????????????????????"
   echo "[ERROR]: Sorry, GNU coreutils for Host=$bbMakhostCPUOS and Target=$bbMakTargetCPUOS NOT Build..." 
   echo "??????????????????????????????????????????????????????????????????????"
fi
 
}

# =================== MAIN =============================
. /usr/local/codetyphon/ScriptsLin/ln_All_Functions.sh
getvalues

bbPCBits=$1
bbPCOS=$2
bbPCCPUOS=$3
bbMakbuildCPUOS=$4
bbMakhostCPUOS=$5
bbMakTargetCPUOS=$6

#----------------------------------------

echo "   "
echo "==============================================="
echo "        GNU coreutils Build Engine Settings"
echo "==============================================="
echo "   "
echo $bbBits
echo $bbOS
echo $bbPCCPUOS
echo $bbMakbuildCPUOS
echo $bbMakhostCPUOS
echo $bbMakTargetCPUOS
echo "   "

dothejob
