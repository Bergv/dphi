# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


dothejob() 
{

echo "----------------------------------------------"
echo " Please Wait... Removing DocFactory Directory" 
echo "----------------------------------------------"

#------------- Remove DocFactory Directory -------------

if [ -d $vCTDir/DocFactory ] ;
then 
  sudo rm -fr $vCTDir/DocFactory
  echo "[INFO]: DocFactory Directory removed from disk"
else
  echo "[INFO]: DocFactory Directory NOT EXIST, nothing to do ..."   
fi
}

# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi


