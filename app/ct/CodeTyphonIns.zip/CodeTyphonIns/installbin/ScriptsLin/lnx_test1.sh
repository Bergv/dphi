# ctusersctript:Test for CodeTyphon user Script
# =============================================================
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================
echo "========================== Linux Test File 1 ========================"
echo ".dfgdfgdfgdfg"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "Test1"
echo "========================== Linux Test File 1 ========================"
echo "Test1"
echo "Test11"
echo "Test111"
echo "---------------------------------------"
echo "[INFO] Test finish"
echo "   "

#echo "press any key"
#read var_read

./lnx_test2.sh
