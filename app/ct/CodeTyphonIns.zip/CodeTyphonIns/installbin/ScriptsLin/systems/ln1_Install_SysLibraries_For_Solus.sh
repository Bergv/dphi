# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#     This Script Install to Solus Linux 
#     base libraries to Build and Run CodeTyphon   
# =============================================================
# Update 20-10-2016 for Solus 1.2.1 
# Update 18-03-2019 for Solus 4.0 MATE
# Update 04-02-2021 for Solus 4.2 MATE
#========================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for"  
echo "              Solus Linux" 
echo "----------------------------------------------------"
echo "   "


echo "[INFO] Start OS Update..."
echo "   "
sudo eopkg upgrade -y

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

# ------------Install libraries Common
sudo eopkg install -y xterm 
sudo eopkg install -y zip 
sudo eopkg install -y unzip 
sudo eopkg install -y wget 

sudo eopkg install -y -c system.devel 
sudo eopkg install -y make 
sudo eopkg install -y gcc 
sudo eopkg install -y binutils 
sudo eopkg install -y gdb 
sudo eopkg install -y devscripts 

sudo eopkg install -y sdl1-devel
sudo eopkg install -y sdl2-devel
sudo eopkg install -y freeglut-devel
sudo eopkg install -y mesalib
sudo eopkg install -y libglu
sudo eopkg install -y libxxf86vm-devel 
sudo eopkg install -y libxtst-devel
sudo eopkg install -y libx11-devel 
sudo eopkg install -y libxft-devel
sudo eopkg install -y fontconfig-devel
  

# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
  
    sudo eopkg install -y libgtk-2-devel 
    sudo eopkg install -y gdk-pixbuf-devel 
    sudo eopkg install -y libcairo-devel

fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo eopkg install -y qt4-devel
  
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo eopkg install -y libgtk-3-devel    
 
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo eopkg install -y libgtk-4-devel    
 
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo eopkg install -y qt5-devel
    sudo eopkg install -y qt5-webkit-devel

fi

sudo ldconfig
#use  sudo ldconfig -v to see if lib are visible to the dynamic linker ld

echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation"  
echo "Finish !!!"

#sleep 5
