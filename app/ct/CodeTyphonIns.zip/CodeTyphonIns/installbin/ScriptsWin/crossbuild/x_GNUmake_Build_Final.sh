# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{
# ===================== Build GNU Make ==================

cd C:/codetyphon/CrossEng/make_src
build

if [ -d ../makeout/bin ] ;
then     
    echo "[INFO]: Remove OLD temporary BUILD directory..."
    rm -rf ../makeout/bin
    echo "  "
fi
mkdir ../makeout/bin
  

if [ -d GccRel ] ;
then     
    echo "[INFO]: Remove OLD temporary GccRel directory..."
    rm -rf GccRel
    echo "  "
fi
    
if [ -d build ] ;
then     
    echo "[INFO]: Remove OLD temporary BUILD directory..."
    rm -rf build
    echo "  "
else    
    echo " "
    echo "--- patch for Windows OS-----------"
    patch -p1 < make_undef_d_type.patch
    echo " "
fi

if [ $buPCBits = 32 ] ;
then 
  cmd " /c" "build_w32.bat" "gcc" "--x86" 
  mv GccRel/gnumake.exe ../makeout/bin/make.exe
else
  cmd " /c" "build_w32.bat" "gcc"
  mv GccRel/gnumake.exe ../makeout/bin/make.exe
fi 

}

# =================== MAIN =============================

buPCBits=$1
buPCOS=$2
buPCCPUOS=$3
buMakbuildCPUOS=$4
buMakhostCPUOS=$5
buMakTargetCPUOS=$6


echo "   "
echo "-----------------------------------------------"
echo "   GNU make Build Engine Final settings"
echo "-----------------------------------------------"
echo "   "
echo $buPCBits
echo $buPCOS
echo $buPCCPUOS
echo $buMakbuildCPUOS
echo $buMakhostCPUOS
echo $buMakTargetCPUOS
echo "   "

dothejob

