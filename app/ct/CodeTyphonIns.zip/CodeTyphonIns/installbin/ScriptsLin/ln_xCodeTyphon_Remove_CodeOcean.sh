# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


dothejob() 
{

echo "----------------------------------------------"
echo " Please Wait... Removing CodeOcean Directory" 
echo "----------------------------------------------"

#------------- Remove CodeOcean Directory -------------

if [ -d $vCTDir/CodeOcean ] ;
then 
  sudo rm -fr $vCTDir/CodeOcean
  echo "[INFO]: CodeOcean Directory removed from disk"
else
  echo "[INFO]: CodeOcean Directory NOT EXIST, nothing to do ..."   
fi
}

# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi


