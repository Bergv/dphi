# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#      This Script Install to Sabayon Linux (Gentoo based) 
#      base libraries to Build and Run CodeTyphon  
# =============================================================
# Update 23-12-2013 for Sabayon 14.01
# Update 06-04-2019 for Sabayon 19.03
#========================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for"  
echo "               Sabayon Linux" 
echo "----------------------------------------------------"
echo "   "


# ========= System Full Update Commands ===========

# equo update
# equo repo mirrorsort sabayon-weekly
# equo install entropy rigo equo  --relaxed
# equo conf update
# equo update
# equo upgrade --ask
# equo conf update
# equo deptest
# equo libtest

# ================================================
echo "[INFO] Start OS Update..."
echo "   "
sudo equo update
sudo equo upgrade
equo conf update

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "


sudo equo install xterm
sudo equo install zip
sudo equo install unzip
sudo equo install wget

sudo equo install make
sudo equo install gcc
sudo equo install gcc-c++
sudo equo install gdb
sudo equo install binutils 

sudo equo install libxtst-dev
sudo equo install libx11-dev 
sudo equo install libgpmg1-dev 
sudo equo install libsdl
sudo equo install libXxf86vm

sudo equo install ttf-fonts
sudo equo install liberation-fonts


# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    sudo equo install gtk+extra
    sudo equo install gtk2-engines-pixbuf 
    sudo equo install libgtk2.0-dev 
    sudo equo install libcairo

fi


# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo equo install libqt4-dev 
    sudo equo install qt4-qmake    
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo equo install gtk+-3.0   
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo equo install gtk+-4.0   
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo equo install libqt5-dev 
    sudo equo install qt5-qmake       
fi

echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation" 
echo "Finish !!!"

#sleep 5
