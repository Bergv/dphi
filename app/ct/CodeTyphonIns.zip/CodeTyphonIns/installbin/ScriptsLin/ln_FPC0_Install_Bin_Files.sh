# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

if [ ! -d $vFpcDir ] ;
then 
  sudo mkdir $vFpcDir
fi

if [ ! -d $vFpcBitsDir ] ;
then 
  sudo mkdir $vFpcBitsDir
fi

if [ ! -d $vFpcBinDir ] ;
then   
  sudo mkdir $vFpcBinDir
fi

if [ ! -d $vFpcExeDir ] ;
then   
  sudo mkdir $vFpcExeDir
fi

echo "   "
echo "------------------------------------------------"
echo "       Install FPC$vBits Binary Files"
echo "------------------------------------------------"
echo "   "
sudo $v7zipexe x $vCTDir/allzips/binfpc/$vCPUOS.7z -o$vFpcBinDir/ -y

sudo chmod -R 777 $vFpcBinDir
sudo chmod -R 777 $vFpcDir

sudo rm -f $vOSBinDir/$vFpcExeFile
sudo rm -f $vOSBinDir/fpc$vBits
sudo ln -s $vFpcExeDir/$vFpcExeFile $vOSBinDir/$vFpcExeFile
sudo ln -s $vFpcExeDir/$vFpcExeFile $vOSBinDir/fpc$vBits

if [ -f $vCTDir/allzips/bingdb/gdb-$vCPUOS.7z ] ;
then   
  echo "[INFO] Install custom GDB for $vCPUOS"
  
  sudo mkdir $vCTDir/binGDB
  sudo chmod -R 777 $vCTDir/binGDB
  
  sudo $v7zipexe x $vCTDir/allzips/bingdb/gdb-$vCPUOS.7z -o$vCTDir/binGDB/ -y 
  
  sudo chmod -R 777 $vCTDir/binGDB   
fi

if [ -f $vCTDir/allzips/binlldb/lldb-$vCPUOS.7z ] ;
then   
  echo "[INFO] Install custom LLDB for $vCPUOS"
  
  sudo mkdir $vCTDir/binLLDB
  sudo chmod -R 777 $vCTDir/binLLDB
  
  sudo $v7zipexe x $vCTDir/allzips/binlldb/lldb-$vCPUOS.7z -o$vCTDir/binLLDB/ -y 
  
  sudo chmod -R 777 $vCTDir/binLLDB  
fi



if [ $vHostOSRealName = Darwin ] ;
then

  if [ ! -f /usr/lib/crt1.o ] ;
  then 
  
# ---- MacOS 10.14 Staffs --------------- 
 
   if [ -f /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/lib/crt1.o ] ;
    then       
      echo "   [DONE] MacOS 10.14 make crt1.xx.xx.o symlink to $vFpcExeDir/crt1.xx.xx.o"
      sudo cp -f /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/lib/crt1.o $vFpcExeDir/crt1.o
      sudo cp -f /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/lib/crt1.10.5.o $vFpcExeDir/crt1.10.5.o
      sudo cp -f /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/lib/crt1.10.6.o $vFpcExeDir/crt1.10.6.o
      sudo chmod -R 777 $vFpcExeDir/crt1.o
      sudo chmod -R 777 $vFpcExeDir/crt1.10.5.o
      sudo chmod -R 777 $vFpcExeDir/crt1.10.6.o
      echo " "      
    fi
   
# ---- MacOS 10.15 Staffs --------------- 
   
   if [ -f /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/lib/crt1.o ] ;
    then       
      echo "   [DONE] MacOS 10.15 make crt1.xx.xx.o symlink to $vFpcExeDir/crt1.xx.xx.o"
      sudo cp -f /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/lib/crt1.o $vFpcExeDir/crt1.o
      sudo cp -f /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/lib/crt1.10.5.o $vFpcExeDir/crt1.10.5.o
      sudo cp -f /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/lib/crt1.10.6.o $vFpcExeDir/crt1.10.6.o
      sudo chmod -R 777 $vFpcExeDir/crt1.o
      sudo chmod -R 777 $vFpcExeDir/crt1.10.5.o
      sudo chmod -R 777 $vFpcExeDir/crt1.10.6.o
      echo " "      
    fi
    
  fi
fi

}

# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

cbInstallBits=$1

case $cbInstallBits in
  32)
     if [ $vUseMultiArch = 1 ] ;
      then 
        setdummy32
        dothejob 
      else 
        dothejob
      fi
    ;;
  64)
     dothejob
    ;; 
  *)
     dothejob

     if [ $vUseMultiArch = 1 ] ;
      then 
        setdummy32
        dothejob       
      fi
    ;;
  esac 

echo "    "


