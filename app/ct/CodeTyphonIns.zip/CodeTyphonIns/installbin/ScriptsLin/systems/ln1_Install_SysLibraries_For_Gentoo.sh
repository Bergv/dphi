# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#      This Script Install to Gentoo Linux 
#      base libraries to Build and Run CodeTyphon  
# =============================================================
# Update/Test 19-12-2014 for Calculate Linux 14.12
# Update/Test 01-07-2017 for Calculate Linux 17.6
# Update/Test 07-10-2018 for Calculate Linux 18
# Update/Test 21-06-2020 for Calculate Linux 20.6
#========================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for"  
echo "               Gentoo Linux" 
echo "----------------------------------------------------"
echo "   "

sudo emerge xterm
sudo emerge zip
sudo emerge unzip
sudo emerge wget

sudo emerge make
sudo emerge gcc
sudo emerge gcc-c++
sudo emerge gdb
sudo emerge binutils-devel 

sudo emerge libxtst-dev
sudo emerge libx11-dev 
sudo emerge libgpmg1-dev 
sudo emerge libsdl
sudo emerge libXxf86vm
sudo emerge mesa

sudo emerge ttf-fonts
sudo emerge liberation-fonts


# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    sudo emerge ibgtk2.0-dev 
    sudo emerge gtk2-engines-pixbuf 
    sudo emerge gtkglext 
    sudo emerge libcairo
fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo emerge libqt4-dev 
    sudo emerge qt4-qmake    
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo emerge gtk+-3.0   
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo emerge gtk+-4.0   
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo emerge libqt5-dev 
    sudo emerge qt5-qmake   
fi

echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation" 
echo "Finish !!!"

#sleep 5
