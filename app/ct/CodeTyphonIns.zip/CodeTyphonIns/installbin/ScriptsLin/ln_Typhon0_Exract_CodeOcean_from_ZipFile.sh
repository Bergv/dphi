# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

#========================MAIN===========================
. $PWD/ln_All_Functions.sh
getvalues


echo "   "
echo "---------------------------------------------------------"
echo "        Extract CodeOcean Samples From Zip File"   
echo "---------------------------------------------------------"

if [ -f ../allzips/src/CodeOcean.7z.001 ] ;
then  

  if [ ! -d $vCTDir/CodeOcean/ ] ;
  then  
    sudo mkdir $vCTDir/CodeOcean/  
  fi

sudo $v7zipexe x ../allzips/src/CodeOcean.7z.001 -o../ -y

sudo chmod -R 777 $vCTDir/CodeOcean/

echo "---------------------------------------"
echo "[INFO]: Extract CodeOcean Samples finish"

else

echo "---------------------------------------"
echo "[ERROR]: CodeOcean Samples Zip File NOT EXIST ???"

fi

echo "   "
