# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

echo "=============================================================="
echo "                 Remove and Build ALL " 
echo "=============================================================="

./ln_xCodeTyphon_Remove_FPC.sh

./ln_FPC32_Build.sh
./ln_FPC64_Build.sh


