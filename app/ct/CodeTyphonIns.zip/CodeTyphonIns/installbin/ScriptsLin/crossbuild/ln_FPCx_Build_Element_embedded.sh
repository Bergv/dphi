# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

dothejob() 
{

echo "   "
echo "================================================="
echo "  CUSTOM Cross Element Build" 
echo "================================================="
echo "   "

cd $vFpcSrcDir

# ------------------- Make SysLinks  --------------------------------

if [ -f $vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/fpcmake ] ;
then
  sudo ln -f -s $vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/fpcmake ${cbSysLinkDir}/fpcmake
fi

if [ -f $vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/${cbTARGETCPUOS}-as ] ;
then
  sudo ln -f -s $vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/${cbTARGETCPUOS}-as ${cbSysLinkDir}/${cbTARGETCPUOS}-as
fi

# -------------------------------------------------------------------

# -------------------------------------------------------------------
# sleep 120
# -------------------------------------------------------------------
echo "   "
echo "------------------------------------------------"
echo "       Stage 1: Build Cross Compiler Executable" 
echo "------------------------------------------------"

if [ $vOSName = solaris ] ;
then   
  sudo $vMake compiler_cycle CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbTARGETCPUOS}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCStartEXE OPT="-Xn" 
elif [ $vOSName = darwin ] ;
then
  sudo $vMake compiler_cycle CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbTARGETCPUOS}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCStartEXE OPT="-XR/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk"
else  
  sudo $vMake compiler_cycle CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbTARGETCPUOS}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCStartEXE
fi

if [ ! -f $vFpcSrcDir/compiler/$cbFPCCrossEXE ] ;
then  
  echo "???????????????????????????????????????????????????????????"
  echo " [ERROR]:Cross compiler $cbFPCCrossEXE  NOT Builded"
  echo "         sorry, Cross Build procedure STOP" 
  echo "??????????????????????????????????????????????????????????"
  docleanall
  exit
else
 sudo cp -f $vFpcSrcDir/compiler/$cbFPCCrossEXE $vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/
 sudo chmod -R 777 $vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS
 echo "   "
 echo "[INFO]: !!! Cross compiler Executable $cbFPCCrossEXE, Build OK. !!!"
 echo "   "
fi

# -------------------------------------------------------------------
# sleep 120
# -------------------------------------------------------------------
echo "   "
echo "------------------------------------------------"
echo "       Stage 2: Build All Units and Packages" 
echo "------------------------------------------------"

if [ $vOSName = darwin ] ;
then
  sudo $vMake rtl CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbTARGETCPUOS}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCCrossEXE OPT="-XR/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk"
else
  sudo $vMake rtl CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbTARGETCPUOS}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCCrossEXE
fi

# -------------------------------------------------------------------
# sleep 120
# -------------------------------------------------------------------
echo "   "
echo "------------------------------------------------"
echo "       Stage 3: Install All Units and Packages" 
echo "------------------------------------------------"

sudo $vMake rtl_install CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbTARGETCPUOS}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCCrossEXE PREFIX=/usr/local/codetyphon/fpc/newfpc

# ------------------- REMOVE SysLinks  ----------------------------------

if [ -f ${cbSysLinkDir}/fpcmake ] ;
then
  sudo rm -f ${cbSysLinkDir}/fpcmake
fi

if [ -f ${cbSysLinkDir}/${cbTARGETCPUOS}-as ] ;
then
  sudo rm -f ${cbSysLinkDir}/${cbTARGETCPUOS}-as
fi
  
}

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

# =================== MAIN =============================
. /usr/local/codetyphon/ScriptsLin/ln_All_Functions.sh
getvalues

cbFPCType=$1
cbFPCCPUOS=$2
cbFPCStartEXE=$3
cbTARGETCPU=$4
cbTARGETOS=$5
cbFPCCrossEXE=$6
cbParam=$7

cbTARGETCPUOS=${cbTARGETCPU}-${cbTARGETOS}

if [ $cbParam = xxxx ] ;
then
  cbbincross=${cbFPCType}-${cbTARGETCPUOS}
else
  cbbincross=${cbFPCType}-${cbTARGETCPUOS}--${cbParam}
fi

#-------- Find Bits ----------------------------------
case $cbFPCType in
 *32*)
    cbBits=32
    ;;
 *)
    cbBits=64
    ;;
esac

#-------- Setup SysLinkdir ----------------------------

if [ $vOSName = darwin ] ;
then
   cbSysLinkDir=/usr/local/bin
else
   cbSysLinkDir=/usr/bin
fi

#------------------------------------------------------

dothejob

