# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{
echo " "
echo "----------------------------------------------------------"
echo "         Clean FreePascal Source Directory "
echo "----------------------------------------------------------"
   
if [ ! -d $vFpcSrcDir ] ;
then  
 echo "[ERROR]: FreePascal Directory NOT EXIST !!!"
 exit
fi  

cd $vFpcSrcDir 

if [ -f $vFpcExeDir/$vFpcExeFile ] ;
then 
  sudo $vMake clean PP=$vFpcExeDir/$vFpcExeFile
fi  

sudo find $PWD -type f -iname "fpcmade.*" -exec rm -f {} \;
sudo find $PWD -type f -iname "Package.fpc" -exec rm -f {} \;
sudo find $PWD -type f -iname "*.ppu" -exec rm -f {} \;

sudo find $PWD/compiler -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/packages -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/rtl -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/installer -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/utils -type f -iname "*.o" -exec rm -f {} \;

sudo rm -f $vFpcSrcDir/packages/xforms/fd2pascal

sudo find $PWD/packages -type d -iname "units" -exec rm -rf {} \;

cd $vCTDir/ScriptsLin/
}

# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

dothejob

echo " "

