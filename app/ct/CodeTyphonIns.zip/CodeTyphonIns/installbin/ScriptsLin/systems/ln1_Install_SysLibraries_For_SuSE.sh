# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#      This Script Install to SeSE Linux 
#      base libraries to Build and Run CodeTyphon  
# =============================================================
# Update 23-05-2014 for OpenSUSE 13.2 beta  (MultiArch for GTK2 and QT4)
# Update 06-11-2015 for OpenSUSE Leap 42.1  (MultiArch for GTK2 and QT4)
# Update 30-01-2018 for OpenSUSE-Tumbleweed (MultiArch for GTK2 and QT5)
# Update 26-05-2018 for OpenSUSE Leap 15
# Update 23-05-2019 for OpenSUSE Leap 15.1  (MultiArch, MultiPlatform)
# Update 05-06-2019 for OpenSUSE Tumbleweed (MultiArch, MultiPlatform) 
# Update 03-07-2020 for OpenSUSE Leap 15.2  (MultiArch, MultiPlatform for GTK2 and QT5)
# Update 01-08-2020 for GeckoLinux 999.200729 (MultiArch, MultiPlatform) 
# Update 03-06-2021 for OpenSUSE Leap 15.3  (MultiArch, MultiPlatform for GTK2 and QT5)
#========================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for"  
echo "               SuSE Linux" 
echo "----------------------------------------------------"
echo "   "

echo "[INFO] Start OS Update..."
echo "   "
sudo zypper --non-interactive update 

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

sudo zypper --non-interactive install -y xterm
sudo zypper --non-interactive install -y zip
sudo zypper --non-interactive install -y unzip
sudo zypper --non-interactive install -y wget

sudo zypper --non-interactive install -y cmake 
sudo zypper --non-interactive install -y make 
sudo zypper --non-interactive install -y gcc 
sudo zypper --non-interactive install -y gcc-c++ 
sudo zypper --non-interactive install -y gdb 
sudo zypper --non-interactive install -y kernel-default-devel 
sudo zypper --non-interactive install -y binutils 
sudo zypper --non-interactive install -y binutils-devel 
sudo zypper --non-interactive install -y libXtst-devel
sudo zypper --non-interactive install -y glu-devel
sudo zypper --non-interactive install -y libgthread-2_0-0
sudo zypper --non-interactive install -y freetype2-devel 

sudo zypper --non-interactive install -y boost-devel 
sudo zypper --non-interactive install -y flex 
sudo zypper --non-interactive install -y bison 
sudo zypper --non-interactive install -y libxml2-devel
sudo zypper --non-interactive install -y libicu-devel 
sudo zypper --non-interactive install -y libopenssl1_0_0 
sudo zypper --non-interactive install -y libopenssl-devel 
sudo zypper --non-interactive install -y libcap1
sudo zypper --non-interactive install -y libcap2 
sudo zypper --non-interactive install -y gd 
sudo zypper --non-interactive install -y zlib-devel
sudo zypper --non-interactive install -y libpcrecpp0  
sudo zypper --non-interactive install -y libpcreposix0
sudo zypper --non-interactive install -y libexpat1  
sudo zypper --non-interactive install -y libexpat-devel  
sudo zypper --non-interactive install -y libbz2-1  
sudo zypper --non-interactive install -y libbz2-devel  
sudo zypper --non-interactive install -y libreadline6  
sudo zypper --non-interactive install -y readline-devel
sudo zypper --non-interactive install -y libXxf86vm1


if [ $ciUseMultiArch = 1 ] ; 
then

sudo zypper --non-interactive install -y gcc-32bit  
sudo zypper --non-interactive install -y gcc-c++-32bit  
sudo zypper --non-interactive install -y libXtst-devel-32bit 
sudo zypper --non-interactive install -y glu-devel-32bit
sudo zypper --non-interactive install -y libgthread-2_0-0-32bit
sudo zypper --non-interactive install -y freetype2-devel-32bit 

sudo zypper --non-interactive install -y boost-devel-32bit 
sudo zypper --non-interactive install -y flex-32bit 
sudo zypper --non-interactive install -y bison-32bit 
sudo zypper --non-interactive install -y libxml2-devel-32bit
sudo zypper --non-interactive install -y libicu-devel-32bit 
sudo zypper --non-interactive install -y libopenssl1_0_0-32bit 
sudo zypper --non-interactive install -y libopenssl-devel-32bit 
sudo zypper --non-interactive install -y libcap1-32bit
sudo zypper --non-interactive install -y libcap2-32bit 
sudo zypper --non-interactive install -y zlib-devel-32bit
sudo zypper --non-interactive install -y libpcrecpp0-32bit  
sudo zypper --non-interactive install -y libpcreposix0-32bit
sudo zypper --non-interactive install -y libexpat1-32bit  
sudo zypper --non-interactive install -y libexpat-devel-32bit  
sudo zypper --non-interactive install -y libbz2-1-32bit  
sudo zypper --non-interactive install -y libbz2-devel-32bit  
sudo zypper --non-interactive install -y libreadline6-32bit  
sudo zypper --non-interactive install -y readline-devel-32bit
sudo zypper --non-interactive install -y libXxf86vm1-32bit

fi

# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    sudo zypper --non-interactive install -y gtk2-devel 
    sudo zypper --non-interactive install -y gdk-pixbuf-devel 
    sudo zypper --non-interactive install -y cairo-devel 
    sudo zypper --non-interactive install -y pango-devel 

    if [ $ciUseMultiArch = 1 ] ; 
    then
     sudo zypper --non-interactive install -y gtk2-devel-32bit  
     sudo zypper --non-interactive install -y gdk-pixbuf-devel-32bit 
     sudo zypper --non-interactive install -y cairo-devel-32bit  
     sudo zypper --non-interactive install -y pango-devel-32bit 
    fi 
fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "

    sudo zypper --non-interactive install -y libqt4
    sudo zypper --non-interactive install -y libqt4-devel
    sudo zypper --non-interactive install -y libQtWebKit4

    if [ $ciUseMultiArch = 1 ] ; 
    then 
     sudo zypper --non-interactive install -y libqt4-32bit
     sudo zypper --non-interactive install -y libQtWebKit4-32bit
    fi 
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "

    sudo zypper --non-interactive install -y libgtk-3-0 

    if [ $ciUseMultiArch = 1 ] ; 
    then 
     sudo zypper --non-interactive install -y libgtk-3-0-32bit
    fi       
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "

    sudo zypper --non-interactive install -y libgtk-4-0 

    if [ $ciUseMultiArch = 1 ] ; 
    then 
     sudo zypper --non-interactive install -y libgtk-4-0-32bit
    fi       
fi


# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo zypper --non-interactive install -y libQt5Core5
    sudo zypper --non-interactive install -y libQt5X11Extras5
    sudo zypper --non-interactive install -y libQt5PrintSupport5
    sudo zypper --non-interactive install -y libQt5Widgets5
    sudo zypper --non-interactive install -y libQt5WebKit5

    if [ $ciUseMultiArch = 1 ] ; 
    then 
     sudo zypper --non-interactive install -y libQt5Core5-32bit
     sudo zypper --non-interactive install -y libQt5X11Extras5-32bit
     sudo zypper --non-interactive install -y libQt5PrintSupport5-32bit
     sudo zypper --non-interactive install -y libQt5Widgets5-32bit
     sudo zypper --non-interactive install -y libQt5WebKit5-32bit
    fi     
fi


echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation" 
echo "Finish !!!"

#sleep 5
