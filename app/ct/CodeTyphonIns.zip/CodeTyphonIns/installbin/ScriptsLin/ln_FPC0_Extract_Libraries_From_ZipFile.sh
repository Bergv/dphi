# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

echo "   "
echo "---------------------------------------------------------"
echo "     Extract Libraries..."   
echo "---------------------------------------------------------"

if [ -f ../allzips/libraries/android-2.3-api9-arm.7z ] ;
then    
   sudo $v7zipexe x ../allzips/libraries/android-2.2-api8-arm.7z -o$vCTDir/binLibraries -y
   sudo $v7zipexe x ../allzips/libraries/android-2.3-api9-arm.7z -o$vCTDir/binLibraries -y
   sudo $v7zipexe x ../allzips/libraries/android-4.0-api14-arm.7z -o$vCTDir/binLibraries -y
   
   sudo chmod -R 777 $vCTDir/binLibraries/   
else
   echo "[ERROR]: android-2.3-api9-arm Libraries Zip File NOT EXIST ????????"
fi

}

# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi


