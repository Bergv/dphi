# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#     This Script Install to MacOS X
#     base libraries to Build and Run CodeTyphon
# =============================================================
# Update 16-11-2014 for MacOS 10.9.5
# Update 11-08-2017 for MacOS 10.12.5
# Update 14-08-2017 for MacOS 10.12.6
# Update 26-10-2017 for MacOS 10.13.0 (High Sierra)
# Update 06-10-2018 for MacOS 10.14.0 (Mojave) (MultiPatform)
# Update 13-10-2019 for MacOS 10.15.0 (Catalina)
# Update 13-04-2020 for MacOS 10.15.4 (Catalina)
#========================================================

ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for"
echo "                 MacOS X"
echo "----------------------------------------------------"
echo "   "

#======= MacPorts =======================================

if [ -f /opt/local/bin/port ] ;
then
echo "[INFO] MacPorts Exists"
else
echo "[ERROR] MacPorts NOT Exists ????"
echo "        Please Install MacPorts first."
echo "        from  https://www.macports.org"
echo "   "
echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation"
echo "Aborted."
exit
fi

#==========================================================

echo "[INFO] Start OS Update..."
echo "   "

# sudo softwareupdate -iva

echo "   "
echo "[INFO] Start MacPorts Update..."
echo "   "

sudo /opt/local/bin/port version
sudo /opt/local/bin/port -d selfupdate
sudo /opt/local/bin/port upgrade outdated

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

sudo /opt/local/bin/port -N install xorg-server
sudo /opt/local/bin/port -N install xorg-apps
sudo /opt/local/bin/port -N install xterm
sudo /opt/local/bin/port -N install gmake
sudo /opt/local/bin/port -N install p7zip
sudo /opt/local/bin/port -N install wget
sudo /opt/local/bin/port -N install upx
sudo /opt/local/bin/port -N install gdb


# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    sudo /opt/local/bin/port -N install gtk2
fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "

    sudo /opt/local/bin/port -N install qt4-mac
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo /opt/local/bin/port -N install gtk3
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo /opt/local/bin/port -N install gtk4
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    
    sudo /opt/local/bin/port -N install qt5
fi

echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation"
echo "Finish !!!"

#sleep 5
