# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob()
{
# ===================== Build GNU Make ==================

cd /usr/local/codetyphon/CrossEng/make_src
           

if [ -d build ] ;
then     
    echo "[INFO]: Remove OLD temporary BUILD directory..."
    sudo rm -rf build
    echo "  "
fi

mkdir build
sudo chmod -R 777 build/
cd build

echo " "
echo "-------- configure -----------"
 
../configure --build=$buMakbuildCPUOS --host=$buMakhostCPUOS --target=$buMakTargetCPUOS --prefix=/usr/local/codetyphon/CrossEng/makeout 

echo " "
echo "-------- make ----------------"
make -j4

echo " "
echo "-------- make install --------"
make -j4 install

}

# =================== MAIN =============================

buPCBits=$1
buPCOS=$2
buPCCPUOS=$3
buMakbuildCPUOS=$4
buMakhostCPUOS=$5
buMakTargetCPUOS=$6


echo "   "
echo "-----------------------------------------------"
echo "   GNU make Build Engine Final settings"
echo "-----------------------------------------------"
echo "   "
echo $buPCBits
echo $buPCOS
echo $buPCCPUOS
echo $buMakbuildCPUOS
echo $buMakhostCPUOS
echo $buMakTargetCPUOS
echo "   "

dothejob

