# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob()
{

echo "   "
echo "=============================================================="
echo " Build FPC64 Bootstrap Compiler from FPC32 for $vHostOSRealName"
echo "=============================================================="
echo "   "

if [ ! -f $vFpcSrcDir/Makefile.fpc ] ;
then    
    echo "[INFO]: FPC$vBits Source files not exists, extracting..."
    ./ln_FPC0_Extract_Source_From_ZipFile.sh
fi

if [ ! -f $vFpcExeDir/$vFpcExeFile ] ;
then      
    echo "[INFO]: FPC$vBits Binary files not exists, extracting..."
    ./ln_FPC0_Install_Bin_Files.sh 32
fi

echo "------------------------------------------------"
echo "        Clean FreePascal $vBits" 
echo "------------------------------------------------"

./ln_FPC0_Clean_SourceDir.sh


cd $vCTDir/fpcsrc

echo "------------------------------------------------"
echo "   Build FPC64 Bootstrap Compiler" 
echo "------------------------------------------------"

case $vOSName in
solaris)
   sudo $vMake compiler_cycle CPU_TARGET=x86_64 OPT="-Xn" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
linux)  
   sudo $vMake compiler_cycle CPU_TARGET=x86_64 PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove    
 ;;
freebsd)
   sudo $vMake compiler_cycle CPU_TARGET=x86_64 OPT="-Fl/usr/local/lib" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
openbsd)
   sudo $vMake compiler_cycle CPU_TARGET=x86_64 OPT="-Fl/usr/local/lib" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
netbsd)
   sudo $vMake compiler_cycle CPU_TARGET=x86_64 OPT="-Fl/usr/local/lib" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
dragonfly)
   sudo $vMake compiler_cycle CPU_TARGET=x86_64 OPT="-Fl/usr/local/lib" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
darwin)  
   sudo $vMake compiler_cycle CPU_TARGET=x86_64 PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove    
 ;;
*)
   sudo $vMake compiler_cycle CPU_TARGET=x86_64 PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove 
 ;;
esac

# =======================================================
if [ ! -f $vCTDir/fpcsrc/compiler/ppcx64 ] ;
then
  echo "   "
  echo "??????????????????????????????????????????????????????"
  echo "[ERROR]: FPC64 Bootstrap Compiler NOT Build from FPC32"
  echo "??????????????????????????????????????????????????????"
  exit
fi

echo "   "
echo "[INFO]:copy ppcx64 to FPC64 Bin Directory"
echo "   "


sudo chmod -R 777 $vFpcDir/
sudo cp -f $vCTDir/fpcsrc/compiler/ppcx64 $vCTDir/fpc/fpc64/bin/x86_64-$vOSName/
sudo chmod -R 777 /usr/local/codetyphon/fpc/fpc64/bin/x86_64-$vOSName/


cd $vCTDir/ScriptsLin
./ln_FPC0_Clean_SourceDir.sh


echo "   "
echo "[FINAL INFO]:FPC64 Bootstrap Compiler Build OK. It's in FPC64 Bin Dir !!!!"
echo "   "

exit
}

# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

if [ $vUseMultiArch = 1 ] ;
then 
 setdummy32
 dothejob 
fi  
