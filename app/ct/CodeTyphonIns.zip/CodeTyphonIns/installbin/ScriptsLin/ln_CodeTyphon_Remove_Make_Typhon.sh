# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

echo "=============================================================="
echo "                 Remove and Build Typhon " 
echo "=============================================================="

./ln_xCodeTyphon_Remove_Typhon.sh

./ln_Typhon32_Build.sh
./ln_Typhon64_Build.sh
 
