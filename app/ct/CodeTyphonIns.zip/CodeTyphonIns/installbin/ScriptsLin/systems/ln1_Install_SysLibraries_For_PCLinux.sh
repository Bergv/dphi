# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#      This Script Install to PCLinuxOS Linux 
#      base libraries to Build and Run CodeTyphon   
# =============================================================
# Update 17-10-2017 for PCLinuxOS 2017-07
# Update 18-09-2019 for PCLinuxOS 2019-09
#========================================================

ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for"  
echo "            PCLinuxOS Linux" 
echo "----------------------------------------------------"
echo "   "

echo "[INFO] Start OS Update..."
echo "   "
sudo apt-get update -y 

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

sudo apt-get install -y xterm 
sudo apt-get install -y zip 
sudo apt-get install -y unzip
sudo apt-get install -y wget

sudo apt-get install -y make 
sudo apt-get install -y gcc
sudo apt-get install -y gcc-c++
sudo apt-get install -y gdb 
sudo apt-get install -y binutils

sudo apt-get install -y glibc
sudo apt-get install -y glibc-devel

sudo apt-get install -y libx11
sudo apt-get install -y libx11-devel

sudo apt-get install -y glib
sudo apt-get install -y glib-devel

sudo apt-get install -y mesa

sudo apt-get install -y libxtst
sudo apt-get install -y libxtst-devel



# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "  

    sudo apt-get install -y gtk2
    sudo apt-get install -y gtk2-devel
    sudo apt-get install -y gtk+
    sudo apt-get install -y gtk+-devel
    sudo apt-get install -y cairo
    sudo apt-get install -y cairo-devel 

    sudo apt-get install -y cairo-gobject
    sudo apt-get install -y cairo-gobject-devel 

    sudo apt-get install -y pango
    sudo apt-get install -y pango-devel
 
fi


# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo apt-get install -y libqt4-dev
    sudo apt-get install -y libqtwebkit-dev
    sudo apt-get install -y qt4-qmake    
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo apt-get install -y gtk+-3.0   
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo apt-get install -y gtk+-4.0   
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo apt-get install -y qt5-qmake   
    sudo apt-get install -y qtbase5-dev 
    sudo apt-get install -y qtbase5-dev-tools 
    sudo apt-get install -y qtdeclarative5-dev 
    sudo apt-get install -y libqt5x11extras5-dev     
fi

echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation"  
echo "Finish !!!"

#sleep 5
