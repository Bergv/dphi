# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


# ======================= Findqmake5 =========================
findqmake5()
{

# Debian 8.6 has /usr/lib/x86_64-linux-gnu/qt4/bin/qmake
# Debian 8.6 has /usr/lib/x86_64-linux-gnu/qt5/bin/qmake

# Fedora 25  has /usr/lib/qt4/bin/qmake
# Fedora 25  has /usr/lib/qt5/bin/qmake
# Fedora 25  has /usr/lib64/qt4/bin/qmake
# Fedora 25  has /usr/lib64/qt5/bin/qmake

vQMake=qmake
BLQMake=error

case $vHostOSRealName in
  Linux)    
  
# ---- these settings are for Ubuntu Linux -------  
      if [ $vBits = 32 ] ;
       then
        vQMake=/usr/lib/i386-linux-gnu/qt5/bin/qmake
       else
        vQMake=/usr/lib/x86_64-linux-gnu/qt5/bin/qmake
       fi
#-------------------------------------------------       
   ;;
  FreeBSD)    
      vQMake=/usr/local/lib/qt5/bin/qmake     
   ;;
  OpenBSD) 
      vQMake=/usr/local/lib/qt5/bin/qmake        
   ;;
  NetBSD) 
      vQMake=/usr/pkg/qt5/bin/qmake 
   ;;
  DragonFly) 
      vQMake=/usr/local/lib/qt5/bin/qmake 
   ;;
  SunOS)
      vQMake=qmake   
   ;;
  Darwin)   
       vQMake=/opt/local/libexec/qt5/bin/qmake 
   ;;
esac


if [ -f $vQMake ] ;
then
  BLQMake=$vQMake
fi

if [ $BLQMake = error ] ;
then

echo "   "
echo "[ERROR]: $BLQMake qmake Executable NOT Found, QT5 Library Build Aborted."
echo "         Please sent this error to PilotLogic for fix"
echo "   "
exit

else

echo "   "
echo "-----------------------------------------------------------"
echo "[INFO]:USE qmake file from $BLQMake."
$BLQMake -v
echo "-----------------------------------------------------------"
echo "   "

fi
}

# ======================= Unzip ===============================
unzipqt5pas()
{

#------------- Remove OLD qt5pas Directory -------------

if [ -d $vCTDir/qt5pas ] ;
then
sudo rm -fr $vCTDir/qt5pas
echo "[INFO]: OLD qt5pas Directory Removed."
fi


echo "   "
echo "---------------------------------------------------------"
echo "      Unzip qt5pas sources"
echo "---------------------------------------------------------"
echo "   "

sudo mkdir $vCTDir/qt5pas/

sudo $v7zipexe x ../allzips/src/qt5pas.7z -o$vCTDir/ -y

sudo chmod -R 777 $vCTDir/qt5pas/

}


# ======================= Build For Unix ===============================
buildqt5pas_unix()
{

cd $vCTDir/qt5pas/${vCPUOS}

#---- Remove OLD Libraries and Links from Folder -------

if [ -f $vCTDir/qt5pas/${vCPUOS}/libQt5Pas.so ] ;
then
sudo rm -f $vCTDir/qt5pas/${vCPUOS}/libQt5Pas.so
fi

if [ -f $vCTDir/qt5pas/${vCPUOS}/libQt5Pas.so.1 ] ;
then
sudo rm -f $vCTDir/qt5pas/${vCPUOS}/libQt5Pas.so.1
fi

if [ -f $vCTDir/qt5pas/${vCPUOS}/libQt5Pas.so.1.2 ] ;
then
sudo rm -f $vCTDir/qt5pas/${vCPUOS}/libQt5Pas.so.1.2
fi

if [ -f $vCTDir/qt5pas/${vCPUOS}/libQt5Pas.so.1.2.12 ] ;
then
sudo rm -f $vCTDir/qt5pas/${vCPUOS}/libQt5Pas.so.1.2.12
fi

echo "   "
echo "------------- Qt Info --------------------------"
echo "   "

$BLQMake -query

echo "   "
echo "-------------- Build and Install qt5pas ------------------------------"
echo "   "

$BLQMake

sudo $vMake install

echo "   "

if [ -f $vCTDir/qt5pas/${vCPUOS}/libQt5Pas.so.1.2.12 ] ;
then
echo "---------------------------------------"
echo "[INFO]: qt5pas Libraries finish Build OK for $vCPUOS"
echo "   "
else
echo "---------------------------------------"
echo "[ERROR]: qt5pas Libraries Don't Build...???"
echo "   "
fi

}


# ======================= Build For MacOS ===========================
buildqt5pas_macos()
{

cd $vCTDir/qt5pas/${vCPUOS}

#---- Remove OLD Libraries and Links from Folder -------

if [ -d /usr/${vOSLibSub}/Qt5Pas.framework ] ;
then
sudo rm -fr $vCTDir/qt5pas/${vCPUOS}/Qt5Pas.framework
fi

echo "   "
echo "------------- Qt Info --------------------------"
echo "   "

$BLQMake -query

echo "   "
echo "-------------- Build and Install QT5pas ------------------------------"
echo "   "

$BLQMake

sudo $vMake install

echo "   "

sudo cp -fr /opt/local/libexec/qt5-mac/lib/Qt5Pas.framework $vCTDir/qt5pas/${vCPUOS}
sudo chmod -R 777 $vCTDir/qt5pas/

echo "   "

if [ -d $vCTDir/qt5pas/${vCPUOS}/Qt5Pas.framework ] ;
then

sudo rm -fr /opt/local/libexec/qt5-mac/lib/Qt5Pas.framework

echo "---------------------------------------"
echo "[INFO]: Qt5Pas.framework Library finish Build OK for $vCPUOS"
echo "   "
else
echo "---------------------------------------"
echo "[ERROR]: Qt5Pas.framework Library Don't Build...???"
echo "   "
fi

}

# ======================= dothejob ===============================
dothejob()
{

echo "  "
echo "---------------------------------------------------------"
echo " Try to Build qt5pas Libraries for ${vCPUOS} from Sources"
echo "---------------------------------------------------------"

findqmake5

if [ ! -f $vCTDir/allzips/src/qt5pas.7z ] ;
then
echo "   "
echo "[ERROR] qt5pas.7z file NOT Exists...Build qt5pas STOPPED"
echo "   "
exit
fi

if [ -f $BLQMake ] ;
then
echo "   "
echo "[INFO] $BLQMake for QT5 Exists"
echo "   "
else
echo "   "
echo "[ERROR]: $BLQMake for QT5 NOT Exists......Build QT5Pas STOPPED"
echo "          Install or find or link qmake for QT5 and Retry"
echo "   "
exit
fi

if [ $vOSName = darwin ] ;
then

if [ $vBits = 64 ] ;
then
unzipqt5pas
buildqt5pas_macos
fi

else
unzipqt5pas
buildqt5pas_unix
fi

cd $vCTDir/ScriptsLin

}

#========================MAIN===========================
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then
setdummy32
dothejob
fi

cd $vCTDir/ScriptsLin

./ln_Typhon1_QT5pas_Make_Links.sh


