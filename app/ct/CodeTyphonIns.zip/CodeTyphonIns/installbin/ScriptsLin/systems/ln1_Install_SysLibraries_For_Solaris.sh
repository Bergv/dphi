# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#      This Script Install to Solaris OS
#      base libraries to Build and Run CodeTyphon
# =============================================================
# Update 08-12-2013 for Solaris 11.1 
# Update 17-08-2014 for Solaris 11.2
# Update 01-11-2015 for Solaris 11.3
# Update 29-10-2018 for Solaris 11.4
#========================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

donewversion()
{
echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for" 
echo "                Solaris 11.x" 
echo "----------------------------------------------------"
echo "   "

echo "[INFO] Start OS Update..."
echo "   "
sudo pkg update

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

sudo pkg install xterm 
sudo pkg install zip
sudo pkg install unzip
sudo pkg install wget

# install GCC >= 4.8 by default
sudo pkg install gcc

sudo pkg install gdb
sudo pkg install gnu-binutils 
sudo pkg install developer-gnu 
sudo pkg install libxtst

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo pkg install gtk+-3.0   
fi
}

doversion10()
{
echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for" 
echo "                Solaris" 
echo "----------------------------------------------------"
echo "   "

echo "[INFO] Start OS Update..."
echo "   "
sudo pkg update

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "

sudo pkg install xterm 
sudo pkg install zip
sudo pkg install unzip
sudo pkg install wget

sudo pkg install gcc-3 
sudo pkg install gcc-3-runtime

sudo pkg install gcc-45 
sudo pkg install gcc-45-runtime 

sudo pkg install gdb
sudo pkg install gnu-binutils 
sudo pkg install developer-gnu 
sudo pkg install libxtst


# Install libraries for QT4
if [ "$ciplatiform" = 1 ] ; 
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "
    sudo pkg install qt4
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] ; 
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo pkg install gtk+-3.0   
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] ; 
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo pkg install gtk+-4.0   
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] ; 
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo pkg install qt5    
fi


}

# =============================================
# =============================================
# =============================================

case $(uname -v) in 
 *8.*)
    doversion10
    ;; 
 *9.*)
    doversion10
    ;; 
 *10.*)
    doversion10
    ;; 
 *)
    donewversion
    ;;
    
esac

echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation"  
echo "Finish !!!"

#sleep 5
