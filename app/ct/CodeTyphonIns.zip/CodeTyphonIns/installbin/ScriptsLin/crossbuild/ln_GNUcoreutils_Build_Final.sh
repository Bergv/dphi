ansi# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob()
{
# ===================== Build GNU coreutils ==================

cd /usr/local/codetyphon/CrossEng/coreutils_src
    

if [ -d build ] ;
then     
    echo "[INFO]: Remove OLD temporary BUILD directory..."
    sudo rm -rf build
    echo "  " 
fi

mkdir build
sudo chmod -R 777 build/
cd build

echo " "
echo "-------- configure -----------"
 
../configure --build=$buMakbuildCPUOS --host=$buMakhostCPUOS --target=$buMakTargetCPUOS --prefix=/usr/local/codetyphon/CrossEng/coreutilsout

echo " "
echo "-------- make ----------------"
make -j4 -k "CFLAGS=-O3" "LDFLAGS=-s" || true

# echo " "
# echo "-------- make install --------"
# make install

}

# =================== MAIN =============================

buPCBits=$1
buPCOS=$2
buPCCPUOS=$3
buMakbuildCPUOS=$4
buMakhostCPUOS=$5
buMakTargetCPUOS=$6


echo "   "
echo "-----------------------------------------------"
echo "   GNU coreutils Build Engine Final settings"
echo "-----------------------------------------------"
echo "   "
echo $buPCBits
echo $buPCOS
echo $buPCCPUOS
echo $buMakbuildCPUOS
echo $buMakhostCPUOS
echo $buMakTargetCPUOS
echo "   "

dothejob

