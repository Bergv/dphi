# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#      This Script Install to Chakra Linux 
#      base libraries to Build and Run CodeTyphon  
# =============================================================


ciplatiform=$1
cicpubits=$2
cicpuname=$3
ciUseMultiArch=$4
ciInstallALL=$5

#========================================================

echo "----------------------------------------------------"
echo " CodeTyphon OS Libraries Installation for"  
echo "               Chakra Linux" 
echo "----------------------------------------------------"
echo "   "

echo "[INFO] Start OS Update..."
echo "   "
sudo pacman -Syyu --noconfirm 

echo "   "
echo "[INFO] Start Libraries Installation..."
echo "   "


sudo pacman -S --noconfirm xterm
sudo pacman -S --noconfirm zip
sudo pacman -S --noconfirm unzip
sudo pacman -S --noconfirm wget

if [ $ciUseMultiArch = 1 ] ; 
then
 echo "   " 
 echo "[INFO] Remove gcc to install MultiArch gcc" 
 sudo pacman -Rs --noconfirm gcc
 echo "   " 
 sudo pacman -S --noconfirm gcc-multilib
 sudo pacman -S --noconfirm lib32-fakeroot
 sudo pacman -S --noconfirm lib32-libltdl
 sudo pacman -S --noconfirm multilib-devel
 sudo pacman -S --noconfirm gcc-libs-multilib 
else
 echo "   " 
 echo "[INFO] Remove multilib-devel" 
 sudo pacman -Rs --noconfirm multilib-devel
 echo "   " 
 sudo pacman -S --noconfirm gcc
 sudo pacman -S --noconfirm base-devel 
fi

sudo pacman -S --noconfirm devtools

sudo pacman -S --noconfirm make
sudo pacman -S --noconfirm gdb
sudo pacman -S --noconfirm binutils 
sudo pacman -S --noconfirm glib
sudo pacman -S --noconfirm glibc
sudo pacman -S --noconfirm libx11
sudo pacman -S --noconfirm libxtst
sudo pacman -S --noconfirm atk
sudo pacman -S --noconfirm freetype2
sudo pacman -S --noconfirm glu

sudo pacman -S --noconfirm xorg-fonts-100dpi 
sudo pacman -S --noconfirm xorg-fonts-75dpi 
sudo pacman -S --noconfirm ttf-freefont
sudo pacman -S --noconfirm ttf-liberation



# Install libraries for GTK2
if [ "$ciplatiform" = 0 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for GTK2"
    echo "   "
    sudo pacman -S --noconfirm gtk2 
    sudo pacman -S --noconfirm gdk-pixbuf2
    sudo pacman -S --noconfirm cairo 
    sudo pacman -S --noconfirm pango
fi

# Install libraries for QT4
if [ "$ciplatiform" = 1 ] || [ "$ciInstallALL" = 1 ] ;
then
    echo "   "
    echo "[INFO] Install libraries for QT4"
    echo "   "

    sudo pacman -S --noconfirm qt4
    sudo pacman -S --noconfirm qtwebkit
    sudo pacman -S --noconfirm libqt4-dev 
    sudo pacman -S --noconfirm qt4-qmake    
fi

# Install libraries for GTK3
if [ "$ciplatiform" = 3 ] ; 
then
    echo "   "
    echo "[INFO] Install libraries for GTK3"
    echo "   "
    sudo pacman -S --noconfirm gtk+-3.0   
fi

# Install libraries for GTK4
if [ "$ciplatiform" = 9 ] ; 
then
    echo "   "
    echo "[INFO] Install libraries for GTK4"
    echo "   "
    sudo pacman -S --noconfirm gtk+-4.0   
fi

# Install libraries for QT5
if [ "$ciplatiform" = 7 ] || [ "$ciInstallALL" = 1 ] ;
 then
    echo "   "
    echo "[INFO] Install libraries for QT5"
    echo "   "
    sudo pacman -S --noconfirm qt5
    sudo pacman -S --noconfirm qt5-base
    sudo pacman -S --noconfirm qt5-webkit
    sudo pacman -S --noconfirm libqt5-dev 
    sudo pacman -S --noconfirm qt5-qmake   
fi

sudo ldconfig

echo "----------------------------------------------------"
echo "CodeTyphon OS Libraries Installation" 
echo "Finish !!!"

#sleep 5