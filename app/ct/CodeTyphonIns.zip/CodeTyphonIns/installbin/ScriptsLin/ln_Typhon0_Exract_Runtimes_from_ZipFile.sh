# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

#========================MAIN===========================
. $PWD/ln_All_Functions.sh
getvalues


echo "   "
echo "---------------------------------------------------------"
echo "    Extract Runtimes Libraries From Zip File"   
echo "---------------------------------------------------------"

if [ -f ../allzips/binRuntimes.7z ] ;
then  

  if [ ! -d $vCTDir/binRuntimes/ ] ;
  then  
    sudo mkdir $vCTDir/binRuntimes/  
  fi

sudo $v7zipexe x ../allzips/binRuntimes.7z -o../ -y

sudo chmod -R 777 $vCTDir/binRuntimes/

echo "---------------------------------------"
echo "[INFO]: Extract Runtimes Libraries finish OK"

else

echo "---------------------------------------"
echo "[ERROR]: Runtimes Libraries Zip File NOT EXIST ???"

fi

echo "   "
