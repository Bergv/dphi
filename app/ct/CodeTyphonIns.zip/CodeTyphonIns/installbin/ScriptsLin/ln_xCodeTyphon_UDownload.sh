# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

#-------------------------------------------------------
actgetwwwfile() 
{
echo "   "
echo "[INFO]: Download file, please wait.."

cd ../

if [ -d zdownload ] ;
then 
  sudo rm -fr zdownload
fi

sudo mkdir zdownload
sudo chmod -R 777 zdownload/

if [ -f zdownload/${cuval4} ] ;
then 
  sudo rm -f zdownload/${cuval4} 
fi

cd zdownload

#sudo $vCTDir/binBase/${cuval3}/wget ${cuval2}

sudo $vwgetexe ${cuval2}
sudo chmod 777 -R ../zdownload/
cd ../

if [ ! -f zdownload/${cuval4} ] ;
then 
  sudo rm -f zdownload/${cuval4} 
fi

exit
}

#-------------------------------------------------------
actgetwwwlistfiles() 
{
echo "   "
echo "[INFO]: Download files, please wait..."

if [ ! -d ../zdownload ] ;
then 
  sudo mkdir ../zdownload
  sudo chmod -R 777 ../zdownload/ 
fi

cd ../zdownload

#sudo $vCTDir/binBase/${cuval3}/wget -i ${cuval2}

sudo $vwgetexe -i ${cuval2}
sudo chmod 777 -R ../zdownload/
sudo chmod +x *.sh

if [ -f ${cuval4} ] ;
then 
sudo ./${cuval4}
fi

cd ../

if [ -d zdownload ] ;
then 
  sudo rm -fr zdownload
fi

exit
}

# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

cuactn=$1
cuval2=$2
cuval3=$3
cuval4=$4
cuval5=$5
cuval6=$6

echo "   "
echo " [INFO]: CodeTyphon Download Engine settings "
echo $cuactn
echo $cuval2
echo $cuval3
echo $cuval4
echo $cuval5
echo $cuval6
echo "   "


case $cuactn in
1)
  actgetwwwfile 
 ;;
2)
  actgetwwwlistfiles
 ;;
esac 

echo "???????????????????????????????????????????????????????????"
echo "   [ERROR]:  Sorry NO Correct Script Parameters."
echo "???????????????????????????????????????????????????????????"

exit

