# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob()
{

echo "   "
echo "=============================================================="
echo " Build FreePascal $vBits for $vHostOSRealName Bootstrap Compiler"
echo "=============================================================="
echo "   "

if [ ! -f $vFpcSrcDir/Makefile.fpc ] ;
then    
    echo "[INFO]: FPC$vBits Source files not exists, extracting..."
    ./ln_FPC0_Extract_Source_From_ZipFile.sh
fi

if [ ! -f $vFpcExeDir/$vFpcExeFile ] ;
then      
    echo "[INFO]: FPC$vBits Binary files not exists, extracting..."
    ./ln_FPC0_Install_Bin_Files.sh 64
fi

echo "------------------------------------------------"
echo "        Clean FreePascal $vBits" 
echo "------------------------------------------------"

./ln_FPC0_Clean_SourceDir.sh


cd $vCTDir/fpcsrc

echo "------------------------------------------------"
echo "   Build FreePascal $vBits Bootstrap Compiler" 
echo "------------------------------------------------"

case $vOSName in
solaris)
   sudo $vMake compiler_cycle OPT="-Xn" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
linux)  
   sudo $vMake compiler_cycle PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove    
 ;;
freebsd)
   sudo $vMake compiler_cycle OPT="-Fl/usr/local/lib" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
openbsd)
   sudo $vMake compiler_cycle OPT="-Fl/usr/local/lib" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
netbsd)
   sudo $vMake compiler_cycle OPT="-Fl/usr/local/lib" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
dragonfly)
   sudo $vMake compiler_cycle OPT="-Fl/usr/local/lib" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
darwin)  
   sudo $vMake compiler_cycle OPT="-XR/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove    
 ;;
*)
   sudo $vMake compiler_cycle PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove 
 ;;
esac

# =======================================================
if [ ! -f $vCTDir/fpcsrc/compiler/$vFpcExeFile ] ;
then
  echo "   "
  echo "??????????????????????????????????????????????????????"
  echo "[ERROR]: FPC$vBits Bootstrap Compiler NOT Build"
  echo "??????????????????????????????????????????????????????"
  exit
fi

sudo chmod -R 777 $vFpcDir/

sudo cp -f $vCTDir/fpcsrc/compiler/$vFpcExeFile $vFpcExeDir/

sudo chmod -R 777 $vFpcBinDir
sudo chmod -R 777 $vFpcDir

cd $vCTDir/ScriptsLin/
./ln_FPC0_Clean_SourceDir.sh


echo "   "
echo "[FINAL INFO]:FPC$vBits Bootstrap Compiler Build OK. It's in FPC$vBits Bin Dir !!!!" 
echo "   "

}
# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

if [ $vBits = 64 ] ;
then 
 dothejob
fi

