#!/bin/bash
# ctusersctript:CodeTyphon Studio Setup
# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

echo "   "
echo "===================================================="
echo "              CodeTyphon Studio "
echo "            Version 7.50 (GEN 7)"
echo "     Setup for Linux-Solaris-Openindiana-MacOS"
echo "          FreeBSD-NetBSD-OpenBSD-DragonFly"
echo "===================================================="

# ==============Make CodeTyphon Directory =================
makectdirectory()
{

sudo chmod -R 777 allzips/
sudo chmod -R 777 binBase/
sudo chmod -R 777 ScriptsLin/
sudo chmod -R 777 ScriptsLin/systems/
sudo chmod -R 777 ScriptsLin/crossbuild/

sudo chmod -x *.*

sudo chmod +x *.sh
sudo chmod +x ScriptsLin/*.sh
sudo chmod +x ScriptsLin/systems/*.sh
sudo chmod +x ScriptsLin/crossbuild/*.sh

#------------------------ Delete old dirs -----------------------
if [ -d bin ] ;
then 
  sudo rm -fr bin
fi

if [ -d binSettings ] ;
then 
  sudo rm -fr binSettings
fi

if [ -d Settings ] ;
then 
  sudo rm -fr Settings
fi
#------------------------ Create new dirs ----------------------
sudo mkdir binSettings
sudo mkdir Settings
sudo mkdir binLibraries

sudo chmod -R 777 binSettings/
sudo chmod -R 777 Settings/
sudo chmod -R 777 binLibraries/

if [ -d zupdate ] ;
then 
  sudo rm -fr zupdate
fi
#------------------------ uncompess ---------------------------

if [ -f allzips/binsettings.7z ] ;
then 
  echo "[INFO]: Exract settings Zip file..."
  sudo $v7zipexe x allzips/binsettings.7z -o$vCTDir/binSettings/ -y   
fi
sudo chmod -R 777 binSettings/

if [ -f allzips/binswitcher.7z ] ;
then 
  echo "[INFO]: Exract switcher Zip file..."
  sudo $v7zipexe x allzips/binswitcher.7z -o$vCTDir/binSettings/ -y   
fi
sudo chmod -R 777 binSettings/

if [ -f allzips/binCenter.7z ] ;
then 
  echo "[INFO]: Exract binCenter Zip file..."
  sudo $v7zipexe x allzips/binCenter.7z -o$vCTDir -y 
  sudo chmod -R 777 binCenter/
else
  echo "[ERROR]: binCenter Zip file NOT Exists..."
fi
sudo chmod -R 777 binCenter/

if [ -f allzips/help.7z.001 ] ;
then 
  echo "[INFO]: Exract help Zip file..."
  sudo $v7zipexe x allzips/help.7z.001 -o$vCTDir -y 
  sudo chmod -R 777 help/
else
  echo "[ERROR]: help Zip file NOT Exists..."
fi

#----------------------- Permissions ----------------------------

#sudo chmod -x help/*
sudo chmod +x binCenter/*
sudo chmod +x *.sh
sudo chmod +x ScriptsLin/*.sh
sudo chmod +x ScriptsLin/systems/*.sh
sudo chmod +x ScriptsLin/crossbuild/*.sh

sudo chmod -R 777 binSettings/
sudo chmod -R 777 binCenter/
sudo chmod -R 777 Settings/
sudo chmod -R 777 help/


if [ -d CodeOcean ] ;
then 
  sudo chmod -R 777 CodeOcean/
fi

if [ -d /usr/local/codetyphon/xIDE ] ;
then 
  sudo chmod -R 777 xIDE/
  sudo chmod -R 777 xLAB_App/
fi

if [ -d $vCTDir/typhon ] ;
then 
  sudo chmod -R 777 $vCTDir/typhon/
fi

#------------ INIT Multiarch ------------------
# Get default OS MultiArch

GetDefaultOSMultiArch

if [ $vUseMultiArch = 1 ] ;
then   
 sudo cp -f $vCTDir/binSettings/switcher/CT_If_Use_MultiArch.ctsw $vCTDir/Settings/ 
 echo "   "
 echo "[INFO]: Ude MultiArch Mode..." 
else
 sudo rm -f $vCTDir/Settings/*CT_If_Use*  
fi

sudo chmod -R 777 Settings/
}

#============== Install QT4Pas or QT5Pas Libraries ====================
makeinstallqtxpas()
{
if [ $vLCLplat = 1 ] ;
then   
sudo cp -f $vCTDir/binSettings/switcher/CT_Use_QT4.ctsw $vCTDir/Settings/

cd $vCTDir/ScriptsLin
./ln_Typhon1_QT4pas_Install.sh
cd $vCTDir
fi

if [ $vLCLplat = 7 ] ;
then   
sudo cp -f $vCTDir/binSettings/switcher/CT_Use_QT5.ctsw $vCTDir/Settings/

cd $vCTDir/ScriptsLin
./ln_Typhon1_QT5pas_Install.sh
cd $vCTDir
fi

}

#------------ CT Center Links for Unix ---------------------
makectlinks_unix()
{
if [ -f $vOSAppDskDir/CodeTyphon ] ;
then 
  sudo rm -f $vOSAppDskDir/CodeTyphon
fi

if [ -f $vOSAppPngDir/codetyphon.png ] ;
then 
  sudo rm -f $vOSAppPngDir/codetyphon.png
fi

if [ -f $vctuserdesk/codetyphon ] ;
then
  sudo rm -f $vctuserdesk/codetyphon
fi

sudo cp -f binSettings/settings/allforunix/codetyphon.desktop $vOSAppDskDir/
sudo cp -f binSettings/settings/allforunix/codetyphon.png $vOSAppPngDir/ 

if [ -f $vOSAppDskDir/CodeTyphon ] ;
then      
  sudo chmod 777 $vOSAppDskDir/CodeTyphon/
fi
sudo chmod 777 $vOSAppPngDir/codetyphon.png

#------------------------

vTempCPUOSPlatStr=${vCPUOS}-$vLCLPlatStr

if [ $vLCLplat = 1 ] ;
then
 vTempCPUOSPlatStr=${vCPUOS}-qt
fi
 
#------------------------
    
if [ -f $vCTDir/binCenter/${vTempCPUOSPlatStr}/CodeTyphon ] ;
then   
 sudo ln -f -s $vCTDir/binCenter/${vTempCPUOSPlatStr}/CodeTyphon /usr/bin/codetyphon 
 
if [ -d $vctuserdesk ] ;
then
 sudo cp -f $vCTDir/binSettings/settings/allforunix/codetyphon.desktop $vctuserdesk/
 sudo chmod 777 $vctuserdesk/codetyphon.desktop
 sudo chown $vctuser $vctuserdesk/codetyphon.desktop
fi
 
 echo "   "
 echo "[INFO]: Make Link and Use CTC for $vTempCPUOSPlatStr executable..."
 echo "   "
else
 sudo ln -f -s $vCTDir/binCenter/${vCPUOS}-gtk2/CodeTyphon /usr/bin/codetyphon 
 echo "   "
 echo "[INFO]: Make Link and Use CTC for GTK2 executable, CTC for $vTempCPUOSPlatStr NOT exists..."
 echo "   "
fi

}

#------------ CT Center Links for MacOS ---------------------
makectlinks_macos()
{
if [ -d $vOSAppDskDir/CodeTyphon.app ] ;
then
  sudo chmod -R 777 $vOSAppDskDir/CodeTyphon.app
  sudo rm -fr $vOSAppDskDir/CodeTyphon.app
fi

#------------------------

vTempCPUOSPlatStr=${vCPUOS}-$vLCLPlatStr

if [ $vLCLplat = 1 ] ;
then
 vTempCPUOSPlatStr=${vCPUOS}-qt
fi
 
#------------------------
    
if [ -f $vCTDir/binCenter/$vTempCPUOSPlatStr/CodeTyphon ] ;
then   
 sudo ln -f -s $vCTDir/binCenter/$vTempCPUOSPlatStr/CodeTyphon /usr/bin/codetyphon
 
 sudo chmod 777 $vCTDir/binCenter/$vTempCPUOSPlatStr/CodeTyphon
 sudo chmod -R 777 $vCTDir/binSettings/settings/allformacos/
 sudo chmod -R 777 $vCTDir/binSettings/settings/allformacos/CodeTyphon.app

 sudo cp -fr $vCTDir/binSettings/settings/allformacos/CodeTyphon.app $vOSAppDskDir/
 sudo ln -f -s $vCTDir/binCenter/$vTempCPUOSPlatStr/CodeTyphon $vOSAppDskDir/CodeTyphon.app/Contents/MacOS/CodeTyphon
   
 echo "   "
 echo "[INFO]: Make Link and Use CTC for $vTempCPUOSPlatStr executable..."
 echo "   "
 
else

 sudo chmod 777 $vCTDir/binCenter/x86_64-darwin-cocoa/CodeTyphon
 sudo chmod -R 777 $vCTDir/binSettings/settings/allformacos/
 sudo chmod -R 777 $vCTDir/binSettings/settings/allformacos/CodeTyphon.app

 sudo cp -fr $vCTDir/binSettings/settings/allformacos/CodeTyphon.app $vOSAppDskDir/
 sudo ln -f -s $vCTDir/binCenter/x86_64-darwin-cocoa/CodeTyphon $vOSAppDskDir/CodeTyphon.app/Contents/MacOS/CodeTyphon
 
 echo "   "
 echo "[INFO]: CTC for $vTempCPUOSPlatStr NOT exists...Use Cocoa Platform CTC 64bit executable...."
 echo "   "
fi

sudo chmod -R 777 $vOSAppDskDir/CodeTyphon.app

}

#============== Make Links General =========================
makectlinks()
{  
if [ $vOSName = darwin ] ;
then 
 makectlinks_macos
else
 makectlinks_unix
fi
}

#=================== PLATFORM SETUP ================================
setupmultiarch()
{

echo "   " 
echo "===================================================="
echo "    CodeTyphon Studio Multi-Architecture Setup"
echo "      Current Multiarch Mode: $vUseMultiArch"
echo "===================================================="
echo "   "
echo "   0) NO  Multi-Architecture Mode (Multiarch=0)"
echo "   "
echo "   1) Use Multi-Architecture Mode (Multiarch=1)"
echo "   "
echo "   "
echo "   9) Back to Main Setup"
echo "   "
echo -n ">>> Select Mode (press 0..9 key): "

read var_read

case $var_read in
#------------------- NO -------------------
0)   
  sudo rm -f $vCTDir/Settings/*Use_MultiArch* 
  getvalues  
;;
#------------------- YES -------------------
1)    
  sudo cp -f $vCTDir/binSettings/switcher/CT_If_Use_MultiArch.ctsw $vCTDir/Settings/   
  getvalues  
;;

esac

sudo chmod -R 777 Settings/

setupmenu
}


#=================== PLATFORM SETUP for Unix ====================
setupplatform_unix()
{
echo "   "
echo "   " 
echo "===================================================="
echo "     CodeTyphon Studio Unix Platform (widget) Setup"
echo "        Current Platform: $vLCLPlatStr"
echo "===================================================="
echo "   "
echo "Warning: Install System Libraries after every Platform change"
echo "   "
echo "   1) GTK2           (Default)"
echo "   2) QT4"
echo "   3) QT5"
echo "   4) GTK3           (Experimental)"
echo "   5) GTK4           (Experimental)"
echo "   6) FpGUI          (Experimental)"
echo "   7) CustomDrawn    (Experimental)"
echo "   "
echo "   9) Back to Main Setup"
echo "   "
echo -n ">>> Select a platform (press 0..9 key): "

read var_read

case $var_read in
#------------------- Gtk2 -------------------
1)   
  sudo rm -f $vCTDir/Settings/*CT_Use* 
  getvalues
  makectlinks
;;
#------------------- QT4 -------------------
2)  
  sudo rm -f $vCTDir/Settings/*CT_Use*
  sudo cp -f $vCTDir/binSettings/switcher/CT_Use_QT4.ctsw $vCTDir/Settings/     
  getvalues
  makeinstallqtxpas
  makectlinks   
;;
#------------------- QT5 -------------------
3) 
  sudo rm -f $vCTDir/Settings/*CT_Use*
  sudo cp -f $vCTDir/binSettings/switcher/CT_Use_QT5.ctsw $vCTDir/Settings/ 
  getvalues
  makeinstallqtxpas
  makectlinks   
;;
#------------------- Gtk3 -------------------
4) 
  sudo rm -f $vCTDir/Settings/*CT_Use*
  sudo cp -f $vCTDir/binSettings/switcher/CT_Use_GTK3.ctsw $vCTDir/Settings/ 
  getvalues
  makectlinks   
;;
#------------------- Gtk4 -------------------
5) 
  sudo rm -f $vCTDir/Settings/*CT_Use*
  sudo cp -f $vCTDir/binSettings/switcher/CT_Use_GTK4.ctsw $vCTDir/Settings/ 
  getvalues
  makectlinks   
;;
#------------------- FpGUI -------------------
6) 
  sudo rm -f $vCTDir/Settings/*CT_Use*
  sudo cp -f $vCTDir/binSettings/switcher/CT_Use_fpGUI.ctsw $vCTDir/Settings/ 
  getvalues
  makectlinks   
;;
#------------------- CustomDrawn -----------
7)  
  sudo rm -f $vCTDir/Settings/*CT_Use*
  sudo cp -f $vCTDir/binSettings/switcher/CT_Use_CustomDrawn.ctsw $vCTDir/Settings/ 
  getvalues
  makectlinks  
;;
esac

sudo chmod -R 777 Settings/
}

#=================== PLATFORM SETUP for MacOS ===================
setupplatform_macos()
{
echo "   "
echo "   " 
echo "===================================================="
echo "    CodeTyphon Studio MacOS Platform (widget) Setup "
echo "        Current Platform: $vLCLPlatStr"
echo "===================================================="
echo "   "
echo "Warning: Install System Libraries after every Platform change"
echo "   "
echo "   1) Cocoa         (Default)"
echo "   2) Carbon"
echo "   3) GTK2"
echo "   4) QT4"
echo "   5) QT5"
echo "   6) GTK3           (Experimental)"
echo "   7) FpGUI          (Experimental)"
echo "   8) CustomDrawn    (Experimental)"
echo "   "
echo "   9) Back to Main Setup"
echo "   "
echo -n ">>> Select a platform (press 0..9 key): "

read var_read

case $var_read in
#------------------- Cocoa -------------------
1)   
  sudo rm -f $vCTDir/Settings/*CT_Use* 
  getvalues
  makectlinks
;;
#------------------- Carbon -------------------
2)  
  sudo rm -f $vCTDir/Settings/*CT_Use*
  sudo cp -f $vCTDir/binSettings/switcher/CT_Use_Carbon.ctsw $vCTDir/Settings/     
  getvalues
  makectlinks   
;;
#------------------- GTK2 -------------------
3) 
  sudo rm -f $vCTDir/Settings/*CT_Use*
  sudo cp -f $vCTDir/binSettings/switcher/CT_Use_GTK2.ctsw $vCTDir/Settings/ 
  getvalues
  makectlinks  
;;
#------------------- QT4 -------------------
4) 
  sudo rm -f $vCTDir/Settings/*CT_Use*
  sudo cp -f $vCTDir/binSettings/switcher/CT_Use_QT4.ctsw $vCTDir/Settings/ 
  getvalues
  makeinstallqtxpas
  makectlinks  
;;
#------------------- QT5 -------------------
5) 
  sudo rm -f $vCTDir/Settings/*CT_Use*
  sudo cp -f $vCTDir/binSettings/switcher/CT_Use_QT5.ctsw $vCTDir/Settings/ 
  getvalues
  makeinstallqtxpas
  makectlinks  
;;
#------------------- GTK3 -------------------
6) 
  sudo rm -f $vCTDir/Settings/*CT_Use*
  sudo cp -f $vCTDir/binSettings/switcher/CT_Use_GTK3.ctsw $vCTDir/Settings/ 
  getvalues
  makectlinks  
;;
#------------------- fpGUI -------------------
7) 
  sudo rm -f $vCTDir/Settings/*CT_Use*
  sudo cp -f $vCTDir/binSettings/switcher/CT_Use_fpGUI.ctsw $vCTDir/Settings/ 
  getvalues
  makectlinks  
;;
#------------------- CustomDrawn ---------------
8) 
  sudo rm -f $vCTDir/Settings/*CT_Use*
  sudo cp -f $vCTDir/binSettings/switcher/CT_Use_CustomDrawn.ctsw $vCTDir/Settings/ 
  getvalues
  makectlinks  
;;
esac

sudo chmod -R 777 Settings/
}

#=================== PLATFORM SETUP General =========================
setupplatform()
{

if [ $vOSName = darwin ] ;
then 
 setupplatform_macos
else
 setupplatform_unix
fi

setupmenu
}

#=================== MAIN MENU =============================
setupmenu()
{
cd /usr/local/codetyphon

echo "   " 
echo "===================================================="
echo "  CodeTyphon Studio 7.50 Setup for ${vHostOSRealName}${vBits}"
echo "   Settings: Platform=$vLCLPlatStr  Multiarch Mode=$vUseMultiArch"
echo "===================================================="
echo "   "
echo "   0) Install System Libraries"
echo "   1) Run CodeTyphon Center (CTC)"
echo "   "
echo "     11) -- Platform (widget) Setup"
echo "     12) -- Multi-Architecture Setup"
echo "   "
echo "   3) Remove FreePascal"
echo "   4) Remove and Build FreePascal"
echo "   "
echo "   5) Remove Typhon IDE"
echo "   6) Remove and Build Typhon IDE"
echo "   "
echo "   7) Remove ALL"
echo "   8) Remove and Build ALL"
echo "   "
echo "   9) EXIT"
echo "   "
echo -n ">>> Select an action (press 0..9 key): "

read var_read

case $var_read in

#------------------- Install System Libraries ----------------
0)   
    cd ScriptsLin
    ./ln1_SysLibraries_Install.sh     
;;
#------------------- Run CodeTyphon Center --------------------
1)  
  #./binCenter/${vCPUOSPlat}/CodeTyphon
  cd /usr/bin
  ./codetyphon 
;;
#------------------- Platform Setup ----------------------------
11)  
  setupplatform
;;
#------------------- Multi-Architecture Setup ------------------
12)  
  setupmultiarch
;;
#------------------- Remove FreePascal -------------------------
3)
 cd ScriptsLin
 ./ln_xCodeTyphon_Remove_FPC.sh
;;
#------------------- Remove and Build FreePascal ---------------
4)
 cd ScriptsLin
 ./ln_CodeTyphon_Remove_Make_FPC.sh
;;
#------------------- Remove Typhon ----------------------------
5) 
 cd ScriptsLin
 ./ln_xCodeTyphon_Remove_Typhon.sh
;;
#------------------- Remove and Build Typhon -------------------
6) 
 cd ScriptsLin
  ./ln_CodeTyphon_Remove_Make_Typhon.sh
;;
#------------------- Remove ALL --------------------------------
7)  
 cd ScriptsLin
 ./ln_xCodeTyphon_Remove_ALL.sh
;;
#------------------- Remove and Build ALL -----------------------
8) 
 cd ScriptsLin
  ./ln_CodeTyphon_Remove_Make_ALL.sh
;;
#-------------------  Exit -----------------------
*) 
 exit
;;

esac

setupmenu
}

#======================MAIN ======================
if [ ! -d /usr/local/codetyphon ] ;
then 

echo " ???????????????????????????????????????? "
echo "  Critical ERROR                          "
echo "  CodeTyphon Directory NOT Exists         "
echo "  please, install CodeTyphon First        "
echo " ???????????????????????????????????????? "

else

cd /usr/local/codetyphon

. $PWD/ScriptsLin/ln_All_Functions.sh
getvalues
 
makectdirectory
makectlinks
makeinstallqtxpas
setupmenu

fi


