# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


dothejob() 
{

#------------- Remove Toolchains Library Directory -------------
if [ -d $vCTDir/binLibraries ] ;
then 
  sudo rm -fr $vCTDir/binLibraries
  echo "[INFO]: Libraries Directory Removed OK"
else
  echo "[INFO]: Libraries Directory NOT EXIST, nothing to do ..."   
fi
}

# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi


