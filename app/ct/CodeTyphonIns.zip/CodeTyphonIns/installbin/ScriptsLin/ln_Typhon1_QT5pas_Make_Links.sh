# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


# ======================== Make Links Unix =========================
dothejob_unix() 
{

if [ ! -f $vCTDir/qt5pas/${vCPUOS}/libQt5Pas.so.1.2.12 ] ;
then
 echo "   "
 echo "[ERROR] File $vCTDir/qt5pas/${vCPUOS}/libQt5Pas.so.1.2.12 NOT Exists..." 
 echo "[ERROR] Can't Make qt5pas links..."
 echo "   " 
 exit
fi

#---- Check and Make Local Links -------

 if [ ! -f ${vCTDir}/qt5pas/${vCPUOS}/libQt5Pas.so.1.2 ] ;
  then  
    sudo ln -f -s ${vCTDir}/qt5pas/${vCPUOS}/libQt5Pas.so.1.2.12 ${vCTDir}/qt5pas/${vCPUOS}/libQt5Pas.so.1.2
  fi

 if [ ! -f ${vCTDir}/qt5pas/${vCPUOS}/libQt5Pas.so.1 ] ;
  then  
    sudo ln -f -s ${vCTDir}/qt5pas/${vCPUOS}/libQt5Pas.so.1.2.12 ${vCTDir}/qt5pas/${vCPUOS}/libQt5Pas.so.1
  fi

 if [ ! -f ${vCTDir}/qt5pas/${vCPUOS}/libQt5Pas.so ] ;
  then  
    sudo ln -f -s ${vCTDir}/qt5pas/${vCPUOS}/libQt5Pas.so.1.2.12 ${vCTDir}/qt5pas/${vCPUOS}/libQt5Pas.so
  fi

sudo chmod -R 777 $vCTDir/qt5pas/

#---- Remove OLD Links from OS Lib Folder -------

  if [ -f /usr/${vOSLibSub}/libQt5Pas.so ] ;
  then  
    sudo rm -f /usr/${vOSLibSub}/libQt5Pas.so
  fi
  
  if [ -f /usr/${vOSLibSub}/libQt5Pas.so.1 ] ;
  then  
    sudo rm -f /usr/${vOSLibSub}/libQt5Pas.so.1
  fi
  
  if [ -f /usr/${vOSLibSub}/libQt5Pas.so.1.2 ] ;
  then  
    sudo rm -f /usr/${vOSLibSub}/libQt5Pas.so.1.2
  fi
  
  if [ -f /usr/${vOSLibSub}/libQt5Pas.so.1.2.12 ] ;
  then  
    sudo rm -f /usr/${vOSLibSub}/libQt5Pas.so.1.2.12
  fi

#---- Make new Links to OS Lib Folder -----------

  sudo cp -f ${vCTDir}/qt5pas/${vCPUOS}/libQt5Pas.so.1.2.12 /usr/${vOSLibSub}/libQt5Pas.so.1.2.12
  sudo chmod 777 /usr/${vOSLibSub}/libQt5Pas.so.1.2.12
  
  sudo ln -f -s /usr/${vOSLibSub}/libQt5Pas.so.1.2.12 /usr/${vOSLibSub}/libQt5Pas.so.1.2
  sudo ln -f -s /usr/${vOSLibSub}/libQt5Pas.so.1.2.12 /usr/${vOSLibSub}/libQt5Pas.so.1
  sudo ln -f -s /usr/${vOSLibSub}/libQt5Pas.so.1.2.12 /usr/${vOSLibSub}/libQt5Pas.so
 
  sudo chmod 777 /usr/${vOSLibSub}/libQt5Pas.so.1.2
  sudo chmod 777 /usr/${vOSLibSub}/libQt5Pas.so.1
  sudo chmod 777 /usr/${vOSLibSub}/libQt5Pas.so
  
echo "[INFO] Make qt5pas links to /usr/${vOSLibSub}/ for ${vCPUOS} finish OK" 
}

# ======================== Make Links MacOS =========================
dothejob_macos() 
{

if [ ! -d $vCTDir/qt5pas/${vCPUOS}/Qt5Pas.framework ] ;
then
 echo "   "
 echo "[ERROR] File $vCTDir/qt5pas/${vCPUOS}/Qt5Pas.framework NOT Exists..." 
 echo "[ERROR] Can't Make Qt5Pas.framework links..."
 echo "   " 
 exit
fi

sudo chmod -R 777 $vCTDir/qt5pas/

# --- Remove MacPorts Qt5Pas Version -----
if [ -d /opt/local/libexec/qt5/lib/Qt5Pas.framework ] ;
then  
    sudo rm -fr /opt/local/libexec/qt5/lib/Qt5Pas.framework
    echo "[INFO] REMOVE MacPorts Qt5Pas Version from /opt/local/libexec/qt5/lib/Qt5Pas.framework"
fi

# --- Remove OLD CT Qt5Pas Version -----
if [ -d /Library/Frameworks/Qt5Pas.framework ] ;
then  
    sudo rm -fr /Library/Frameworks/Qt5Pas.framework
fi

sudo cp -fr ${vCTDir}/qt5pas/${vCPUOS}/Qt5Pas.framework /Library/Frameworks/Qt5Pas.framework
sudo chmod -R 777 /Library/Frameworks/Qt5Pas.framework

# --- make internal links -----

sudo rm -f /Library/Frameworks/Qt5Pas

sudo chmod 777 /Library/Frameworks/Qt5Pas.framework/Versions/1/Qt5Pas
sudo ln -f -s /Library/Frameworks/Qt5Pas.framework/Versions/1/Qt5Pas /Library/Frameworks/Qt5Pas.framework/Qt5Pas
sudo chmod 777 /Library/Frameworks/Qt5Pas.framework/Qt5Pas
sudo chmod -R 777 /Library/Frameworks/Qt5Pas.framework
  
echo "[INFO] Make Qt5Pas.framework links to /Library/Frameworks/Qt5Pas.framework for ${vCPUOS} finish OK"
}

# ======================== Make Links General ======================
dothejob() 
{
if [ $vOSName = darwin ] ;
then 

  if [ $vBits = 64 ] ;
  then 
   dothejob_macos
  fi 
  
else
 dothejob_unix
fi
}


#========================MAIN===========================
. $PWD/ln_All_Functions.sh
getvalues

echo "   "
echo "---------------------------------------------------------"
echo "    Make qt5pas Libraries Links"   
echo "---------------------------------------------------------"
echo "   "

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi


