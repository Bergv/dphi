# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

echo "   "
echo "======================================================================"
echo "======================================================================"
echo "        Make ALL $cbFPCType Cross Compiler Elemments for" 
echo "                  ALL Supported CPU-OS "
echo "               This will be take long time..." 
echo "======================================================================"
echo "======================================================================"


./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 linux ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 go32v2 ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 win32 ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 os2 ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 freebsd ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 beos ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 haiku ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 netbsd ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 solaris ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 qnx ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 netware ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 openbsd ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 wdosx ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 darwin ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 emx ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 watcom ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 netwlibc ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 wince ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 embedded ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 symbian ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 nativent ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 iphonesim ppcross386 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i386 android ppcross386 xxxx

./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE x86_64 linux ppcrossx64 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE x86_64 freebsd ppcrossx64 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE x86_64 netbsd ppcrossx64 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE x86_64 solaris ppcrossx64 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE x86_64 openbsd ppcrossx64 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE x86_64 darwin ppcrossx64 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE x86_64 win64 ppcrossx64 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE x86_64 embedded ppcrossx64 xxxx

./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE arm linux ppcrossarm xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE arm palmos ppcrossarm xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE arm darwin ppcrossarm xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE arm wince ppcrossarm xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE arm gba ppcrossarm xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE arm nds ppcrossarm xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE arm embedded ppcrossarm xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE arm symbian ppcrossarm xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE arm android ppcrossarm xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE armeb linux ppcrossarm xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE armeb embedded ppcrossarm xxxx

./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE m68k linux 
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE m68k freebsd 
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE m68k netbsd 
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE m68k amiga 
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE m68k atari 
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE m68k openbsd 
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE m68k palmos 
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE m68k embedded 

./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE powerpc linux ppcrossppc xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE powerpc netbsd ppcrossppc xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE powerpc amiga ppcrossppc xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE powerpc macos ppcrossppc xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE powerpc darwin ppcrossppc xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE powerpc morphos ppcrossppc xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE powerpc embedded ppcrossppc xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE powerpc wii ppcrossppc xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE powerpc aix ppcrossppc xxxx

./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE sparc linux ppcrosssparc xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE sparc netbsd ppcrosssparc xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE sparc solaris ppcrosssparc xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE sparc embedded ppcrosssparc xxxx

./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE powerpc64 linux ppcrossppc64 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE powerpc64 darwin ppcrossppc64 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE powerpc64 embedded ppcrossppc64 xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE powerpc64 aix ppcrossppc64 xxxx

./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE avr embedded ppcavr xxxx

./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE mips linux ppcmips xxxx
./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE mipsel linux ppcmipsel xxxx

./ln_FPCx_Build_Cross.sh $cbFPCType $cbFPCCPUOS $cbFPCStartEXE i8086 msdos ppc8086 xxxx


# sleep 120

}

# =================== MAIN =============================
. /usr/local/codetyphon/ScriptsLin/ln_All_Functions.sh
getvalues

cbFPCType=$1
cbFPCCPUOS=$2
cbFPCStartEXE=$3
cbTARGETCPU=$4
cbTARGETOS=$5
cbFPCCrossEXE=$6

dothejob

echo "---------------------------------------"
echo "[FINAL INFO] Make ALL Cross Compiler Elemments finish"
echo "   "
