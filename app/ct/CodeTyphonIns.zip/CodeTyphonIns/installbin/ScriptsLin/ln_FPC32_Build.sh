# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob()
{

echo "   "
echo "=============================================================="
echo "            Build FreePascal $vBits for $vHostOSRealName"
echo "=============================================================="
echo "   "

if [ ! -f $vFpcSrcDir/Makefile.fpc ] ;
then    
    echo "[INFO]: FPC$vBits Source files not exists, extracting..."
    ./ln_FPC0_Extract_Source_From_ZipFile.sh
fi

if [ ! -f $vFpcExeDir/$vFpcExeFile ] ;
then      
    echo "[INFO]: FPC$vBits Binary files not exists, extracting..."
    ./ln_FPC0_Install_Bin_Files.sh 32
fi

if [ -d $vFpcDir/newfpc ] ;
then     
    echo "[INFO]: Remove OLD FreePascal temporary build folder..."
    sudo rm -rf $vFpcDir/newfpc
fi

if [ -d $vFpcDir/fpc$vBits/units/$vCPUOS ] ;
then     
    echo "[INFO]: Remove OLD FPC units folder..."
    sudo rm -rf $vFpcDir/fpc$vBits/units/$vCPUOS
fi

cd $vCTDir/fpcsrc

echo "------------------------------------------------"
echo "        Clean FreePascal $vBits" 
echo "------------------------------------------------"
sudo $vMake clean PP=$vFpcExeDir/$vFpcExeFile

echo "------------------------------------------------"
echo "        Build FreePascal $vBits MultiArch=$vUseMultiArch" 
echo "------------------------------------------------"

#sleep 100

case $vOSName in
solaris)
   sudo $vMake all OPT="-Xn" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
linux)  
   sudo $vMake all PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
freebsd)
   sudo $vMake all OPT="-Fl/usr/local/lib" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
openbsd)
   sudo $vMake all OPT="-Fl/usr/local/lib" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
netbsd)
   sudo $vMake all OPT="-Fl/usr/local/lib" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
dragonfly)
   sudo $vMake all OPT="-Fl/usr/local/lib" PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
darwin)  
   sudo $vMake all PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
*)
   sudo $vMake all PP=$vFpcExeDir/$vFpcExeFile PPUMOVE=/usr/local/codetyphon/fpcsrc/compiler/utils/ppumove
 ;;
esac

# =======================================================
if [ -f $vCTDir/Settings/CT_FPC_Stop_Before_Install.ctsw ] ;
then
  echo "   "
  echo "[INFO]: Switch, FPC Stop Before Install Procedure, is ON."
  echo "        FPC Build procedure STOP.."
  echo "   "
  exit
fi
# =====================================================
echo "   "
echo "------------------------------------------------"
echo "        Install FreePascal $vBits" 
echo "------------------------------------------------"

sudo $vMake install PP=$vFpcExeDir/$vFpcExeFile INSTALL_PREFIX=/usr/local/codetyphon/fpc/newfpc

echo "   "
echo "------------------------------------------------"
echo "        Clean FreePascal $vBits" 
echo "------------------------------------------------"
sudo $vMake clean PP=$vFpcExeDir/$vFpcExeFile

# =====================================================
echo "   "
echo "------------------------------------------------"
echo "        Copy FreePascal $vBits" 
echo "------------------------------------------------"

if [ ! -d $vFpcBitsDir/ ] ;
then   
  sudo mkdir $vFpcBitsDir
fi

sudo chmod -R 777 $vFpcDir/

sudo cp -f $vFpcDir/newfpc/bin/* $vFpcExeDir/
sudo cp -fr $vFpcDir/newfpc/share/* $vFpcBitsDir/

sudo cp -fr $vFpcDir/newfpc/lib/fpc/$vFpcVer/* $vFpcBitsDir/
sudo rm -fr $vFpcDir/newfpc/lib/fpc/$vFpcVer

sudo cp -fr $vFpcDir/newfpc/lib/fpc/* $vFpcBitsDir/

sudo rm -fr $vFpcDir/newfpc

sudo mv -f $vFpcBitsDir/$vFpcExeFile $vFpcExeDir/


sudo chmod -R 777 $vFpcBinDir
sudo chmod -R 777 $vFpcDir

#=========================================

sudo rm -f $vOSBinDir/$vFpcExeFile
sudo rm -f $vOSBinDir/fpc$vBits

if [ ! -d $vOSBinDir/ ] ;
then   
  sudo mkdir $vOSBinDir
  sudo chmod -R 777 $vOSBinDir
fi

sudo ln -f -s $vFpcExeDir/$vFpcExeFile $vOSBinDir/$vFpcExeFile
sudo ln -f -s $vFpcExeDir/$vFpcExeFile $vOSBinDir/fpc$vBits

#=========================================

if [ -f $vFpcDir/fpc$vBits/units/$vCPUOS/rtl/system.ppu ] ;
then    
 
echo "   "
echo "[FINAL INFO]: FreePascal $vBits Building, finish..." 
echo "   "

else

echo "   "
echo "???????????????????????????????????????????????????"
echo "[ERROR]: FreePascal $vBits NOT build" 
echo "???????????????????????????????????????????????????"
echo "   "

fi

}
# =================== MAIN =============================
. $PWD/ln_All_Functions.sh
getvalues

if [ $vBits = 32 ] ;
then 
 dothejob
else
  if [ $vUseMultiArch = 1 ] ;
  then 
    setdummy32
    dothejob 
  fi
fi

