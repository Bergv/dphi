# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


dothejob() 
{

echo "----------------------------------------------"
echo " Please Wait... Removing Runtimes Directory" 
echo "----------------------------------------------"

#------------- Remove Runtimes Directory -------------

if [ -d $vCTDir/binRuntimes ] ;
then 
  sudo rm -fr $vCTDir/binRuntimes
  echo "[INFO]: Runtimes Directory removed from disk OK"
else
  echo "[INFO]: Runtimes Directory NOT EXIST, nothing to do ..."   
fi
}

# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi


