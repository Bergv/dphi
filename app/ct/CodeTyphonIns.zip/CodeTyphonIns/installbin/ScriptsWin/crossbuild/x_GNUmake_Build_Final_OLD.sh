# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{
# ===================== Build GNU Make ==================

cd C:/codetyphon/CrossEng/make_src     
    
if [ -d build ] ;
then     
    echo "[INFO]: Remove OLD temporary BUILD directory..."
    rm -rf build
    echo "  "
fi
    
mkdir build
cd build

echo "-------- configure -----------"
 
../configure --build=$buMakbuildCPUOS --host=$buMakhostCPUOS --target=$buMakTargetCPUOS --prefix=C:/codetyphon/CrossEng/makeout

echo " "
echo "-------- make ----------------"
make -j4

echo " "
echo "-------- make install --------"
make -j4 install

}

# =================== MAIN =============================

buPCBits=$1
buPCOS=$2
buPCCPUOS=$3
buMakbuildCPUOS=$4
buMakhostCPUOS=$5
buMakTargetCPUOS=$6


echo "   "
echo "-----------------------------------------------"
echo "   GNU make Build Engine Final settings"
echo "-----------------------------------------------"
echo "   "
echo $buPCBits
echo $buPCOS
echo $buPCCPUOS
echo $buMakbuildCPUOS
echo $buMakhostCPUOS
echo $buMakTargetCPUOS
echo "   "

dothejob

