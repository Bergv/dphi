# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

docleanall() 
{

if [ -f /usr/bin/fpcmake ] ;
then
  sudo rm -f /usr/bin/fpcmake
fi

if [ -f /usr/bin/${abTARGETCPUOS}-as ] ;
then
  sudo rm -f /usr/bin/${abTARGETCPUOS}-as
fi

if [ -d $vFpcDir/newfpc ] ;
then 
  sudo rm -rf $vFpcDir/newfpc
fi

if [ -d $vCTDir/binutils ] ;
then    
    sudo rm -rf $vCTDir/binutils
fi

if [ -d $vCTDir/binutilsout ] ;
then     
    sudo rm -rf $vCTDir/binutilsout
fi

}

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

dothejob() 
{

if [ $abTARGETCPUOS = $abFPCCPUOS ] ;
then 
  exit
fi

#////////////////// Remove this for Custom Cross Build Script ////////////////////
# ================= Build cross build tools ======================================

if [ -f $vCTDir/Settings/CT_Cross_GNU_Toolschains_Engine_Enabled.ctsw ] ;
then
./ln_FPCx_Build_Binutils $abFPCType $abFPCCPUOS $abFPCStartEXE $abTARGETCPU $abTARGETOS $abFPCCrossEXE $abParam
else
  echo "   "
  echo "[INFO]: [INFO]: Cross CT GNU Toolschains Engine Switch is OFF."
  echo "         Use files from GNU Toolschains Store."
  echo "   " 
fi
#//////////////////////////////////////////////////////////////////////////////////

# ================= Check Elements Engine Switch  =================================

if [ -f $vCTDir/Settings/CT_Cross_FPC_Elements_Engine_Disabled.ctsw ] ;
then
  echo "   "
  echo "[INFO]: Cross CT FPC Elements Engine Switch is OFF"
  echo "        Cross Build procedure STOP."
  echo "   "
  exit
fi

# ================= Build FPC cross compiler ======================================

echo "====================================================================="
echo "    Build Cross Element for $abTARGETCPUOS Param:$abParam"
echo "====================================================================="
echo "   "

# sleep 120

if [ ! -f $vFpcSrcDir/Makefile.fpc ] ;
then   
  echo "???????????????????????????????????????????????????????????"
  echo " [ERROR]:FreePascal Source directory NOT exists"
  echo "         sorry, Cross Build procedure STOP" 
  echo "??????????????????????????????????????????????????????????"
  docleanall
  exit
fi

if [ -d $vFpcDir/newfpc ] ;
then     
    echo "   "
    echo "[INFO]: Remove OLD FreePascal temporary build folder..."
    echo "   "
    sudo rm -rf $vFpcDir/newfpc
fi

if [ -d $vFpcDir/fpc$abBits/units/$abTARGETCPUOS/ ] ;
then     
    echo "   "
    echo "[INFO]: Remove OLD FreePascal Units folder..."
    echo "   "
    sudo rm -rf $vFpcDir/fpc$abBits/units/$abTARGETCPUOS
fi


if [ -d $vCTDir/binToolchains/all-$abTARGETCPUOS ] ; then 

  echo "[INFO]: Copy Files from ToolsChains Library..."
  sudo cp -f $vCTDir/binToolchains/all-$abTARGETCPUOS/* $vFpcDir/fpc$abBits/bin/$abFPCCPUOS/
  sudo chmod -R 777 $vFpcDir/fpc$abBits/bin/$abFPCCPUOS

elif [ -d $vCTDir/binToolchains/${abbincross} ] ; then 

  echo "[INFO]: Copy Files from ToolsChains Library..."
  sudo cp -f $vCTDir/binToolchains/${abbincross}/* $vFpcDir/fpc$abBits/bin/$abFPCCPUOS/
  sudo chmod -R 777 $vFpcDir/fpc$abBits/bin/$abFPCCPUOS
  
else    
  echo "???????????????????????????????????????????????????????????"
  echo "   [ERROR]: Can NOT find Toolchain files for $abTARGETCPUOS Param:$abParam" 
  echo "            in Toolchains Library." 
  echo "            sorry, Cross Build procedure STOP" 
  echo "??????????????????????????????????????????????????????????" 
  exit
fi

# =======================================================

cd $vFpcSrcDir

echo "   "
echo "------------------------------------------------"
echo "       Stage 0: Clean FreePascal $abFPCStartEXE" 
echo "------------------------------------------------"

sudo $vMake clean PP=$vFpcDir/fpc$abBits/bin/$abFPCCPUOS/$abFPCStartEXE

sudo find $PWD -type f -iname "fpcmade.*" -exec rm -f {} \;
sudo find $PWD -type f -iname "Package.fpc" -exec rm -f {} \;
sudo find $PWD -type f -iname "*.ppu" -exec rm -f {} \;

sudo find $PWD/compiler -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/packages -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/ide -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/installer -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/utils -type f -iname "*.o" -exec rm -f {} \;

sudo rm -f $vFpcSrcDir/packages/xforms/fd2pascal

sudo find $PWD/packages -type d -iname "units" -exec rm -rf {} \;

cd $vCTDir/ScriptsLin/crossbuild/


# sleep 120
# =======================================================================
# if the script find CUSTOM ln_FPCx_Build_Cross_xxxx.sh will execute this script..

cd $vCTDir/ScriptsLin/crossbuild

if [ -f ln_FPCx_Build_Element_${abTARGETCPU}_${abTARGETOS}_${abParam}.sh ] ; then 
 ./ln_FPCx_Build_Element_${abTARGETCPU}_${abTARGETOS}_${abParam}.sh $abFPCType $abFPCCPUOS $abFPCStartEXE $abTARGETCPU $abTARGETOS $abFPCCrossEXE $abParam

elif [ -f ln_FPCx_Build_Element_${abTARGETCPU}_${abTARGETOS}.sh ] ; then  
 ./ln_FPCx_Build_Element_${abTARGETCPU}_${abTARGETOS}.sh $abFPCType $abFPCCPUOS $abFPCStartEXE $abTARGETCPU $abTARGETOS $abFPCCrossEXE $abParam

elif [ -f ln_FPCx_Build_Element_${abTARGETOS}.sh ] ; then  
 ./ln_FPCx_Build_Element_${abTARGETOS}.sh $abFPCType $abFPCCPUOS $abFPCStartEXE $abTARGETCPU $abTARGETOS $abFPCCrossEXE $abParam

elif [ -f ln_FPCx_Build_Element_${abTARGETCPU}.sh ] ; then  
 ./ln_FPCx_Build_Element_${abTARGETCPU}.sh $abFPCType $abFPCCPUOS $abFPCStartEXE $abTARGETCPU $abTARGETOS $abFPCCrossEXE $abParam

else
 ./ln_FPCx_Build_Element.sh $abFPCType $abFPCCPUOS $abFPCStartEXE $abTARGETCPU $abTARGETOS $abFPCCrossEXE $abParam
fi


echo "   "
echo "------------------------------------------------"
echo "       Stage 4: Clean FreePascal Directory " 
echo "------------------------------------------------"

cd $vFpcSrcDir

sudo $vMake clean PP=$vFpcDir/fpc$abBits/bin/$abFPCCPUOS/$abFPCStartEXE

sudo find $PWD -type f -iname "fpcmade.*" -exec rm -f {} \;
sudo find $PWD -type f -iname "Package.fpc" -exec rm -f {} \;
sudo find $PWD -type f -iname "*.ppu" -exec rm -f {} \;

sudo find $PWD/compiler -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/packages -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/ide -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/installer -type f -iname "*.o" -exec rm -f {} \;
sudo find $PWD/utils -type f -iname "*.o" -exec rm -f {} \;

sudo rm -f $vFpcSrcDir/packages/xforms/fd2pascal

sudo find $PWD/packages -type d -iname "units" -exec rm -rf {} \;

cd $vCTDir/ScriptsLin/crossbuild/


echo "   "
echo "------------------------------------------------"
echo "       Stage 5: Copy Files and Units" 
echo "------------------------------------------------"

#---- Copy Cross Units files ----

if [ -d $vFpcDir/newfpc/lib/fpc/$vFpcVer/units ] ;
then
 echo "   "
 echo "[INFO]: Move FPC Cross compiler units..."
 sudo cp -fr $vFpcDir/newfpc/lib/fpc/$vFpcVer/units/* $vFpcDir/fpc$abBits/units/
fi

#---- Copy Cross bin files ----

if [ -d $vFpcDir/newfpc/bin ] ;
then

if [ ! -d $vFpcDir/fpc$abBits/bin/$abTARGETCPUOS ] ;
then 
  sudo mkdir $vFpcDir/fpc$abBits/bin/$abTARGETCPUOS
  sudo chmod -R 777 $vFpcDir/fpc$abBits/bin/$abTARGETCPUOS
fi 
 echo "[INFO]: Move FPC Cross compiler Bin Files..."
 sudo cp -f $vFpcDir/newfpc/bin/* $vFpcDir/fpc$abBits/bin/$abTARGETCPUOS/

fi

#--------- Clean all ---------
docleanall

sudo chmod -R 777 $vFpcDir/fpc$abBits/bin/$abFPCCPUOS
sudo chmod -R 777 $vFpcDir

# ===================Final Check ===================================

if [ -f $vFpcDir/fpc$abBits/units/$abTARGETCPUOS/rtl/system.ppu ] ;
then 
    echo "   "
    echo "[FINAL INFO]:-- !!! FPC$abBits $abTARGETCPUOS Param:$abParam Cross Build Element Build OK !!! --"
    echo "   "
else
    echo "   "
    echo " ???????????????????????????????????????????????????????????"
    echo "  [ERROR]: FPC$abBits Cross Element $abTARGETCPUOS Param:$abParam NOT Exists" 
    echo "           sorry, Cross Build procedure STOP"
    echo " ???????????????????????????????????????????????????????????"
    echo "   " 
fi

}

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

# =================== MAIN =============================
. /usr/local/codetyphon/ScriptsLin/ln_All_Functions.sh
getvalues

abFPCType=$1
abFPCCPUOS=$2
abFPCStartEXE=$3
abTARGETCPU=$4
abTARGETOS=$5
abFPCCrossEXE=$6
abParam=$7

abTARGETCPUOS=${abTARGETCPU}-${abTARGETOS}

if [ $abParam = xxxx ] ; 
then 
  abbincross=${abFPCType}-${abTARGETCPUOS}
else
  abbincross=${abFPCType}-${abTARGETCPUOS}--${abParam}
fi

#-------- Find Bits -------------------
case $abFPCType in 
 *32*)
    abBits=32
    ;; 
 *)
    abBits=64
    ;;    
esac

#-------- Print Settings ----------------

echo "   "
echo "-----------------------------------------------"
echo "   FPC Cross Elements Engine settings"
echo "-----------------------------------------------"
echo "   "
echo $abFPCType
echo $abFPCCPUOS
echo $abFPCStartEXE
echo $abTARGETCPU
echo $abTARGETOS
echo $abFPCCrossEXE
echo $abTARGETCPUOS
echo $abParam
echo "   "
echo $abbincross
echo $abBits
echo "   "

dothejob




