# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

echo "-------------------------------------------------"
echo "               Start Typhon AS ROOT "
echo "-------------------------------------------------"

sudo typhonstart

# sleep 120
