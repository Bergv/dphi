# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

if [ -d $vTyphonSetDir ] ;
then     
  sudo chmod -R 777 $vTyphonSetDir
  sudo rm -fr $vTyphonSetDir
fi

if [ ! -d $vTyphonSetDir ] ;
then   
  sudo mkdir $vTyphonSetDir
  sudo chmod -R 777 $vTyphonSetDir
fi

if [ ! -d $vTyphonSetDir/userschemes ] ;
then   
  sudo mkdir $vTyphonSetDir/userschemes
  sudo chmod -R 777 $vTyphonSetDir/userschemes
fi

if [ -d $vCTDir/binSettings/settings/${vCPUOSPlat}/styphon ] ; 
then 

sudo cp -f $vCTDir/binSettings/settings/${vCPUOSPlat}/styphon/* $vTyphonSetDir
sudo cp -f $vCTDir/binSettings/settings/alluserschemes/* $vTyphonSetDir/userschemes
sudo chmod -R 777 $vTyphonSetDir
sudo chmod 777 $vTyphonSetDir/*

fi

echo "   " 
echo "[INFO]: Restore Typhon$vBits Settings finish"
}

# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

echo "   "  
echo "--------------------------------------------"
echo "   Restore Typhon Default IDE Setings"
echo "--------------------------------------------"


dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi

echo "   "

