# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

dothejob() 
{

echo "   "
echo "================================================="
echo "  CUSTOM Cross Element Build" 
echo "================================================="
echo "   "

cd $vFpcSrcDir

# ------------------- Set Android Things ----------------------------

case $cbTARGETCPU in
'arm')
  cbandroid=arm-linux-androideabi
  cbandroidas=arm-linux-androideabi-as
 ;;
'aarch64')
  cbandroid=aarch64-linux-android
  cbandroidas=aarch64-linux-android-as
 ;;
'i386')
   cbandroid=i686-linux-android
   cbandroidas=i686-linux-android-as
 ;;
'x86_64')
   cbandroid=x86_64-linux-android
   cbandroidas=x86_64-linux-android-as
 ;;
'mipsel')
   cbandroid=mipsel-linux-android
   cbandroidas=mipsel-linux-android-as
 ;;
'mips64el')
   cbandroid=mips64el-linux-android
   cbandroidas=mips64el-linux-android-as
 ;;
esac 

# ------------------- Make Links -------------------------------------

if [ -f $vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/fpcmake ] ;
then
  sudo ln -f -s $vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/fpcmake ${cbSysLinkDir}/fpcmake
fi

if [ -f $vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbandroidas ] ;
then 
  sudo ln -f -s $vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbandroidas ${cbSysLinkDir}/$cbandroidas
fi

echo "   "
echo "------------------------------------------------"
echo "       Stage 1: Build Cross Compiler Executable" 
echo "------------------------------------------------"

if [ $vOSName = solaris ] ;
then   
  
  if [ $cbTARGETCPU = arm ] ;
  then   
    sudo $vMake compiler_cycle CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbandroid}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCStartEXE OPT="-Xn -dFPC_ARMEL"
  else  
    sudo $vMake compiler_cycle CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbandroid}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCStartEXE OPT="-Xn"
  fi
 
elif [ $vOSName = darwin ] ;
then 
  
  if [ $cbTARGETCPU = arm ] ;
  then   
    sudo $vMake compiler_cycle CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbandroid}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCStartEXE OPT="-dFPC_ARMEL -XR/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk"
  else  
    sudo $vMake compiler_cycle CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbandroid}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCStartEXE OPT="-XR/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk"
  fi

else
  
  if [ $cbTARGETCPU = arm ] ;
  then   
    sudo $vMake compiler_cycle CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbandroid}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCStartEXE OPT="-dFPC_ARMEL"
  else  
    sudo $vMake compiler_cycle CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbandroid}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCStartEXE
  fi
  
fi

if [ ! -f $vFpcSrcDir/compiler/$cbFPCCrossEXE ] ;
then  
  echo "???????????????????????????????????????????????????????????"
  echo " [ERROR]:Cross compiler $cbFPCCrossEXE  NOT Builded"
  echo "         sorry, Cross Build procedure STOP" 
  echo "??????????????????????????????????????????????????????????"
  docleanall
  exit
else
 sudo cp -f $vFpcSrcDir/compiler/$cbFPCCrossEXE $vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/
 sudo chmod -R 777 $vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS
 echo "   "
 echo "[INFO]: !!! Cross compiler Executable $cbFPCCrossEXE, Build OK. !!!"
 echo "   "
fi

# -------------------------------------------------------------------
# sleep 120
# --------------------------------------------------------------------
echo "   "
echo "------------------------------------------------"
echo "       Stage 2: Build All Units and Packages" 
echo "------------------------------------------------"

if [ $vOSName = darwin ] ;
then

  if [ $cbTARGETCPU = arm ] ;
  then   
    sudo $vMake rtl packages CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbandroid}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCCrossEXE CROSSOPT="-dFPC_ARMEL" OPT="-XR/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk"
  else  
    sudo $vMake rtl packages CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbandroid}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCCrossEXE OPT="-XR/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk"
  fi

else

  if [ $cbTARGETCPU = arm ] ;
  then   
    sudo $vMake rtl packages CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbandroid}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCCrossEXE CROSSOPT="-dFPC_ARMEL"
  else  
    sudo $vMake rtl packages CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbandroid}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCCrossEXE
  fi

fi


# -------------------------------------------------------------------
# sleep 120
# -------------------------------------------------------------------
echo "   "
echo "------------------------------------------------"
echo "       Stage 3: Install All Units and Packages " 
echo "------------------------------------------------"

sudo $vMake rtl_install packages_install CROSSINSTALL=1 CPU_TARGET=$cbTARGETCPU OS_TARGET=$cbTARGETOS BINUTILSPREFIX=${cbandroid}- FPC=$vFpcDir/fpc$cbBits/bin/$cbFPCCPUOS/$cbFPCCrossEXE PREFIX=/usr/local/codetyphon/fpc/newfpc

# ------------------- REMOVE SysLinks  ----------------------------------

if [ -f ${cbSysLinkDir}/fpcmake ] ;
then
  sudo rm -f ${cbSysLinkDir}/fpcmake
fi

if [ -f ${cbSysLinkDir}/$cbandroidas ] ;
then
  sudo rm -f ${cbSysLinkDir}/$cbandroidas
fi
  
}

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

# =================== MAIN =============================
. /usr/local/codetyphon/ScriptsLin/ln_All_Functions.sh
getvalues

cbFPCType=$1
cbFPCCPUOS=$2
cbFPCStartEXE=$3
cbTARGETCPU=$4
cbTARGETOS=$5
cbFPCCrossEXE=$6
cbParam=$7

cbTARGETCPUOS=${cbTARGETCPU}-${cbTARGETOS}

if [ $cbParam = xxxx ] ;
then
  cbbincross=${cbFPCType}-${cbTARGETCPUOS}
else
  cbbincross=${cbFPCType}-${cbTARGETCPUOS}--${cbParam}
fi

#-------- Find Bits ----------------------------------
case $cbFPCType in
 *32*)
    cbBits=32
    ;;
 *)
    cbBits=64
    ;;
esac

#-------- Setup SysLinkdir ----------------------------

if [ $vOSName = darwin ] ;
then
   cbSysLinkDir=/usr/local/bin
else
   cbSysLinkDir=/usr/bin
fi

#------------------------------------------------------

dothejob

