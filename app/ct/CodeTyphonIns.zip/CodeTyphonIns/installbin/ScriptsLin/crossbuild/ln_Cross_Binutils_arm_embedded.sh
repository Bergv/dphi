# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

dothejob() 
{

echo "   "
echo "================================================="
echo "  CUSTOM Toolchain Build" 
echo "================================================="
echo "   "

# ===================== Build Binutils ==================


cd $vCTDir/CrossEng/binutils


if [ -d build ] ;
then     
    echo "[INFO]: Remove OLD temporary BUILD directory..."
    sudo rm -rf build
    echo "  "
fi

mkdir build
sudo chmod -R 777 build/
cd build

echo "-------- configure -----------"
  
../configure --prefix=$vCTDir/CrossEng/binutilsout --program-prefix=arm-embedded- --target=arm-linux --disable-nls --disable-werror --disable-shared


echo " "
echo "-------- make ----------------"
sudo $vMake -j4

echo " "
echo "-------- make install --------"
sudo $vMake -j4 install

}

# =================== MAIN =============================
. /usr/local/codetyphon/ScriptsLin/ln_All_Functions.sh
getvalues

buFPCType=$1
buFPCCPUOS=$2
buFPCStartEXE=$3
buTARGETCPU=$4
buTARGETOS=$5
buFPCCrossEXE=$6
buParam=$7
buTARGETCPUOS=${buTARGETCPU}-${buTARGETOS}


echo "   "
echo "-----------------------------------------------"
echo "   GNU Cross toolschains Engine settings CUSTOM"
echo "   Real binutils target: arm-linux"
echo "-----------------------------------------------"
echo "   "
echo $buFPCType
echo $buFPCCPUOS
echo $buFPCStartEXE
echo $buTARGETCPU
echo $buTARGETOS
echo $buFPCCrossEXE
echo $buTARGETCPUOS
echo $buParam
echo "   "

dothejob

