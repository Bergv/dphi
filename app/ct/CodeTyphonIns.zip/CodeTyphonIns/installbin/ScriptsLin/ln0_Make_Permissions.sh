# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


echo "-------------------------------------------------"
echo "      CodeTyphon Make Files Permissions" 
echo "-------------------------------------------------"

cd ..

# ==============Make Permissions =================
sudo chmod 777 *.sh
sudo chmod 777 ScriptsLin/*.sh
sudo chmod 777 ScriptsLin/systems/*.sh
sudo chmod 777 CodeTyphon_ln32.ex
sudo chmod 777 CodeTyphon_ln64.ex

sudo chmod -R 777 bin/i386-linux
sudo chmod 777 bin/i386-linux/bin/*
sudo chmod 777 bin/i386-linux/lib/ppc386

sudo chmod -R 777 bin/x86_64-linux
sudo chmod 777 bin/x86_64-linux/lib/*
sudo chmod 777 bin/x86_64-linux/lib/ppcx64

sudo chmod -R 777 binMOD
sudo chmod 777 binMOD/*

# =========== CodeOcean ==========================================

sudo chmod 777 CodeOcean/*.sh
sudo chmod 777 CodeOcean/1Other/*.sh
sudo chmod 777 CodeOcean/AGG/*.sh
sudo chmod 777 CodeOcean/APE/*.sh
sudo chmod 777 CodeOcean/AsphyreSphinx/*.sh
sudo chmod 777 CodeOcean/BGRAbitmap/*.sh
sudo chmod 777 CodeOcean/BGRAcontrols/*.sh
sudo chmod 777 CodeOcean/BGRAueControls/*.sh
sudo chmod 777 CodeOcean/Box2D/*.sh
sudo chmod 777 CodeOcean/Cindy/*.sh
sudo chmod 777 CodeOcean/ExControls/*.sh
sudo chmod 777 CodeOcean/ExDesign/*.sh
sudo chmod 777 CodeOcean/GeoGIS/*.sh
sudo chmod 777 CodeOcean/ExSystem/*.sh
sudo chmod 777 CodeOcean/GLScene/*.sh
sudo chmod 777 CodeOcean/Graphics32/*.sh
sudo chmod 777 CodeOcean/Graphics32EXT/*.sh
sudo chmod 777 CodeOcean/Graphics32VPR/*.sh
sudo chmod 777 CodeOcean/JVCL/*.sh
sudo chmod 777 CodeOcean/KambiEngine/*.sh
sudo chmod 777 CodeOcean/KControls/*.sh
sudo chmod 777 CodeOcean/LNet/*.sh
sudo chmod 777 CodeOcean/OpenGL/*.sh
sudo chmod 777 CodeOcean/Orpheus/*.sh
sudo chmod 777 CodeOcean/PAPPE/*.sh
sudo chmod 777 CodeOcean/PowerPDF/*.sh
sudo chmod 777 CodeOcean/RX/*.sh
sudo chmod 777 CodeOcean/Shapes/*.sh
sudo chmod 777 CodeOcean/TitanScript/*.sh
sudo chmod 777 CodeOcean/VirtualTrees/*.sh
sudo chmod 777 CodeOcean/Win_DirectX/*.sh
sudo chmod 777 CodeOcean/ZenGL/*.sh
sudo chmod 777 CodeOcean/ZenGLD3D/*.sh
sudo chmod 777 CodeOcean/ZenGLES/*.sh

sleep 5

