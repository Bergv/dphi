# =============================================================
#               CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
#
#      This Script Try to Fix OS Libraries Links
# =============================================================
# Ver 5.50 2015-08-15

#===============================================================
#======================= Delete ALL Links ======================

DeleteSysLinks()
{
sudo rm -f $vOSLibDir/libc.so
sudo rm -f $vOSLibDir/libdl.so
sudo rm -f $vOSLibDir/libpthread.so
sudo rm -f $vOSLibDir/libX11.so
sudo rm -f $vOSLibDir/libgdk_pixbuf-2.0.so
sudo rm -f $vOSLibDir/libgtk-x11-2.0.so
sudo rm -f $vOSLibDir/libgdk-x11-2.0.so
sudo rm -f $vOSLibDir/libgobject-2.0.so
sudo rm -f $vOSLibDir/libglib-2.0.so
sudo rm -f $vOSLibDir/libgthread-2.0.so
sudo rm -f $vOSLibDir/libgmodule-2.0.so
sudo rm -f $vOSLibDir/libpango-1.0.so
sudo rm -f $vOSLibDir/libcairo.so
sudo rm -f $vOSLibDir/libatk-1.0.so
sudo rm -f $vOSLibDir/libXtst.so
sudo rm -f $vOSLibDir/libpangocairo-1.0.so
sudo rm -f $vOSLibDir/libGL.so
sudo rm -f $vOSLibDir/libGLU.so
sudo rm -f $vOSLibDir/libfreetype.so
sudo rm -f $vOSLibDir/libXxf86vm.so
sudo rm -f $vOSLibDir/libgtkglext-x11-1.0.so
sudo rm -f $vOSLibDir/libgdkglext-x11-1.0.so
sudo rm -f $vOSLibDir/libz.so
}

#DeleteSysLinks


#===============================================================
#========================= Make a Bin Link =====================

MakeABinLink()
{
#vcFrom
#vcTo

vcError=0

if [ -f $vOSBinDir/$vcTo ] ;
then
echo "   [ OK ] $vOSBinDir/$vcTo Exists "

elif [ -f $vOSBinDir/$vcFrom ] ;
then
echo "   [DONE] make $vOSBinDir/$vcFrom symlink to $vOSBinDir/$vcTo"
sudo ln -s $vOSBinDir/$vcFrom $vOSBinDir/$vcTo

elif [ ! -d $vOSLocalBinDir ] ;
then
vcError=1
echo "   [ER-INFO] $vOSBinDir/$vcFrom NOT Exists ???, can't make symlink for: $vcTo"

elif [ -f $vOSLocalBinDir/$vcTo ] ;
then
echo "   [ OK ] $vOSLocalBinDir/$vcTo Exists "

elif [ -f $vOSLocalBinDir/$vcFrom ] ;
then
echo "   [DONE] make $vOSLocalBinDir/$vcFrom symlink to $vOSLocalBinDir/$vcTo"
sudo ln -s $vOSLocalBinDir/$vcFrom $vOSLocalBinDir/$vcTo

else
vcError=1
echo " "
echo "   [ER-INFO] $vcFrom Executable NOT Exists ???"
echo "             Can't make symlink for: $vcTo"
echo " "

fi
}


#===================================================================
#========================= Make a Library Link =====================

MakeALibLink()
{
#vcFrom
#vcTo

vcError=0

if [ -f $vOSLibDir/$vcTo ] ;
then
echo "   [ OK ] $vOSLibDir/$vcTo Exists "

elif [ -f $vOSLibDir/$vcFrom ] ;
then
echo "   [DONE] make $vOSLibDir/$vcFrom symlink to $vOSLibDir/$vcTo"
sudo ln -s $vOSLibDir/$vcFrom $vOSLibDir/$vcTo

#--- for Debian/Ubuntu ---------------
elif [ -f $vOSLibDir/mesa/$vcFrom ] ;
then
echo "   [DONE] make $vOSLibDir/mesa/$vcFrom symlink to $vOSLibDir/$vcTo"
sudo ln -s $vOSLibDir/mesa/$vcFrom $vOSLibDir/$vcTo

elif [ ! -d $vOSLocalBinDir ] ;
then
vcError=1
echo "   [ER-INFO] $vOSLibDir/$vcFrom NOT Exists ???, can't make symlink for: $vcTo"

elif [ -f $vOSLocalLinDir/$vcTo ] ;
then
echo "   [ OK ] $vOSLocalLinDir/$vcTo Exists "

elif [ -f $vOSLocalLinDir/$vcFrom ] ;
then
echo "   [DONE] make $vOSLocalLinDir/$vcFrom symlink to $vOSLocalLinDir/$vcTo"
sudo ln -s $vOSLocalLinDir/$vcFrom $vOSLocalLinDir/$vcTo

#--- From /usr/lib32/ or /usr/lib64/ ----------------------------------
elif [ -f /usr/lib$vBits/$vcTo ] ;
then
echo "   [ OK ] /usr/lib$vBits/$vcTo Exists "

elif [ -f /usr/lib$vBits/$vcFrom ] ;
then
echo "   [DONE] make /usr/lib$vBits/$vcFrom symlink to /usr/lib$vBits/$vcTo"
sudo ln -s /usr/lib$vBits/$vcFrom /usr/lib$vBits/$vcTo

#--- From /usr/local/lib32/ or /usr/local/lib64/ -------
elif [ -f /usr/local/lib$vBits/$vcTo ] ;
then
echo "   [ OK ] /usr/local/lib$vBits/$vcTo Exists "

elif [ -f /usr/local/lib$vBits/$vcFrom ] ;
then
echo "   [DONE] make /usr/local/lib$vBits/$vcFrom symlink to /usr/local/lib$vBits/$vcTo"
sudo ln -s /usr/local/lib$vBits/$vcFrom /usr/local/lib$vBits/$vcTo

#--- From /usr/lib/ --------------------------------------------------
elif [ -f /usr/lib/$vcTo ] ;
then
echo "   [ OK ] /usr/lib/$vcTo Exists "

elif [ -f /usr/lib/$vcFrom ] ;
then
echo "   [DONE] make /usr/lib/$vcFrom symlink to /usr/lib/$vcTo"
sudo ln -s /usr/lib/$vcFrom /usr/lib/$vcTo

#--- From /usr/local/lib/ ------------------------
elif [ -f /usr/local/lib/$vcTo ] ;
then
echo "   [ OK ] /usr/local/lib/$vcTo Exists "

#----- For NetBSD ---------------------

elif [ -f /usr/pkg/lib/$vcTo ] ;
then
echo "   [ OK ] /usr/pkg/lib/$vcTo Exists "

elif [ -f /usr/X11R7/lib/$vcTo ] ;
then
echo "   [ OK ] /usr/X11R7/lib/$vcTo Exists "

#---------------------------------------

elif [ -f /usr/local/lib/$vcFrom ] ;
then
echo "   [DONE] make /usr/local/lib/$vcFrom symlink to /usr/local/lib/$vcTo"
sudo ln -s /usr/local/lib/$vcFrom /usr/local/lib/$vcTo

# last try to find library
#--- From /lib/ or /lib64/ ==> /usr/lib/ or /usr/lib64/ ----------------
elif [ -f /$vOSLibSub/$vcFrom ] ;
then
echo "   [DONE-Ex] make /$vOSLibSub/$vcFrom symlink to $vOSLibDir/$vcTo"
sudo ln -s /$vOSLibSub/$vcFrom $vOSLibDir/$vcTo

else
vcError=1
echo " "
echo "   [ER-INFO] $vcFrom Library NOT Exists ???"
echo "             Can't make symlink for: $vcTo"
echo " "
fi

}

#===================================================================
#======================= Make ALL Links ============================

MakeSysLinks()
{
echo ".........................................."
echo "[INFO] OS Libraries Dir for $vBits : $vOSLibDir"
echo ".........................................."

vcError=0

#-------------------------- FPC -------------------------

# == for FreeBSD, NetBSD ====
if [ $vHostOSRealName = FreeBSD ] ;
then
echo "   "

elif [ $vHostOSRealName = NetBSD ] ; then
echo "   "

elif [ $vHostOSRealName = OpenBSD ] ; then
echo "   "
  
else
vcTo=libdl.so
vcFrom=libdl.so.0
MakeALibLink
fi

vcTo=libc.so
vcFrom=libc.so.6
MakeALibLink

vcTo=libpthread.so
vcFrom=libpthread.so.6
MakeALibLink


#--------------------- Typhon General -----------------------

vcTo=libX11.so
vcFrom=libX11.so.6
MakeALibLink

vcTo=libgobject-2.0.so
vcFrom=libgobject-2.0.so.0
MakeALibLink

vcTo=libglib-2.0.so
vcFrom=libglib-2.0.so.0
MakeALibLink

vcTo=libgthread-2.0.so
vcFrom=libgthread-2.0.so.0
MakeALibLink

vcTo=libgmodule-2.0.so
vcFrom=libgmodule-2.0.so.0
MakeALibLink

vcTo=libatk-1.0.so
vcFrom=libatk-1.0.so.0
MakeALibLink

vcTo=libXtst.so
vcFrom=libXtst.so.6
MakeALibLink

vcTo=libfreetype.so
vcFrom=libfreetype.so.6
MakeALibLink

vcTo=libXxf86vm.so
vcFrom=libXxf86vm.so.1
MakeALibLink

vcTo=libz.so
vcFrom=libz.so.1
MakeALibLink

vcTo=libGL.so
vcFrom=libGL.so.1
MakeALibLink

vcTo=libGLU.so
vcFrom=libGLU.so.1
MakeALibLink

#----------------------- Typhon GTK2------------------------------
if [ $vLCLplat = 0 ] ;
then

vcTo=libgdk_pixbuf-2.0.so
vcFrom=libgdk_pixbuf-2.0.so.0
MakeALibLink

vcTo=libpango-1.0.so
vcFrom=libpango-1.0.so.0
MakeALibLink

vcTo=libcairo.so
vcFrom=libcairo.so.2
MakeALibLink

vcTo=libpangocairo-1.0.so
vcFrom=libpangocairo-1.0.so.0
MakeALibLink

vcTo=libgtk-x11-2.0.so
vcFrom=libgtk-x11-2.0.so.0
MakeALibLink

vcTo=libgdk-x11-2.0.so
vcFrom=libgdk-x11-2.0.so.0
MakeALibLink
 
fi

#------------------------ Typhon QT------------------------------
# if [ $vLCLplat = 1 ] ;
# then

# vcTo=qmake-qt4
# vcFrom=qmake
# MakeABinLink
 
# fi

#------------------------ Typhon GTK3----------------------------
if [ $vLCLplat = 3 ] ;
then

vcTo=libgdk-3.so
vcFrom=libgdk-3.so.0
MakeALibLink
 
fi

#------------------------ Typhon GTK4----------------------------
if [ $vLCLplat = 9 ] ;
then

vcTo=libgtk-4.so
vcFrom=libgtk-4.so.1
MakeALibLink
 
fi

}

#===================================================================
#============= Make ALL Links For MacOS ============================

MakeSysLinksMacOS()
{

vcError=0

  echo " "
  
  
#======= CLT ============================================
# Update Command Line Tools

#sudo rm -rf /Library/Developer/CommandLineTools
#code-select --install

if [ -d /Library/Developer/CommandLineTools ] ;
then
echo "   [INFO] Command Line Tools Exists"
else
echo "   [ERROR] Command Line Tools NOT Exists ????"
echo "           Please Install Command Line Tools first."
echo "   "
echo "----------------------------------------------------"
fi

#==== OLD Frameworks Staff ===========


if [ -f /usr/local/lib/libc.dylib ] ;
then
  sudo chmod -R 777 /usr/local/lib
  sudo rm -fr /usr/local/lib
  echo "   [DONE] REMOVE OLD Dir: /usr/local/lib"
fi

if [ -d /Library/Frameworks/CoreFoundation.framework ] ;
then
  sudo chmod -R 777 /Library/Frameworks/CoreFoundation.framework
  sudo rm -fr /Library/Frameworks/CoreFoundation.framework
  echo "   [DONE] REMOVE OLD Dir: /Library/Frameworks/CoreFoundation.framework"
fi

#==== /usr/local/bin/ Staff ======

if [ ! -d /usr/local/bin/ ] ;
then
  sudo mkdir /usr/local/bin
  sudo chmod -R 777 /usr/local/bin
fi

#......... xterm MacPorts ............
if [ -f /usr/local/bin/xterm ] ;
then
echo "   [ OK ] /usr/local/bin/xterm Exists "

elif [ -f /opt/local/bin/xterm ] ;
then

sudo ln -f -s /opt/local/bin/xterm /usr/local/bin/xterm
sudo chmod 777 /usr/local/bin/xterm
echo "   [DONE] make /opt/local/bin/xterm symlink to /usr/local/bin/xterm"

else
echo "   [ER-INFO] /usr/local/bin/xterm NOT Exists ???"
fi


#......... gmake MacPorts ............
if [ -f /usr/local/bin/gmake ] ;
then
echo "   [ OK ] /usr/local/bin/gmake Exists "

elif [ -f /opt/local/bin/gmake ] ;
then

sudo ln -f -s /opt/local/bin/gmake /usr/local/bin/gmake
sudo chmod 777 /usr/local/bin/gmake
echo "   [DONE] make /opt/local/bin/gmake symlink to /usr/local/bin/gmake"

else
echo "   [ER-INFO] /usr/local/bin/gmake NOT Exists ???"
fi

#......... make MacPorts ............
if [ -f /usr/local/bin/make ] ;
then
echo "   [ OK ] /usr/local/bin/make Exists "

elif [ -f /opt/local/bin/gmake ] ;
then

sudo ln -f -s /opt/local/bin/gmake /usr/local/bin/make
sudo chmod 777 /usr/local/bin/make
echo "   [DONE] make /opt/local/bin/gmake symlink to /usr/local/bin/make"

else
echo "   [ER-INFO] /usr/local/bin/make NOT Exists ???"
fi

#......... ggdb MacPorts ............
if [ -f /usr/local/bin/ggdb ] ;
then
echo "   [ OK ] /usr/local/bin/ggdb Exists "

elif [ -f /opt/local/bin/ggdb ] ;
then

sudo ln -f -s /opt/local/bin/ggdb /usr/local/bin/ggdb
sudo chmod 777 /usr/local/bin/ggdb
echo "   [DONE] make /opt/local/bin/ggdb symlink to /usr/local/bin/ggdb"

else
echo "   [ER-INFO] /usr/local/bin/ggdb NOT Exists ???"
fi

#......... wget MacPorts ............
if [ -f /usr/local/bin/wget ] ;
then
echo "   [ OK ] /usr/local/bin/wget Exists "

elif [ -f /opt/local/bin/wget ] ;
then

sudo ln -f -s /opt/local/bin/wget /usr/local/bin/wget
sudo chmod 777 /usr/local/bin/wget
echo "   [DONE] make /opt/local/bin/wget symlink to /usr/local/bin/wget"

else
echo "   [ER-INFO] /usr/local/bin/wget NOT Exists ???"
fi

#.........Check codesign ggdb ............

SIGNED="$(codesign -dv /usr/local/bin/ggdb 2>&1)"

if [[ $SIGNED == *"object is not signed"* ]]
then
  echo "  "
  echo "[WARNING] gdb (/usr/local/bin/ggdb) is NOT currently code signed. ????"
  echo "  "
else
  echo "  "
  echo "[INFO] gdb (/usr/local/bin/ggdb) has signed"
  echo "  "
fi

}

#===================================================================
# ====================== Do The Job ================================
#===================================================================

dothejob()
{

if [ $vHostOSRealName = Darwin ] ;
then
  MakeSysLinksMacOS
else
  MakeSysLinks
fi

}

#===================================================================
#===================================================================
# ======================= Main =====================================
. $PWD/ln_All_Functions.sh
getvalues

echo "  "
echo "----------------------------------------------------"
echo "   CodeTyphon Try to Fix Links for SysLibraries"
echo "----------------------------------------------------"

dothejob

if [ $vUseMultiArch = 1 ] ;
then
setdummy32
dothejob
fi

echo "----------------------------------------------------"
echo "CodeTyphon Fix Links for SysLibraries"
echo "Finish !!!"

#sleep 5
