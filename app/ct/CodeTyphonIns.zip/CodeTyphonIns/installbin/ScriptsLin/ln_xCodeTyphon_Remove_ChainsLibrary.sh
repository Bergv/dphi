# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


dothejob() 
{

echo "----------------------------------------------"
echo " Please Wait... Removing Toolchains Library Directory" 
echo "----------------------------------------------"

#------------- Remove Toolchains Library Directory -------------

if [ -d $vCTDir/binToolchains ] ;
then 
  sudo rm -fr $vCTDir/binToolchains
  echo "[INFO]: Toolchains Library Directory Removed OK"
else
  echo "[INFO]: Toolchains Library Directory NOT EXIST, nothing to do ..."   
fi
}

# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi


