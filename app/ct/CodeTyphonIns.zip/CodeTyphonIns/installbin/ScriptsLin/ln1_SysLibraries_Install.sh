# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================

# =====================================================================
# [INFO] sudo, zip, unzip, xterm (needed by CodeTyphon)
# [INFO] make gcc build-essential binutils binutils-devel (needed by fpc)
# [INFO] gdb gdb-doc devscripts (needed by fpc and Typhon)
# [INFO] libgpmg1-dev (needed by fpc console IDE)
# [INFO] xterm, alien, libgtk2.0-dev (needed by Typhon IDE)
# [INFO] libsdl-dev,libXxf86vm-dev, libgl1-mesa-dev, libglu1-mesa-dev(needed by pl_GLScene 3D Components Library)
# [INFO] libgtkglext1, libgtkglext1-dev (needed by Kambi Engine 3D Components Library)
# [INFO] gtkglext-devel gtkglext-doc (needed by ORCA 2D/3D Components Library)
# ===========================================================


# =======================Main================================
. $PWD/ln_All_Functions.sh
getvalues

#-- Set to '1' will install ALL Platform Libraries

caInstallALL=$1

echo "***************************************************"    
echo " Found:  $vOSDistribution  (OS ID:$vOSVerNum)"
echo "***************************************************"

if [ "$caInstallALL" = 1 ] ; 
then 
  echo " "
  echo "[INFO] Install System Libraries for ALL CT Platforms"
  echo " "
fi

# sleep 2
# ===========================================================

case $vOSVerNum in
1)
echo "Sorry, Unknow OS ???"
echo "Please, send this report to CodeTyphon Programmers..."
;;
100)
./systems/ln1_Install_SysLibraries_For_Ubuntu.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
200)
./systems/ln1_Install_SysLibraries_For_SuSE.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
300)
./systems/ln1_Install_SysLibraries_For_Debian.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
400)
./systems/ln1_Install_SysLibraries_For_CentOS.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
450)
./systems/ln1_Install_SysLibraries_For_OracleLinux.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
500)
./systems/ln1_Install_SysLibraries_For_Fedora.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
600)
./systems/ln1_Install_SysLibraries_For_RedHat.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
700)
./systems/ln1_Install_SysLibraries_For_Gentoo.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
720)
./systems/ln1_Install_SysLibraries_For_Sabayon.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
750)
./systems/ln1_Install_SysLibraries_For_ArchLinux.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
760)
./systems/ln1_Install_SysLibraries_For_ChakraLinux.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
763)
./systems/ln1_Install_SysLibraries_For_KaOS.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
765)
./systems/ln1_Install_SysLibraries_For_PCLinux.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
770)
./systems/ln1_Install_SysLibraries_For_Mandriva.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
775)
./systems/ln1_Install_SysLibraries_For_Mageia.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
776)
./systems/ln1_Install_SysLibraries_For_Rosa.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
777)
./systems/ln1_Install_SysLibraries_For_OpenMandriva.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
780)
./systems/ln1_Install_SysLibraries_For_Manjaro.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
800)
./systems/ln1_Install_SysLibraries_For_Slackware.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
850)
./systems/ln1_Install_SysLibraries_For_Solus.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
2000)
./systems/ln1_Install_SysLibraries_For_FreeBSD.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
3000)
./systems/ln1_Install_SysLibraries_For_OpenBSD.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
4000)
./systems/ln1_Install_SysLibraries_For_NetBSD.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
4500)
./systems/ln1_Install_SysLibraries_For_DragonFly.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
5000)
./systems/ln1_Install_SysLibraries_For_Solaris.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
5100)
./systems/ln1_Install_SysLibraries_For_OpenIndiana.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
6000)
./systems/ln1_Install_SysLibraries_For_MacOSX.sh $vLCLplat $vHostBits $vCPU $vUseMultiArch $caInstallALL
;;
esac

# sleep 2
# ===========================================================

./ln1_SysLibraries_Make_Links.sh

# ===========================================================

