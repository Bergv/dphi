# =============================================================
#                CodeTyphon Studio
#      Copyright (c) PilotLogic Software House.
#               All rights reserved.
# =============================================================


dothejob() 
{

echo "----------------------------------------------"
echo " Please Wait... Removing CrossBuild Engine Directory" 
echo "----------------------------------------------"

#------------- Remove CrossBuild Engine Directory -------------

if [ -d $vCTDir/CrossEng ] ;
then 
  sudo rm -fr $vCTDir/CrossEng
  echo "[INFO]: CrossBuild Engine Directory Removed OK"
else
  echo "[INFO]: CrossBuild Engine Directory NOT EXIST, nothing to do ...."   
fi
}

# =================== MAIN ============================= 
. $PWD/ln_All_Functions.sh
getvalues

dothejob

if [ $vUseMultiArch = 1 ] ;
then 
  setdummy32
  dothejob 
fi


